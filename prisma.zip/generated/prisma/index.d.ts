
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Event
 * 
 */
export type Event = $Result.DefaultSelection<Prisma.$EventPayload>
/**
 * Model Venue
 * 
 */
export type Venue = $Result.DefaultSelection<Prisma.$VenuePayload>
/**
 * Model LogisticsServiceProvider
 * 
 */
export type LogisticsServiceProvider = $Result.DefaultSelection<Prisma.$LogisticsServiceProviderPayload>
/**
 * Model CateringService
 * 
 */
export type CateringService = $Result.DefaultSelection<Prisma.$CateringServicePayload>
/**
 * Model SecurityAgency
 * 
 */
export type SecurityAgency = $Result.DefaultSelection<Prisma.$SecurityAgencyPayload>
/**
 * Model GiftShop
 * 
 */
export type GiftShop = $Result.DefaultSelection<Prisma.$GiftShopPayload>
/**
 * Model DJ
 * 
 */
export type DJ = $Result.DefaultSelection<Prisma.$DJPayload>
/**
 * Model Photographer
 * 
 */
export type Photographer = $Result.DefaultSelection<Prisma.$PhotographerPayload>
/**
 * Model EventType
 * 
 */
export type EventType = $Result.DefaultSelection<Prisma.$EventTypePayload>
/**
 * Model Vendor
 * 
 */
export type Vendor = $Result.DefaultSelection<Prisma.$VendorPayload>
/**
 * Model ContentPage
 * 
 */
export type ContentPage = $Result.DefaultSelection<Prisma.$ContentPagePayload>
/**
 * Model MediaItem
 * 
 */
export type MediaItem = $Result.DefaultSelection<Prisma.$MediaItemPayload>
/**
 * Model NewsItem
 * 
 */
export type NewsItem = $Result.DefaultSelection<Prisma.$NewsItemPayload>
/**
 * Model Student
 * 
 */
export type Student = $Result.DefaultSelection<Prisma.$StudentPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  ADMIN: 'ADMIN',
  STUDENT: 'STUDENT'
};

export type Role = (typeof Role)[keyof typeof Role]


export const EventStatus: {
  PENDING: 'PENDING',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED'
};

export type EventStatus = (typeof EventStatus)[keyof typeof EventStatus]


export const VenueStatus: {
  ACTIVE: 'ACTIVE',
  MAINTENANCE: 'MAINTENANCE',
  INACTIVE: 'INACTIVE'
};

export type VenueStatus = (typeof VenueStatus)[keyof typeof VenueStatus]


export const ContentStatus: {
  PUBLISHED: 'PUBLISHED',
  DRAFT: 'DRAFT'
};

export type ContentStatus = (typeof ContentStatus)[keyof typeof ContentStatus]


export const MediaType: {
  IMAGE: 'IMAGE',
  DOCUMENT: 'DOCUMENT',
  VIDEO: 'VIDEO'
};

export type MediaType = (typeof MediaType)[keyof typeof MediaType]


export const StudentStatus: {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE'
};

export type StudentStatus = (typeof StudentStatus)[keyof typeof StudentStatus]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

export type EventStatus = $Enums.EventStatus

export const EventStatus: typeof $Enums.EventStatus

export type VenueStatus = $Enums.VenueStatus

export const VenueStatus: typeof $Enums.VenueStatus

export type ContentStatus = $Enums.ContentStatus

export const ContentStatus: typeof $Enums.ContentStatus

export type MediaType = $Enums.MediaType

export const MediaType: typeof $Enums.MediaType

export type StudentStatus = $Enums.StudentStatus

export const StudentStatus: typeof $Enums.StudentStatus

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.event`: Exposes CRUD operations for the **Event** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Events
    * const events = await prisma.event.findMany()
    * ```
    */
  get event(): Prisma.EventDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.venue`: Exposes CRUD operations for the **Venue** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Venues
    * const venues = await prisma.venue.findMany()
    * ```
    */
  get venue(): Prisma.VenueDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.logisticsServiceProvider`: Exposes CRUD operations for the **LogisticsServiceProvider** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more LogisticsServiceProviders
    * const logisticsServiceProviders = await prisma.logisticsServiceProvider.findMany()
    * ```
    */
  get logisticsServiceProvider(): Prisma.LogisticsServiceProviderDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.cateringService`: Exposes CRUD operations for the **CateringService** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CateringServices
    * const cateringServices = await prisma.cateringService.findMany()
    * ```
    */
  get cateringService(): Prisma.CateringServiceDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.securityAgency`: Exposes CRUD operations for the **SecurityAgency** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SecurityAgencies
    * const securityAgencies = await prisma.securityAgency.findMany()
    * ```
    */
  get securityAgency(): Prisma.SecurityAgencyDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.giftShop`: Exposes CRUD operations for the **GiftShop** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more GiftShops
    * const giftShops = await prisma.giftShop.findMany()
    * ```
    */
  get giftShop(): Prisma.GiftShopDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.dJ`: Exposes CRUD operations for the **DJ** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more DJS
    * const dJS = await prisma.dJ.findMany()
    * ```
    */
  get dJ(): Prisma.DJDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.photographer`: Exposes CRUD operations for the **Photographer** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Photographers
    * const photographers = await prisma.photographer.findMany()
    * ```
    */
  get photographer(): Prisma.PhotographerDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eventType`: Exposes CRUD operations for the **EventType** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more EventTypes
    * const eventTypes = await prisma.eventType.findMany()
    * ```
    */
  get eventType(): Prisma.EventTypeDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vendor`: Exposes CRUD operations for the **Vendor** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Vendors
    * const vendors = await prisma.vendor.findMany()
    * ```
    */
  get vendor(): Prisma.VendorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.contentPage`: Exposes CRUD operations for the **ContentPage** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ContentPages
    * const contentPages = await prisma.contentPage.findMany()
    * ```
    */
  get contentPage(): Prisma.ContentPageDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.mediaItem`: Exposes CRUD operations for the **MediaItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MediaItems
    * const mediaItems = await prisma.mediaItem.findMany()
    * ```
    */
  get mediaItem(): Prisma.MediaItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.newsItem`: Exposes CRUD operations for the **NewsItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more NewsItems
    * const newsItems = await prisma.newsItem.findMany()
    * ```
    */
  get newsItem(): Prisma.NewsItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.student`: Exposes CRUD operations for the **Student** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Students
    * const students = await prisma.student.findMany()
    * ```
    */
  get student(): Prisma.StudentDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.17.1
   * Query Engine version: 272a37d34178c2894197e17273bf937f25acdeac
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Event: 'Event',
    Venue: 'Venue',
    LogisticsServiceProvider: 'LogisticsServiceProvider',
    CateringService: 'CateringService',
    SecurityAgency: 'SecurityAgency',
    GiftShop: 'GiftShop',
    DJ: 'DJ',
    Photographer: 'Photographer',
    EventType: 'EventType',
    Vendor: 'Vendor',
    ContentPage: 'ContentPage',
    MediaItem: 'MediaItem',
    NewsItem: 'NewsItem',
    Student: 'Student'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "event" | "venue" | "logisticsServiceProvider" | "cateringService" | "securityAgency" | "giftShop" | "dJ" | "photographer" | "eventType" | "vendor" | "contentPage" | "mediaItem" | "newsItem" | "student"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Event: {
        payload: Prisma.$EventPayload<ExtArgs>
        fields: Prisma.EventFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EventFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EventFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          findFirst: {
            args: Prisma.EventFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EventFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          findMany: {
            args: Prisma.EventFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>[]
          }
          create: {
            args: Prisma.EventCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          createMany: {
            args: Prisma.EventCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.EventDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          update: {
            args: Prisma.EventUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          deleteMany: {
            args: Prisma.EventDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EventUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.EventUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          aggregate: {
            args: Prisma.EventAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEvent>
          }
          groupBy: {
            args: Prisma.EventGroupByArgs<ExtArgs>
            result: $Utils.Optional<EventGroupByOutputType>[]
          }
          count: {
            args: Prisma.EventCountArgs<ExtArgs>
            result: $Utils.Optional<EventCountAggregateOutputType> | number
          }
        }
      }
      Venue: {
        payload: Prisma.$VenuePayload<ExtArgs>
        fields: Prisma.VenueFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VenueFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VenueFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          findFirst: {
            args: Prisma.VenueFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VenueFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          findMany: {
            args: Prisma.VenueFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>[]
          }
          create: {
            args: Prisma.VenueCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          createMany: {
            args: Prisma.VenueCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VenueDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          update: {
            args: Prisma.VenueUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          deleteMany: {
            args: Prisma.VenueDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VenueUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VenueUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VenuePayload>
          }
          aggregate: {
            args: Prisma.VenueAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVenue>
          }
          groupBy: {
            args: Prisma.VenueGroupByArgs<ExtArgs>
            result: $Utils.Optional<VenueGroupByOutputType>[]
          }
          count: {
            args: Prisma.VenueCountArgs<ExtArgs>
            result: $Utils.Optional<VenueCountAggregateOutputType> | number
          }
        }
      }
      LogisticsServiceProvider: {
        payload: Prisma.$LogisticsServiceProviderPayload<ExtArgs>
        fields: Prisma.LogisticsServiceProviderFieldRefs
        operations: {
          findUnique: {
            args: Prisma.LogisticsServiceProviderFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.LogisticsServiceProviderFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          findFirst: {
            args: Prisma.LogisticsServiceProviderFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.LogisticsServiceProviderFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          findMany: {
            args: Prisma.LogisticsServiceProviderFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>[]
          }
          create: {
            args: Prisma.LogisticsServiceProviderCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          createMany: {
            args: Prisma.LogisticsServiceProviderCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.LogisticsServiceProviderDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          update: {
            args: Prisma.LogisticsServiceProviderUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          deleteMany: {
            args: Prisma.LogisticsServiceProviderDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.LogisticsServiceProviderUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.LogisticsServiceProviderUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$LogisticsServiceProviderPayload>
          }
          aggregate: {
            args: Prisma.LogisticsServiceProviderAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateLogisticsServiceProvider>
          }
          groupBy: {
            args: Prisma.LogisticsServiceProviderGroupByArgs<ExtArgs>
            result: $Utils.Optional<LogisticsServiceProviderGroupByOutputType>[]
          }
          count: {
            args: Prisma.LogisticsServiceProviderCountArgs<ExtArgs>
            result: $Utils.Optional<LogisticsServiceProviderCountAggregateOutputType> | number
          }
        }
      }
      CateringService: {
        payload: Prisma.$CateringServicePayload<ExtArgs>
        fields: Prisma.CateringServiceFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CateringServiceFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CateringServiceFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          findFirst: {
            args: Prisma.CateringServiceFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CateringServiceFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          findMany: {
            args: Prisma.CateringServiceFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>[]
          }
          create: {
            args: Prisma.CateringServiceCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          createMany: {
            args: Prisma.CateringServiceCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.CateringServiceDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          update: {
            args: Prisma.CateringServiceUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          deleteMany: {
            args: Prisma.CateringServiceDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CateringServiceUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.CateringServiceUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CateringServicePayload>
          }
          aggregate: {
            args: Prisma.CateringServiceAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCateringService>
          }
          groupBy: {
            args: Prisma.CateringServiceGroupByArgs<ExtArgs>
            result: $Utils.Optional<CateringServiceGroupByOutputType>[]
          }
          count: {
            args: Prisma.CateringServiceCountArgs<ExtArgs>
            result: $Utils.Optional<CateringServiceCountAggregateOutputType> | number
          }
        }
      }
      SecurityAgency: {
        payload: Prisma.$SecurityAgencyPayload<ExtArgs>
        fields: Prisma.SecurityAgencyFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SecurityAgencyFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SecurityAgencyFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          findFirst: {
            args: Prisma.SecurityAgencyFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SecurityAgencyFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          findMany: {
            args: Prisma.SecurityAgencyFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>[]
          }
          create: {
            args: Prisma.SecurityAgencyCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          createMany: {
            args: Prisma.SecurityAgencyCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SecurityAgencyDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          update: {
            args: Prisma.SecurityAgencyUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          deleteMany: {
            args: Prisma.SecurityAgencyDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SecurityAgencyUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SecurityAgencyUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SecurityAgencyPayload>
          }
          aggregate: {
            args: Prisma.SecurityAgencyAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSecurityAgency>
          }
          groupBy: {
            args: Prisma.SecurityAgencyGroupByArgs<ExtArgs>
            result: $Utils.Optional<SecurityAgencyGroupByOutputType>[]
          }
          count: {
            args: Prisma.SecurityAgencyCountArgs<ExtArgs>
            result: $Utils.Optional<SecurityAgencyCountAggregateOutputType> | number
          }
        }
      }
      GiftShop: {
        payload: Prisma.$GiftShopPayload<ExtArgs>
        fields: Prisma.GiftShopFieldRefs
        operations: {
          findUnique: {
            args: Prisma.GiftShopFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.GiftShopFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          findFirst: {
            args: Prisma.GiftShopFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.GiftShopFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          findMany: {
            args: Prisma.GiftShopFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>[]
          }
          create: {
            args: Prisma.GiftShopCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          createMany: {
            args: Prisma.GiftShopCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.GiftShopDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          update: {
            args: Prisma.GiftShopUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          deleteMany: {
            args: Prisma.GiftShopDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.GiftShopUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.GiftShopUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GiftShopPayload>
          }
          aggregate: {
            args: Prisma.GiftShopAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateGiftShop>
          }
          groupBy: {
            args: Prisma.GiftShopGroupByArgs<ExtArgs>
            result: $Utils.Optional<GiftShopGroupByOutputType>[]
          }
          count: {
            args: Prisma.GiftShopCountArgs<ExtArgs>
            result: $Utils.Optional<GiftShopCountAggregateOutputType> | number
          }
        }
      }
      DJ: {
        payload: Prisma.$DJPayload<ExtArgs>
        fields: Prisma.DJFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DJFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DJFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          findFirst: {
            args: Prisma.DJFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DJFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          findMany: {
            args: Prisma.DJFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>[]
          }
          create: {
            args: Prisma.DJCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          createMany: {
            args: Prisma.DJCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.DJDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          update: {
            args: Prisma.DJUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          deleteMany: {
            args: Prisma.DJDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.DJUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.DJUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DJPayload>
          }
          aggregate: {
            args: Prisma.DJAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateDJ>
          }
          groupBy: {
            args: Prisma.DJGroupByArgs<ExtArgs>
            result: $Utils.Optional<DJGroupByOutputType>[]
          }
          count: {
            args: Prisma.DJCountArgs<ExtArgs>
            result: $Utils.Optional<DJCountAggregateOutputType> | number
          }
        }
      }
      Photographer: {
        payload: Prisma.$PhotographerPayload<ExtArgs>
        fields: Prisma.PhotographerFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PhotographerFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PhotographerFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          findFirst: {
            args: Prisma.PhotographerFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PhotographerFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          findMany: {
            args: Prisma.PhotographerFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>[]
          }
          create: {
            args: Prisma.PhotographerCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          createMany: {
            args: Prisma.PhotographerCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PhotographerDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          update: {
            args: Prisma.PhotographerUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          deleteMany: {
            args: Prisma.PhotographerDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PhotographerUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PhotographerUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotographerPayload>
          }
          aggregate: {
            args: Prisma.PhotographerAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePhotographer>
          }
          groupBy: {
            args: Prisma.PhotographerGroupByArgs<ExtArgs>
            result: $Utils.Optional<PhotographerGroupByOutputType>[]
          }
          count: {
            args: Prisma.PhotographerCountArgs<ExtArgs>
            result: $Utils.Optional<PhotographerCountAggregateOutputType> | number
          }
        }
      }
      EventType: {
        payload: Prisma.$EventTypePayload<ExtArgs>
        fields: Prisma.EventTypeFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EventTypeFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EventTypeFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          findFirst: {
            args: Prisma.EventTypeFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EventTypeFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          findMany: {
            args: Prisma.EventTypeFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>[]
          }
          create: {
            args: Prisma.EventTypeCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          createMany: {
            args: Prisma.EventTypeCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.EventTypeDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          update: {
            args: Prisma.EventTypeUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          deleteMany: {
            args: Prisma.EventTypeDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EventTypeUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.EventTypeUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventTypePayload>
          }
          aggregate: {
            args: Prisma.EventTypeAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEventType>
          }
          groupBy: {
            args: Prisma.EventTypeGroupByArgs<ExtArgs>
            result: $Utils.Optional<EventTypeGroupByOutputType>[]
          }
          count: {
            args: Prisma.EventTypeCountArgs<ExtArgs>
            result: $Utils.Optional<EventTypeCountAggregateOutputType> | number
          }
        }
      }
      Vendor: {
        payload: Prisma.$VendorPayload<ExtArgs>
        fields: Prisma.VendorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VendorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VendorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          findFirst: {
            args: Prisma.VendorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VendorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          findMany: {
            args: Prisma.VendorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>[]
          }
          create: {
            args: Prisma.VendorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          createMany: {
            args: Prisma.VendorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VendorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          update: {
            args: Prisma.VendorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          deleteMany: {
            args: Prisma.VendorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VendorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VendorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorPayload>
          }
          aggregate: {
            args: Prisma.VendorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVendor>
          }
          groupBy: {
            args: Prisma.VendorGroupByArgs<ExtArgs>
            result: $Utils.Optional<VendorGroupByOutputType>[]
          }
          count: {
            args: Prisma.VendorCountArgs<ExtArgs>
            result: $Utils.Optional<VendorCountAggregateOutputType> | number
          }
        }
      }
      ContentPage: {
        payload: Prisma.$ContentPagePayload<ExtArgs>
        fields: Prisma.ContentPageFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ContentPageFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ContentPageFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          findFirst: {
            args: Prisma.ContentPageFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ContentPageFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          findMany: {
            args: Prisma.ContentPageFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>[]
          }
          create: {
            args: Prisma.ContentPageCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          createMany: {
            args: Prisma.ContentPageCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ContentPageDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          update: {
            args: Prisma.ContentPageUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          deleteMany: {
            args: Prisma.ContentPageDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ContentPageUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ContentPageUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContentPagePayload>
          }
          aggregate: {
            args: Prisma.ContentPageAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateContentPage>
          }
          groupBy: {
            args: Prisma.ContentPageGroupByArgs<ExtArgs>
            result: $Utils.Optional<ContentPageGroupByOutputType>[]
          }
          count: {
            args: Prisma.ContentPageCountArgs<ExtArgs>
            result: $Utils.Optional<ContentPageCountAggregateOutputType> | number
          }
        }
      }
      MediaItem: {
        payload: Prisma.$MediaItemPayload<ExtArgs>
        fields: Prisma.MediaItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MediaItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MediaItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          findFirst: {
            args: Prisma.MediaItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MediaItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          findMany: {
            args: Prisma.MediaItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>[]
          }
          create: {
            args: Prisma.MediaItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          createMany: {
            args: Prisma.MediaItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.MediaItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          update: {
            args: Prisma.MediaItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          deleteMany: {
            args: Prisma.MediaItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MediaItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.MediaItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MediaItemPayload>
          }
          aggregate: {
            args: Prisma.MediaItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMediaItem>
          }
          groupBy: {
            args: Prisma.MediaItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<MediaItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.MediaItemCountArgs<ExtArgs>
            result: $Utils.Optional<MediaItemCountAggregateOutputType> | number
          }
        }
      }
      NewsItem: {
        payload: Prisma.$NewsItemPayload<ExtArgs>
        fields: Prisma.NewsItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.NewsItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.NewsItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          findFirst: {
            args: Prisma.NewsItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.NewsItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          findMany: {
            args: Prisma.NewsItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>[]
          }
          create: {
            args: Prisma.NewsItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          createMany: {
            args: Prisma.NewsItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.NewsItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          update: {
            args: Prisma.NewsItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          deleteMany: {
            args: Prisma.NewsItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.NewsItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.NewsItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NewsItemPayload>
          }
          aggregate: {
            args: Prisma.NewsItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateNewsItem>
          }
          groupBy: {
            args: Prisma.NewsItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<NewsItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.NewsItemCountArgs<ExtArgs>
            result: $Utils.Optional<NewsItemCountAggregateOutputType> | number
          }
        }
      }
      Student: {
        payload: Prisma.$StudentPayload<ExtArgs>
        fields: Prisma.StudentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.StudentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.StudentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          findFirst: {
            args: Prisma.StudentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.StudentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          findMany: {
            args: Prisma.StudentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>[]
          }
          create: {
            args: Prisma.StudentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          createMany: {
            args: Prisma.StudentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.StudentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          update: {
            args: Prisma.StudentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          deleteMany: {
            args: Prisma.StudentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.StudentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.StudentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StudentPayload>
          }
          aggregate: {
            args: Prisma.StudentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateStudent>
          }
          groupBy: {
            args: Prisma.StudentGroupByArgs<ExtArgs>
            result: $Utils.Optional<StudentGroupByOutputType>[]
          }
          count: {
            args: Prisma.StudentCountArgs<ExtArgs>
            result: $Utils.Optional<StudentCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    event?: EventOmit
    venue?: VenueOmit
    logisticsServiceProvider?: LogisticsServiceProviderOmit
    cateringService?: CateringServiceOmit
    securityAgency?: SecurityAgencyOmit
    giftShop?: GiftShopOmit
    dJ?: DJOmit
    photographer?: PhotographerOmit
    eventType?: EventTypeOmit
    vendor?: VendorOmit
    contentPage?: ContentPageOmit
    mediaItem?: MediaItemOmit
    newsItem?: NewsItemOmit
    student?: StudentOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    events: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    events?: boolean | UserCountOutputTypeCountEventsArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountEventsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EventWhereInput
  }


  /**
   * Count Type EventTypeCountOutputType
   */

  export type EventTypeCountOutputType = {
    venues: number
  }

  export type EventTypeCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    venues?: boolean | EventTypeCountOutputTypeCountVenuesArgs
  }

  // Custom InputTypes
  /**
   * EventTypeCountOutputType without action
   */
  export type EventTypeCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventTypeCountOutputType
     */
    select?: EventTypeCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * EventTypeCountOutputType without action
   */
  export type EventTypeCountOutputTypeCountVenuesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VenueWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    id: number | null
  }

  export type UserSumAggregateOutputType = {
    id: number | null
  }

  export type UserMinAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    password: string | null
    role: $Enums.Role | null
    createdAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    password: string | null
    role: $Enums.Role | null
    createdAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    name: number
    email: number
    password: number
    role: number
    createdAt: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    id?: true
  }

  export type UserSumAggregateInputType = {
    id?: true
  }

  export type UserMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    createdAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    createdAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    createdAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: number
    name: string
    email: string
    password: string
    role: $Enums.Role
    createdAt: Date
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
    createdAt?: boolean
    events?: boolean | User$eventsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>



  export type UserSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
    createdAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "password" | "role" | "createdAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    events?: boolean | User$eventsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      events: Prisma.$EventPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      email: string
      password: string
      role: $Enums.Role
      createdAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    events<T extends User$eventsArgs<ExtArgs> = {}>(args?: Subset<T, User$eventsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'Int'>
    readonly name: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.events
   */
  export type User$eventsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    where?: EventWhereInput
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    cursor?: EventWhereUniqueInput
    take?: number
    skip?: number
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Event
   */

  export type AggregateEvent = {
    _count: EventCountAggregateOutputType | null
    _avg: EventAvgAggregateOutputType | null
    _sum: EventSumAggregateOutputType | null
    _min: EventMinAggregateOutputType | null
    _max: EventMaxAggregateOutputType | null
  }

  export type EventAvgAggregateOutputType = {
    id: number | null
    studentId: number | null
  }

  export type EventSumAggregateOutputType = {
    id: number | null
    studentId: number | null
  }

  export type EventMinAggregateOutputType = {
    id: number | null
    title: string | null
    description: string | null
    date: Date | null
    location: string | null
    studentId: number | null
    status: $Enums.EventStatus | null
    createdAt: Date | null
  }

  export type EventMaxAggregateOutputType = {
    id: number | null
    title: string | null
    description: string | null
    date: Date | null
    location: string | null
    studentId: number | null
    status: $Enums.EventStatus | null
    createdAt: Date | null
  }

  export type EventCountAggregateOutputType = {
    id: number
    title: number
    description: number
    date: number
    location: number
    studentId: number
    status: number
    createdAt: number
    _all: number
  }


  export type EventAvgAggregateInputType = {
    id?: true
    studentId?: true
  }

  export type EventSumAggregateInputType = {
    id?: true
    studentId?: true
  }

  export type EventMinAggregateInputType = {
    id?: true
    title?: true
    description?: true
    date?: true
    location?: true
    studentId?: true
    status?: true
    createdAt?: true
  }

  export type EventMaxAggregateInputType = {
    id?: true
    title?: true
    description?: true
    date?: true
    location?: true
    studentId?: true
    status?: true
    createdAt?: true
  }

  export type EventCountAggregateInputType = {
    id?: true
    title?: true
    description?: true
    date?: true
    location?: true
    studentId?: true
    status?: true
    createdAt?: true
    _all?: true
  }

  export type EventAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Event to aggregate.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Events
    **/
    _count?: true | EventCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EventAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EventSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EventMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EventMaxAggregateInputType
  }

  export type GetEventAggregateType<T extends EventAggregateArgs> = {
        [P in keyof T & keyof AggregateEvent]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEvent[P]>
      : GetScalarType<T[P], AggregateEvent[P]>
  }




  export type EventGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EventWhereInput
    orderBy?: EventOrderByWithAggregationInput | EventOrderByWithAggregationInput[]
    by: EventScalarFieldEnum[] | EventScalarFieldEnum
    having?: EventScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EventCountAggregateInputType | true
    _avg?: EventAvgAggregateInputType
    _sum?: EventSumAggregateInputType
    _min?: EventMinAggregateInputType
    _max?: EventMaxAggregateInputType
  }

  export type EventGroupByOutputType = {
    id: number
    title: string
    description: string | null
    date: Date
    location: string
    studentId: number
    status: $Enums.EventStatus
    createdAt: Date
    _count: EventCountAggregateOutputType | null
    _avg: EventAvgAggregateOutputType | null
    _sum: EventSumAggregateOutputType | null
    _min: EventMinAggregateOutputType | null
    _max: EventMaxAggregateOutputType | null
  }

  type GetEventGroupByPayload<T extends EventGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EventGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EventGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EventGroupByOutputType[P]>
            : GetScalarType<T[P], EventGroupByOutputType[P]>
        }
      >
    >


  export type EventSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    description?: boolean
    date?: boolean
    location?: boolean
    studentId?: boolean
    status?: boolean
    createdAt?: boolean
    student?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["event"]>



  export type EventSelectScalar = {
    id?: boolean
    title?: boolean
    description?: boolean
    date?: boolean
    location?: boolean
    studentId?: boolean
    status?: boolean
    createdAt?: boolean
  }

  export type EventOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "title" | "description" | "date" | "location" | "studentId" | "status" | "createdAt", ExtArgs["result"]["event"]>
  export type EventInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    student?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $EventPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Event"
    objects: {
      student: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      title: string
      description: string | null
      date: Date
      location: string
      studentId: number
      status: $Enums.EventStatus
      createdAt: Date
    }, ExtArgs["result"]["event"]>
    composites: {}
  }

  type EventGetPayload<S extends boolean | null | undefined | EventDefaultArgs> = $Result.GetResult<Prisma.$EventPayload, S>

  type EventCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EventFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EventCountAggregateInputType | true
    }

  export interface EventDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Event'], meta: { name: 'Event' } }
    /**
     * Find zero or one Event that matches the filter.
     * @param {EventFindUniqueArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EventFindUniqueArgs>(args: SelectSubset<T, EventFindUniqueArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Event that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EventFindUniqueOrThrowArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EventFindUniqueOrThrowArgs>(args: SelectSubset<T, EventFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Event that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindFirstArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EventFindFirstArgs>(args?: SelectSubset<T, EventFindFirstArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Event that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindFirstOrThrowArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EventFindFirstOrThrowArgs>(args?: SelectSubset<T, EventFindFirstOrThrowArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Events that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Events
     * const events = await prisma.event.findMany()
     * 
     * // Get first 10 Events
     * const events = await prisma.event.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const eventWithIdOnly = await prisma.event.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EventFindManyArgs>(args?: SelectSubset<T, EventFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Event.
     * @param {EventCreateArgs} args - Arguments to create a Event.
     * @example
     * // Create one Event
     * const Event = await prisma.event.create({
     *   data: {
     *     // ... data to create a Event
     *   }
     * })
     * 
     */
    create<T extends EventCreateArgs>(args: SelectSubset<T, EventCreateArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Events.
     * @param {EventCreateManyArgs} args - Arguments to create many Events.
     * @example
     * // Create many Events
     * const event = await prisma.event.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EventCreateManyArgs>(args?: SelectSubset<T, EventCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Event.
     * @param {EventDeleteArgs} args - Arguments to delete one Event.
     * @example
     * // Delete one Event
     * const Event = await prisma.event.delete({
     *   where: {
     *     // ... filter to delete one Event
     *   }
     * })
     * 
     */
    delete<T extends EventDeleteArgs>(args: SelectSubset<T, EventDeleteArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Event.
     * @param {EventUpdateArgs} args - Arguments to update one Event.
     * @example
     * // Update one Event
     * const event = await prisma.event.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EventUpdateArgs>(args: SelectSubset<T, EventUpdateArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Events.
     * @param {EventDeleteManyArgs} args - Arguments to filter Events to delete.
     * @example
     * // Delete a few Events
     * const { count } = await prisma.event.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EventDeleteManyArgs>(args?: SelectSubset<T, EventDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Events.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Events
     * const event = await prisma.event.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EventUpdateManyArgs>(args: SelectSubset<T, EventUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Event.
     * @param {EventUpsertArgs} args - Arguments to update or create a Event.
     * @example
     * // Update or create a Event
     * const event = await prisma.event.upsert({
     *   create: {
     *     // ... data to create a Event
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Event we want to update
     *   }
     * })
     */
    upsert<T extends EventUpsertArgs>(args: SelectSubset<T, EventUpsertArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Events.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventCountArgs} args - Arguments to filter Events to count.
     * @example
     * // Count the number of Events
     * const count = await prisma.event.count({
     *   where: {
     *     // ... the filter for the Events we want to count
     *   }
     * })
    **/
    count<T extends EventCountArgs>(
      args?: Subset<T, EventCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EventCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Event.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EventAggregateArgs>(args: Subset<T, EventAggregateArgs>): Prisma.PrismaPromise<GetEventAggregateType<T>>

    /**
     * Group by Event.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EventGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EventGroupByArgs['orderBy'] }
        : { orderBy?: EventGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EventGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEventGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Event model
   */
  readonly fields: EventFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Event.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EventClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    student<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Event model
   */
  interface EventFieldRefs {
    readonly id: FieldRef<"Event", 'Int'>
    readonly title: FieldRef<"Event", 'String'>
    readonly description: FieldRef<"Event", 'String'>
    readonly date: FieldRef<"Event", 'DateTime'>
    readonly location: FieldRef<"Event", 'String'>
    readonly studentId: FieldRef<"Event", 'Int'>
    readonly status: FieldRef<"Event", 'EventStatus'>
    readonly createdAt: FieldRef<"Event", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Event findUnique
   */
  export type EventFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event findUniqueOrThrow
   */
  export type EventFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event findFirst
   */
  export type EventFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Events.
     */
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event findFirstOrThrow
   */
  export type EventFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Events.
     */
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event findMany
   */
  export type EventFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter, which Events to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event create
   */
  export type EventCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * The data needed to create a Event.
     */
    data: XOR<EventCreateInput, EventUncheckedCreateInput>
  }

  /**
   * Event createMany
   */
  export type EventCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Events.
     */
    data: EventCreateManyInput | EventCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Event update
   */
  export type EventUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * The data needed to update a Event.
     */
    data: XOR<EventUpdateInput, EventUncheckedUpdateInput>
    /**
     * Choose, which Event to update.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event updateMany
   */
  export type EventUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Events.
     */
    data: XOR<EventUpdateManyMutationInput, EventUncheckedUpdateManyInput>
    /**
     * Filter which Events to update
     */
    where?: EventWhereInput
    /**
     * Limit how many Events to update.
     */
    limit?: number
  }

  /**
   * Event upsert
   */
  export type EventUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * The filter to search for the Event to update in case it exists.
     */
    where: EventWhereUniqueInput
    /**
     * In case the Event found by the `where` argument doesn't exist, create a new Event with this data.
     */
    create: XOR<EventCreateInput, EventUncheckedCreateInput>
    /**
     * In case the Event was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EventUpdateInput, EventUncheckedUpdateInput>
  }

  /**
   * Event delete
   */
  export type EventDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
    /**
     * Filter which Event to delete.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event deleteMany
   */
  export type EventDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Events to delete
     */
    where?: EventWhereInput
    /**
     * Limit how many Events to delete.
     */
    limit?: number
  }

  /**
   * Event without action
   */
  export type EventDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventInclude<ExtArgs> | null
  }


  /**
   * Model Venue
   */

  export type AggregateVenue = {
    _count: VenueCountAggregateOutputType | null
    _avg: VenueAvgAggregateOutputType | null
    _sum: VenueSumAggregateOutputType | null
    _min: VenueMinAggregateOutputType | null
    _max: VenueMaxAggregateOutputType | null
  }

  export type VenueAvgAggregateOutputType = {
    id: number | null
    capacity: number | null
    bookings: number | null
    eventTypeId: number | null
  }

  export type VenueSumAggregateOutputType = {
    id: number | null
    capacity: number | null
    bookings: number | null
    eventTypeId: number | null
  }

  export type VenueMinAggregateOutputType = {
    id: number | null
    name: string | null
    capacity: number | null
    location: string | null
    status: $Enums.VenueStatus | null
    bookings: number | null
    description: string | null
    amenities: string | null
    eventTypeId: number | null
    createdAt: Date | null
  }

  export type VenueMaxAggregateOutputType = {
    id: number | null
    name: string | null
    capacity: number | null
    location: string | null
    status: $Enums.VenueStatus | null
    bookings: number | null
    description: string | null
    amenities: string | null
    eventTypeId: number | null
    createdAt: Date | null
  }

  export type VenueCountAggregateOutputType = {
    id: number
    name: number
    capacity: number
    location: number
    status: number
    bookings: number
    description: number
    amenities: number
    eventTypeId: number
    createdAt: number
    _all: number
  }


  export type VenueAvgAggregateInputType = {
    id?: true
    capacity?: true
    bookings?: true
    eventTypeId?: true
  }

  export type VenueSumAggregateInputType = {
    id?: true
    capacity?: true
    bookings?: true
    eventTypeId?: true
  }

  export type VenueMinAggregateInputType = {
    id?: true
    name?: true
    capacity?: true
    location?: true
    status?: true
    bookings?: true
    description?: true
    amenities?: true
    eventTypeId?: true
    createdAt?: true
  }

  export type VenueMaxAggregateInputType = {
    id?: true
    name?: true
    capacity?: true
    location?: true
    status?: true
    bookings?: true
    description?: true
    amenities?: true
    eventTypeId?: true
    createdAt?: true
  }

  export type VenueCountAggregateInputType = {
    id?: true
    name?: true
    capacity?: true
    location?: true
    status?: true
    bookings?: true
    description?: true
    amenities?: true
    eventTypeId?: true
    createdAt?: true
    _all?: true
  }

  export type VenueAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Venue to aggregate.
     */
    where?: VenueWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Venues to fetch.
     */
    orderBy?: VenueOrderByWithRelationInput | VenueOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VenueWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Venues from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Venues.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Venues
    **/
    _count?: true | VenueCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VenueAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VenueSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VenueMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VenueMaxAggregateInputType
  }

  export type GetVenueAggregateType<T extends VenueAggregateArgs> = {
        [P in keyof T & keyof AggregateVenue]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVenue[P]>
      : GetScalarType<T[P], AggregateVenue[P]>
  }




  export type VenueGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VenueWhereInput
    orderBy?: VenueOrderByWithAggregationInput | VenueOrderByWithAggregationInput[]
    by: VenueScalarFieldEnum[] | VenueScalarFieldEnum
    having?: VenueScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VenueCountAggregateInputType | true
    _avg?: VenueAvgAggregateInputType
    _sum?: VenueSumAggregateInputType
    _min?: VenueMinAggregateInputType
    _max?: VenueMaxAggregateInputType
  }

  export type VenueGroupByOutputType = {
    id: number
    name: string
    capacity: number
    location: string
    status: $Enums.VenueStatus
    bookings: number
    description: string | null
    amenities: string | null
    eventTypeId: number | null
    createdAt: Date
    _count: VenueCountAggregateOutputType | null
    _avg: VenueAvgAggregateOutputType | null
    _sum: VenueSumAggregateOutputType | null
    _min: VenueMinAggregateOutputType | null
    _max: VenueMaxAggregateOutputType | null
  }

  type GetVenueGroupByPayload<T extends VenueGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VenueGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VenueGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VenueGroupByOutputType[P]>
            : GetScalarType<T[P], VenueGroupByOutputType[P]>
        }
      >
    >


  export type VenueSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    capacity?: boolean
    location?: boolean
    status?: boolean
    bookings?: boolean
    description?: boolean
    amenities?: boolean
    eventTypeId?: boolean
    createdAt?: boolean
    eventType?: boolean | Venue$eventTypeArgs<ExtArgs>
  }, ExtArgs["result"]["venue"]>



  export type VenueSelectScalar = {
    id?: boolean
    name?: boolean
    capacity?: boolean
    location?: boolean
    status?: boolean
    bookings?: boolean
    description?: boolean
    amenities?: boolean
    eventTypeId?: boolean
    createdAt?: boolean
  }

  export type VenueOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "capacity" | "location" | "status" | "bookings" | "description" | "amenities" | "eventTypeId" | "createdAt", ExtArgs["result"]["venue"]>
  export type VenueInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    eventType?: boolean | Venue$eventTypeArgs<ExtArgs>
  }

  export type $VenuePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Venue"
    objects: {
      eventType: Prisma.$EventTypePayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      capacity: number
      location: string
      status: $Enums.VenueStatus
      bookings: number
      description: string | null
      amenities: string | null
      eventTypeId: number | null
      createdAt: Date
    }, ExtArgs["result"]["venue"]>
    composites: {}
  }

  type VenueGetPayload<S extends boolean | null | undefined | VenueDefaultArgs> = $Result.GetResult<Prisma.$VenuePayload, S>

  type VenueCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VenueFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VenueCountAggregateInputType | true
    }

  export interface VenueDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Venue'], meta: { name: 'Venue' } }
    /**
     * Find zero or one Venue that matches the filter.
     * @param {VenueFindUniqueArgs} args - Arguments to find a Venue
     * @example
     * // Get one Venue
     * const venue = await prisma.venue.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VenueFindUniqueArgs>(args: SelectSubset<T, VenueFindUniqueArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Venue that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VenueFindUniqueOrThrowArgs} args - Arguments to find a Venue
     * @example
     * // Get one Venue
     * const venue = await prisma.venue.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VenueFindUniqueOrThrowArgs>(args: SelectSubset<T, VenueFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Venue that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueFindFirstArgs} args - Arguments to find a Venue
     * @example
     * // Get one Venue
     * const venue = await prisma.venue.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VenueFindFirstArgs>(args?: SelectSubset<T, VenueFindFirstArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Venue that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueFindFirstOrThrowArgs} args - Arguments to find a Venue
     * @example
     * // Get one Venue
     * const venue = await prisma.venue.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VenueFindFirstOrThrowArgs>(args?: SelectSubset<T, VenueFindFirstOrThrowArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Venues that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Venues
     * const venues = await prisma.venue.findMany()
     * 
     * // Get first 10 Venues
     * const venues = await prisma.venue.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const venueWithIdOnly = await prisma.venue.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VenueFindManyArgs>(args?: SelectSubset<T, VenueFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Venue.
     * @param {VenueCreateArgs} args - Arguments to create a Venue.
     * @example
     * // Create one Venue
     * const Venue = await prisma.venue.create({
     *   data: {
     *     // ... data to create a Venue
     *   }
     * })
     * 
     */
    create<T extends VenueCreateArgs>(args: SelectSubset<T, VenueCreateArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Venues.
     * @param {VenueCreateManyArgs} args - Arguments to create many Venues.
     * @example
     * // Create many Venues
     * const venue = await prisma.venue.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VenueCreateManyArgs>(args?: SelectSubset<T, VenueCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Venue.
     * @param {VenueDeleteArgs} args - Arguments to delete one Venue.
     * @example
     * // Delete one Venue
     * const Venue = await prisma.venue.delete({
     *   where: {
     *     // ... filter to delete one Venue
     *   }
     * })
     * 
     */
    delete<T extends VenueDeleteArgs>(args: SelectSubset<T, VenueDeleteArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Venue.
     * @param {VenueUpdateArgs} args - Arguments to update one Venue.
     * @example
     * // Update one Venue
     * const venue = await prisma.venue.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VenueUpdateArgs>(args: SelectSubset<T, VenueUpdateArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Venues.
     * @param {VenueDeleteManyArgs} args - Arguments to filter Venues to delete.
     * @example
     * // Delete a few Venues
     * const { count } = await prisma.venue.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VenueDeleteManyArgs>(args?: SelectSubset<T, VenueDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Venues.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Venues
     * const venue = await prisma.venue.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VenueUpdateManyArgs>(args: SelectSubset<T, VenueUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Venue.
     * @param {VenueUpsertArgs} args - Arguments to update or create a Venue.
     * @example
     * // Update or create a Venue
     * const venue = await prisma.venue.upsert({
     *   create: {
     *     // ... data to create a Venue
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Venue we want to update
     *   }
     * })
     */
    upsert<T extends VenueUpsertArgs>(args: SelectSubset<T, VenueUpsertArgs<ExtArgs>>): Prisma__VenueClient<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Venues.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueCountArgs} args - Arguments to filter Venues to count.
     * @example
     * // Count the number of Venues
     * const count = await prisma.venue.count({
     *   where: {
     *     // ... the filter for the Venues we want to count
     *   }
     * })
    **/
    count<T extends VenueCountArgs>(
      args?: Subset<T, VenueCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VenueCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Venue.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VenueAggregateArgs>(args: Subset<T, VenueAggregateArgs>): Prisma.PrismaPromise<GetVenueAggregateType<T>>

    /**
     * Group by Venue.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VenueGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VenueGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VenueGroupByArgs['orderBy'] }
        : { orderBy?: VenueGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VenueGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVenueGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Venue model
   */
  readonly fields: VenueFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Venue.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VenueClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    eventType<T extends Venue$eventTypeArgs<ExtArgs> = {}>(args?: Subset<T, Venue$eventTypeArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Venue model
   */
  interface VenueFieldRefs {
    readonly id: FieldRef<"Venue", 'Int'>
    readonly name: FieldRef<"Venue", 'String'>
    readonly capacity: FieldRef<"Venue", 'Int'>
    readonly location: FieldRef<"Venue", 'String'>
    readonly status: FieldRef<"Venue", 'VenueStatus'>
    readonly bookings: FieldRef<"Venue", 'Int'>
    readonly description: FieldRef<"Venue", 'String'>
    readonly amenities: FieldRef<"Venue", 'String'>
    readonly eventTypeId: FieldRef<"Venue", 'Int'>
    readonly createdAt: FieldRef<"Venue", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Venue findUnique
   */
  export type VenueFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter, which Venue to fetch.
     */
    where: VenueWhereUniqueInput
  }

  /**
   * Venue findUniqueOrThrow
   */
  export type VenueFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter, which Venue to fetch.
     */
    where: VenueWhereUniqueInput
  }

  /**
   * Venue findFirst
   */
  export type VenueFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter, which Venue to fetch.
     */
    where?: VenueWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Venues to fetch.
     */
    orderBy?: VenueOrderByWithRelationInput | VenueOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Venues.
     */
    cursor?: VenueWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Venues from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Venues.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Venues.
     */
    distinct?: VenueScalarFieldEnum | VenueScalarFieldEnum[]
  }

  /**
   * Venue findFirstOrThrow
   */
  export type VenueFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter, which Venue to fetch.
     */
    where?: VenueWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Venues to fetch.
     */
    orderBy?: VenueOrderByWithRelationInput | VenueOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Venues.
     */
    cursor?: VenueWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Venues from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Venues.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Venues.
     */
    distinct?: VenueScalarFieldEnum | VenueScalarFieldEnum[]
  }

  /**
   * Venue findMany
   */
  export type VenueFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter, which Venues to fetch.
     */
    where?: VenueWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Venues to fetch.
     */
    orderBy?: VenueOrderByWithRelationInput | VenueOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Venues.
     */
    cursor?: VenueWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Venues from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Venues.
     */
    skip?: number
    distinct?: VenueScalarFieldEnum | VenueScalarFieldEnum[]
  }

  /**
   * Venue create
   */
  export type VenueCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * The data needed to create a Venue.
     */
    data: XOR<VenueCreateInput, VenueUncheckedCreateInput>
  }

  /**
   * Venue createMany
   */
  export type VenueCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Venues.
     */
    data: VenueCreateManyInput | VenueCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Venue update
   */
  export type VenueUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * The data needed to update a Venue.
     */
    data: XOR<VenueUpdateInput, VenueUncheckedUpdateInput>
    /**
     * Choose, which Venue to update.
     */
    where: VenueWhereUniqueInput
  }

  /**
   * Venue updateMany
   */
  export type VenueUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Venues.
     */
    data: XOR<VenueUpdateManyMutationInput, VenueUncheckedUpdateManyInput>
    /**
     * Filter which Venues to update
     */
    where?: VenueWhereInput
    /**
     * Limit how many Venues to update.
     */
    limit?: number
  }

  /**
   * Venue upsert
   */
  export type VenueUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * The filter to search for the Venue to update in case it exists.
     */
    where: VenueWhereUniqueInput
    /**
     * In case the Venue found by the `where` argument doesn't exist, create a new Venue with this data.
     */
    create: XOR<VenueCreateInput, VenueUncheckedCreateInput>
    /**
     * In case the Venue was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VenueUpdateInput, VenueUncheckedUpdateInput>
  }

  /**
   * Venue delete
   */
  export type VenueDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    /**
     * Filter which Venue to delete.
     */
    where: VenueWhereUniqueInput
  }

  /**
   * Venue deleteMany
   */
  export type VenueDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Venues to delete
     */
    where?: VenueWhereInput
    /**
     * Limit how many Venues to delete.
     */
    limit?: number
  }

  /**
   * Venue.eventType
   */
  export type Venue$eventTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    where?: EventTypeWhereInput
  }

  /**
   * Venue without action
   */
  export type VenueDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
  }


  /**
   * Model LogisticsServiceProvider
   */

  export type AggregateLogisticsServiceProvider = {
    _count: LogisticsServiceProviderCountAggregateOutputType | null
    _avg: LogisticsServiceProviderAvgAggregateOutputType | null
    _sum: LogisticsServiceProviderSumAggregateOutputType | null
    _min: LogisticsServiceProviderMinAggregateOutputType | null
    _max: LogisticsServiceProviderMaxAggregateOutputType | null
  }

  export type LogisticsServiceProviderAvgAggregateOutputType = {
    id: number | null
  }

  export type LogisticsServiceProviderSumAggregateOutputType = {
    id: number | null
  }

  export type LogisticsServiceProviderMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type LogisticsServiceProviderMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type LogisticsServiceProviderCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type LogisticsServiceProviderAvgAggregateInputType = {
    id?: true
  }

  export type LogisticsServiceProviderSumAggregateInputType = {
    id?: true
  }

  export type LogisticsServiceProviderMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type LogisticsServiceProviderMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type LogisticsServiceProviderCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type LogisticsServiceProviderAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which LogisticsServiceProvider to aggregate.
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LogisticsServiceProviders to fetch.
     */
    orderBy?: LogisticsServiceProviderOrderByWithRelationInput | LogisticsServiceProviderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: LogisticsServiceProviderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LogisticsServiceProviders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LogisticsServiceProviders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned LogisticsServiceProviders
    **/
    _count?: true | LogisticsServiceProviderCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: LogisticsServiceProviderAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: LogisticsServiceProviderSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: LogisticsServiceProviderMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: LogisticsServiceProviderMaxAggregateInputType
  }

  export type GetLogisticsServiceProviderAggregateType<T extends LogisticsServiceProviderAggregateArgs> = {
        [P in keyof T & keyof AggregateLogisticsServiceProvider]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateLogisticsServiceProvider[P]>
      : GetScalarType<T[P], AggregateLogisticsServiceProvider[P]>
  }




  export type LogisticsServiceProviderGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: LogisticsServiceProviderWhereInput
    orderBy?: LogisticsServiceProviderOrderByWithAggregationInput | LogisticsServiceProviderOrderByWithAggregationInput[]
    by: LogisticsServiceProviderScalarFieldEnum[] | LogisticsServiceProviderScalarFieldEnum
    having?: LogisticsServiceProviderScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: LogisticsServiceProviderCountAggregateInputType | true
    _avg?: LogisticsServiceProviderAvgAggregateInputType
    _sum?: LogisticsServiceProviderSumAggregateInputType
    _min?: LogisticsServiceProviderMinAggregateInputType
    _max?: LogisticsServiceProviderMaxAggregateInputType
  }

  export type LogisticsServiceProviderGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: LogisticsServiceProviderCountAggregateOutputType | null
    _avg: LogisticsServiceProviderAvgAggregateOutputType | null
    _sum: LogisticsServiceProviderSumAggregateOutputType | null
    _min: LogisticsServiceProviderMinAggregateOutputType | null
    _max: LogisticsServiceProviderMaxAggregateOutputType | null
  }

  type GetLogisticsServiceProviderGroupByPayload<T extends LogisticsServiceProviderGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<LogisticsServiceProviderGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof LogisticsServiceProviderGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], LogisticsServiceProviderGroupByOutputType[P]>
            : GetScalarType<T[P], LogisticsServiceProviderGroupByOutputType[P]>
        }
      >
    >


  export type LogisticsServiceProviderSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["logisticsServiceProvider"]>



  export type LogisticsServiceProviderSelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type LogisticsServiceProviderOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["logisticsServiceProvider"]>

  export type $LogisticsServiceProviderPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "LogisticsServiceProvider"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["logisticsServiceProvider"]>
    composites: {}
  }

  type LogisticsServiceProviderGetPayload<S extends boolean | null | undefined | LogisticsServiceProviderDefaultArgs> = $Result.GetResult<Prisma.$LogisticsServiceProviderPayload, S>

  type LogisticsServiceProviderCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<LogisticsServiceProviderFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: LogisticsServiceProviderCountAggregateInputType | true
    }

  export interface LogisticsServiceProviderDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['LogisticsServiceProvider'], meta: { name: 'LogisticsServiceProvider' } }
    /**
     * Find zero or one LogisticsServiceProvider that matches the filter.
     * @param {LogisticsServiceProviderFindUniqueArgs} args - Arguments to find a LogisticsServiceProvider
     * @example
     * // Get one LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends LogisticsServiceProviderFindUniqueArgs>(args: SelectSubset<T, LogisticsServiceProviderFindUniqueArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one LogisticsServiceProvider that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {LogisticsServiceProviderFindUniqueOrThrowArgs} args - Arguments to find a LogisticsServiceProvider
     * @example
     * // Get one LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends LogisticsServiceProviderFindUniqueOrThrowArgs>(args: SelectSubset<T, LogisticsServiceProviderFindUniqueOrThrowArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first LogisticsServiceProvider that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderFindFirstArgs} args - Arguments to find a LogisticsServiceProvider
     * @example
     * // Get one LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends LogisticsServiceProviderFindFirstArgs>(args?: SelectSubset<T, LogisticsServiceProviderFindFirstArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first LogisticsServiceProvider that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderFindFirstOrThrowArgs} args - Arguments to find a LogisticsServiceProvider
     * @example
     * // Get one LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends LogisticsServiceProviderFindFirstOrThrowArgs>(args?: SelectSubset<T, LogisticsServiceProviderFindFirstOrThrowArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more LogisticsServiceProviders that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all LogisticsServiceProviders
     * const logisticsServiceProviders = await prisma.logisticsServiceProvider.findMany()
     * 
     * // Get first 10 LogisticsServiceProviders
     * const logisticsServiceProviders = await prisma.logisticsServiceProvider.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const logisticsServiceProviderWithIdOnly = await prisma.logisticsServiceProvider.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends LogisticsServiceProviderFindManyArgs>(args?: SelectSubset<T, LogisticsServiceProviderFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a LogisticsServiceProvider.
     * @param {LogisticsServiceProviderCreateArgs} args - Arguments to create a LogisticsServiceProvider.
     * @example
     * // Create one LogisticsServiceProvider
     * const LogisticsServiceProvider = await prisma.logisticsServiceProvider.create({
     *   data: {
     *     // ... data to create a LogisticsServiceProvider
     *   }
     * })
     * 
     */
    create<T extends LogisticsServiceProviderCreateArgs>(args: SelectSubset<T, LogisticsServiceProviderCreateArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many LogisticsServiceProviders.
     * @param {LogisticsServiceProviderCreateManyArgs} args - Arguments to create many LogisticsServiceProviders.
     * @example
     * // Create many LogisticsServiceProviders
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends LogisticsServiceProviderCreateManyArgs>(args?: SelectSubset<T, LogisticsServiceProviderCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a LogisticsServiceProvider.
     * @param {LogisticsServiceProviderDeleteArgs} args - Arguments to delete one LogisticsServiceProvider.
     * @example
     * // Delete one LogisticsServiceProvider
     * const LogisticsServiceProvider = await prisma.logisticsServiceProvider.delete({
     *   where: {
     *     // ... filter to delete one LogisticsServiceProvider
     *   }
     * })
     * 
     */
    delete<T extends LogisticsServiceProviderDeleteArgs>(args: SelectSubset<T, LogisticsServiceProviderDeleteArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one LogisticsServiceProvider.
     * @param {LogisticsServiceProviderUpdateArgs} args - Arguments to update one LogisticsServiceProvider.
     * @example
     * // Update one LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends LogisticsServiceProviderUpdateArgs>(args: SelectSubset<T, LogisticsServiceProviderUpdateArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more LogisticsServiceProviders.
     * @param {LogisticsServiceProviderDeleteManyArgs} args - Arguments to filter LogisticsServiceProviders to delete.
     * @example
     * // Delete a few LogisticsServiceProviders
     * const { count } = await prisma.logisticsServiceProvider.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends LogisticsServiceProviderDeleteManyArgs>(args?: SelectSubset<T, LogisticsServiceProviderDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more LogisticsServiceProviders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many LogisticsServiceProviders
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends LogisticsServiceProviderUpdateManyArgs>(args: SelectSubset<T, LogisticsServiceProviderUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one LogisticsServiceProvider.
     * @param {LogisticsServiceProviderUpsertArgs} args - Arguments to update or create a LogisticsServiceProvider.
     * @example
     * // Update or create a LogisticsServiceProvider
     * const logisticsServiceProvider = await prisma.logisticsServiceProvider.upsert({
     *   create: {
     *     // ... data to create a LogisticsServiceProvider
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the LogisticsServiceProvider we want to update
     *   }
     * })
     */
    upsert<T extends LogisticsServiceProviderUpsertArgs>(args: SelectSubset<T, LogisticsServiceProviderUpsertArgs<ExtArgs>>): Prisma__LogisticsServiceProviderClient<$Result.GetResult<Prisma.$LogisticsServiceProviderPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of LogisticsServiceProviders.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderCountArgs} args - Arguments to filter LogisticsServiceProviders to count.
     * @example
     * // Count the number of LogisticsServiceProviders
     * const count = await prisma.logisticsServiceProvider.count({
     *   where: {
     *     // ... the filter for the LogisticsServiceProviders we want to count
     *   }
     * })
    **/
    count<T extends LogisticsServiceProviderCountArgs>(
      args?: Subset<T, LogisticsServiceProviderCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], LogisticsServiceProviderCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a LogisticsServiceProvider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends LogisticsServiceProviderAggregateArgs>(args: Subset<T, LogisticsServiceProviderAggregateArgs>): Prisma.PrismaPromise<GetLogisticsServiceProviderAggregateType<T>>

    /**
     * Group by LogisticsServiceProvider.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LogisticsServiceProviderGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends LogisticsServiceProviderGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: LogisticsServiceProviderGroupByArgs['orderBy'] }
        : { orderBy?: LogisticsServiceProviderGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, LogisticsServiceProviderGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetLogisticsServiceProviderGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the LogisticsServiceProvider model
   */
  readonly fields: LogisticsServiceProviderFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for LogisticsServiceProvider.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__LogisticsServiceProviderClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the LogisticsServiceProvider model
   */
  interface LogisticsServiceProviderFieldRefs {
    readonly id: FieldRef<"LogisticsServiceProvider", 'Int'>
    readonly name: FieldRef<"LogisticsServiceProvider", 'String'>
    readonly contact: FieldRef<"LogisticsServiceProvider", 'String'>
    readonly location: FieldRef<"LogisticsServiceProvider", 'String'>
    readonly createdAt: FieldRef<"LogisticsServiceProvider", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * LogisticsServiceProvider findUnique
   */
  export type LogisticsServiceProviderFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter, which LogisticsServiceProvider to fetch.
     */
    where: LogisticsServiceProviderWhereUniqueInput
  }

  /**
   * LogisticsServiceProvider findUniqueOrThrow
   */
  export type LogisticsServiceProviderFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter, which LogisticsServiceProvider to fetch.
     */
    where: LogisticsServiceProviderWhereUniqueInput
  }

  /**
   * LogisticsServiceProvider findFirst
   */
  export type LogisticsServiceProviderFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter, which LogisticsServiceProvider to fetch.
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LogisticsServiceProviders to fetch.
     */
    orderBy?: LogisticsServiceProviderOrderByWithRelationInput | LogisticsServiceProviderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LogisticsServiceProviders.
     */
    cursor?: LogisticsServiceProviderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LogisticsServiceProviders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LogisticsServiceProviders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LogisticsServiceProviders.
     */
    distinct?: LogisticsServiceProviderScalarFieldEnum | LogisticsServiceProviderScalarFieldEnum[]
  }

  /**
   * LogisticsServiceProvider findFirstOrThrow
   */
  export type LogisticsServiceProviderFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter, which LogisticsServiceProvider to fetch.
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LogisticsServiceProviders to fetch.
     */
    orderBy?: LogisticsServiceProviderOrderByWithRelationInput | LogisticsServiceProviderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LogisticsServiceProviders.
     */
    cursor?: LogisticsServiceProviderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LogisticsServiceProviders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LogisticsServiceProviders.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LogisticsServiceProviders.
     */
    distinct?: LogisticsServiceProviderScalarFieldEnum | LogisticsServiceProviderScalarFieldEnum[]
  }

  /**
   * LogisticsServiceProvider findMany
   */
  export type LogisticsServiceProviderFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter, which LogisticsServiceProviders to fetch.
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LogisticsServiceProviders to fetch.
     */
    orderBy?: LogisticsServiceProviderOrderByWithRelationInput | LogisticsServiceProviderOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing LogisticsServiceProviders.
     */
    cursor?: LogisticsServiceProviderWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LogisticsServiceProviders from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LogisticsServiceProviders.
     */
    skip?: number
    distinct?: LogisticsServiceProviderScalarFieldEnum | LogisticsServiceProviderScalarFieldEnum[]
  }

  /**
   * LogisticsServiceProvider create
   */
  export type LogisticsServiceProviderCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * The data needed to create a LogisticsServiceProvider.
     */
    data: XOR<LogisticsServiceProviderCreateInput, LogisticsServiceProviderUncheckedCreateInput>
  }

  /**
   * LogisticsServiceProvider createMany
   */
  export type LogisticsServiceProviderCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many LogisticsServiceProviders.
     */
    data: LogisticsServiceProviderCreateManyInput | LogisticsServiceProviderCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * LogisticsServiceProvider update
   */
  export type LogisticsServiceProviderUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * The data needed to update a LogisticsServiceProvider.
     */
    data: XOR<LogisticsServiceProviderUpdateInput, LogisticsServiceProviderUncheckedUpdateInput>
    /**
     * Choose, which LogisticsServiceProvider to update.
     */
    where: LogisticsServiceProviderWhereUniqueInput
  }

  /**
   * LogisticsServiceProvider updateMany
   */
  export type LogisticsServiceProviderUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update LogisticsServiceProviders.
     */
    data: XOR<LogisticsServiceProviderUpdateManyMutationInput, LogisticsServiceProviderUncheckedUpdateManyInput>
    /**
     * Filter which LogisticsServiceProviders to update
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * Limit how many LogisticsServiceProviders to update.
     */
    limit?: number
  }

  /**
   * LogisticsServiceProvider upsert
   */
  export type LogisticsServiceProviderUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * The filter to search for the LogisticsServiceProvider to update in case it exists.
     */
    where: LogisticsServiceProviderWhereUniqueInput
    /**
     * In case the LogisticsServiceProvider found by the `where` argument doesn't exist, create a new LogisticsServiceProvider with this data.
     */
    create: XOR<LogisticsServiceProviderCreateInput, LogisticsServiceProviderUncheckedCreateInput>
    /**
     * In case the LogisticsServiceProvider was found with the provided `where` argument, update it with this data.
     */
    update: XOR<LogisticsServiceProviderUpdateInput, LogisticsServiceProviderUncheckedUpdateInput>
  }

  /**
   * LogisticsServiceProvider delete
   */
  export type LogisticsServiceProviderDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
    /**
     * Filter which LogisticsServiceProvider to delete.
     */
    where: LogisticsServiceProviderWhereUniqueInput
  }

  /**
   * LogisticsServiceProvider deleteMany
   */
  export type LogisticsServiceProviderDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which LogisticsServiceProviders to delete
     */
    where?: LogisticsServiceProviderWhereInput
    /**
     * Limit how many LogisticsServiceProviders to delete.
     */
    limit?: number
  }

  /**
   * LogisticsServiceProvider without action
   */
  export type LogisticsServiceProviderDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LogisticsServiceProvider
     */
    select?: LogisticsServiceProviderSelect<ExtArgs> | null
    /**
     * Omit specific fields from the LogisticsServiceProvider
     */
    omit?: LogisticsServiceProviderOmit<ExtArgs> | null
  }


  /**
   * Model CateringService
   */

  export type AggregateCateringService = {
    _count: CateringServiceCountAggregateOutputType | null
    _avg: CateringServiceAvgAggregateOutputType | null
    _sum: CateringServiceSumAggregateOutputType | null
    _min: CateringServiceMinAggregateOutputType | null
    _max: CateringServiceMaxAggregateOutputType | null
  }

  export type CateringServiceAvgAggregateOutputType = {
    id: number | null
  }

  export type CateringServiceSumAggregateOutputType = {
    id: number | null
  }

  export type CateringServiceMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type CateringServiceMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type CateringServiceCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type CateringServiceAvgAggregateInputType = {
    id?: true
  }

  export type CateringServiceSumAggregateInputType = {
    id?: true
  }

  export type CateringServiceMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type CateringServiceMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type CateringServiceCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type CateringServiceAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CateringService to aggregate.
     */
    where?: CateringServiceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CateringServices to fetch.
     */
    orderBy?: CateringServiceOrderByWithRelationInput | CateringServiceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CateringServiceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CateringServices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CateringServices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CateringServices
    **/
    _count?: true | CateringServiceCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CateringServiceAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CateringServiceSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CateringServiceMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CateringServiceMaxAggregateInputType
  }

  export type GetCateringServiceAggregateType<T extends CateringServiceAggregateArgs> = {
        [P in keyof T & keyof AggregateCateringService]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCateringService[P]>
      : GetScalarType<T[P], AggregateCateringService[P]>
  }




  export type CateringServiceGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CateringServiceWhereInput
    orderBy?: CateringServiceOrderByWithAggregationInput | CateringServiceOrderByWithAggregationInput[]
    by: CateringServiceScalarFieldEnum[] | CateringServiceScalarFieldEnum
    having?: CateringServiceScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CateringServiceCountAggregateInputType | true
    _avg?: CateringServiceAvgAggregateInputType
    _sum?: CateringServiceSumAggregateInputType
    _min?: CateringServiceMinAggregateInputType
    _max?: CateringServiceMaxAggregateInputType
  }

  export type CateringServiceGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: CateringServiceCountAggregateOutputType | null
    _avg: CateringServiceAvgAggregateOutputType | null
    _sum: CateringServiceSumAggregateOutputType | null
    _min: CateringServiceMinAggregateOutputType | null
    _max: CateringServiceMaxAggregateOutputType | null
  }

  type GetCateringServiceGroupByPayload<T extends CateringServiceGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CateringServiceGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CateringServiceGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CateringServiceGroupByOutputType[P]>
            : GetScalarType<T[P], CateringServiceGroupByOutputType[P]>
        }
      >
    >


  export type CateringServiceSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["cateringService"]>



  export type CateringServiceSelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type CateringServiceOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["cateringService"]>

  export type $CateringServicePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CateringService"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["cateringService"]>
    composites: {}
  }

  type CateringServiceGetPayload<S extends boolean | null | undefined | CateringServiceDefaultArgs> = $Result.GetResult<Prisma.$CateringServicePayload, S>

  type CateringServiceCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CateringServiceFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CateringServiceCountAggregateInputType | true
    }

  export interface CateringServiceDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CateringService'], meta: { name: 'CateringService' } }
    /**
     * Find zero or one CateringService that matches the filter.
     * @param {CateringServiceFindUniqueArgs} args - Arguments to find a CateringService
     * @example
     * // Get one CateringService
     * const cateringService = await prisma.cateringService.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CateringServiceFindUniqueArgs>(args: SelectSubset<T, CateringServiceFindUniqueArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CateringService that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CateringServiceFindUniqueOrThrowArgs} args - Arguments to find a CateringService
     * @example
     * // Get one CateringService
     * const cateringService = await prisma.cateringService.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CateringServiceFindUniqueOrThrowArgs>(args: SelectSubset<T, CateringServiceFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CateringService that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceFindFirstArgs} args - Arguments to find a CateringService
     * @example
     * // Get one CateringService
     * const cateringService = await prisma.cateringService.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CateringServiceFindFirstArgs>(args?: SelectSubset<T, CateringServiceFindFirstArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CateringService that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceFindFirstOrThrowArgs} args - Arguments to find a CateringService
     * @example
     * // Get one CateringService
     * const cateringService = await prisma.cateringService.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CateringServiceFindFirstOrThrowArgs>(args?: SelectSubset<T, CateringServiceFindFirstOrThrowArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CateringServices that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CateringServices
     * const cateringServices = await prisma.cateringService.findMany()
     * 
     * // Get first 10 CateringServices
     * const cateringServices = await prisma.cateringService.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const cateringServiceWithIdOnly = await prisma.cateringService.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CateringServiceFindManyArgs>(args?: SelectSubset<T, CateringServiceFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CateringService.
     * @param {CateringServiceCreateArgs} args - Arguments to create a CateringService.
     * @example
     * // Create one CateringService
     * const CateringService = await prisma.cateringService.create({
     *   data: {
     *     // ... data to create a CateringService
     *   }
     * })
     * 
     */
    create<T extends CateringServiceCreateArgs>(args: SelectSubset<T, CateringServiceCreateArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CateringServices.
     * @param {CateringServiceCreateManyArgs} args - Arguments to create many CateringServices.
     * @example
     * // Create many CateringServices
     * const cateringService = await prisma.cateringService.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CateringServiceCreateManyArgs>(args?: SelectSubset<T, CateringServiceCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a CateringService.
     * @param {CateringServiceDeleteArgs} args - Arguments to delete one CateringService.
     * @example
     * // Delete one CateringService
     * const CateringService = await prisma.cateringService.delete({
     *   where: {
     *     // ... filter to delete one CateringService
     *   }
     * })
     * 
     */
    delete<T extends CateringServiceDeleteArgs>(args: SelectSubset<T, CateringServiceDeleteArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CateringService.
     * @param {CateringServiceUpdateArgs} args - Arguments to update one CateringService.
     * @example
     * // Update one CateringService
     * const cateringService = await prisma.cateringService.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CateringServiceUpdateArgs>(args: SelectSubset<T, CateringServiceUpdateArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CateringServices.
     * @param {CateringServiceDeleteManyArgs} args - Arguments to filter CateringServices to delete.
     * @example
     * // Delete a few CateringServices
     * const { count } = await prisma.cateringService.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CateringServiceDeleteManyArgs>(args?: SelectSubset<T, CateringServiceDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CateringServices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CateringServices
     * const cateringService = await prisma.cateringService.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CateringServiceUpdateManyArgs>(args: SelectSubset<T, CateringServiceUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one CateringService.
     * @param {CateringServiceUpsertArgs} args - Arguments to update or create a CateringService.
     * @example
     * // Update or create a CateringService
     * const cateringService = await prisma.cateringService.upsert({
     *   create: {
     *     // ... data to create a CateringService
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CateringService we want to update
     *   }
     * })
     */
    upsert<T extends CateringServiceUpsertArgs>(args: SelectSubset<T, CateringServiceUpsertArgs<ExtArgs>>): Prisma__CateringServiceClient<$Result.GetResult<Prisma.$CateringServicePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CateringServices.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceCountArgs} args - Arguments to filter CateringServices to count.
     * @example
     * // Count the number of CateringServices
     * const count = await prisma.cateringService.count({
     *   where: {
     *     // ... the filter for the CateringServices we want to count
     *   }
     * })
    **/
    count<T extends CateringServiceCountArgs>(
      args?: Subset<T, CateringServiceCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CateringServiceCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CateringService.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CateringServiceAggregateArgs>(args: Subset<T, CateringServiceAggregateArgs>): Prisma.PrismaPromise<GetCateringServiceAggregateType<T>>

    /**
     * Group by CateringService.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CateringServiceGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CateringServiceGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CateringServiceGroupByArgs['orderBy'] }
        : { orderBy?: CateringServiceGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CateringServiceGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCateringServiceGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CateringService model
   */
  readonly fields: CateringServiceFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CateringService.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CateringServiceClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CateringService model
   */
  interface CateringServiceFieldRefs {
    readonly id: FieldRef<"CateringService", 'Int'>
    readonly name: FieldRef<"CateringService", 'String'>
    readonly contact: FieldRef<"CateringService", 'String'>
    readonly location: FieldRef<"CateringService", 'String'>
    readonly createdAt: FieldRef<"CateringService", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * CateringService findUnique
   */
  export type CateringServiceFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter, which CateringService to fetch.
     */
    where: CateringServiceWhereUniqueInput
  }

  /**
   * CateringService findUniqueOrThrow
   */
  export type CateringServiceFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter, which CateringService to fetch.
     */
    where: CateringServiceWhereUniqueInput
  }

  /**
   * CateringService findFirst
   */
  export type CateringServiceFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter, which CateringService to fetch.
     */
    where?: CateringServiceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CateringServices to fetch.
     */
    orderBy?: CateringServiceOrderByWithRelationInput | CateringServiceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CateringServices.
     */
    cursor?: CateringServiceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CateringServices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CateringServices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CateringServices.
     */
    distinct?: CateringServiceScalarFieldEnum | CateringServiceScalarFieldEnum[]
  }

  /**
   * CateringService findFirstOrThrow
   */
  export type CateringServiceFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter, which CateringService to fetch.
     */
    where?: CateringServiceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CateringServices to fetch.
     */
    orderBy?: CateringServiceOrderByWithRelationInput | CateringServiceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CateringServices.
     */
    cursor?: CateringServiceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CateringServices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CateringServices.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CateringServices.
     */
    distinct?: CateringServiceScalarFieldEnum | CateringServiceScalarFieldEnum[]
  }

  /**
   * CateringService findMany
   */
  export type CateringServiceFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter, which CateringServices to fetch.
     */
    where?: CateringServiceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CateringServices to fetch.
     */
    orderBy?: CateringServiceOrderByWithRelationInput | CateringServiceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CateringServices.
     */
    cursor?: CateringServiceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CateringServices from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CateringServices.
     */
    skip?: number
    distinct?: CateringServiceScalarFieldEnum | CateringServiceScalarFieldEnum[]
  }

  /**
   * CateringService create
   */
  export type CateringServiceCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * The data needed to create a CateringService.
     */
    data: XOR<CateringServiceCreateInput, CateringServiceUncheckedCreateInput>
  }

  /**
   * CateringService createMany
   */
  export type CateringServiceCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CateringServices.
     */
    data: CateringServiceCreateManyInput | CateringServiceCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CateringService update
   */
  export type CateringServiceUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * The data needed to update a CateringService.
     */
    data: XOR<CateringServiceUpdateInput, CateringServiceUncheckedUpdateInput>
    /**
     * Choose, which CateringService to update.
     */
    where: CateringServiceWhereUniqueInput
  }

  /**
   * CateringService updateMany
   */
  export type CateringServiceUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CateringServices.
     */
    data: XOR<CateringServiceUpdateManyMutationInput, CateringServiceUncheckedUpdateManyInput>
    /**
     * Filter which CateringServices to update
     */
    where?: CateringServiceWhereInput
    /**
     * Limit how many CateringServices to update.
     */
    limit?: number
  }

  /**
   * CateringService upsert
   */
  export type CateringServiceUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * The filter to search for the CateringService to update in case it exists.
     */
    where: CateringServiceWhereUniqueInput
    /**
     * In case the CateringService found by the `where` argument doesn't exist, create a new CateringService with this data.
     */
    create: XOR<CateringServiceCreateInput, CateringServiceUncheckedCreateInput>
    /**
     * In case the CateringService was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CateringServiceUpdateInput, CateringServiceUncheckedUpdateInput>
  }

  /**
   * CateringService delete
   */
  export type CateringServiceDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
    /**
     * Filter which CateringService to delete.
     */
    where: CateringServiceWhereUniqueInput
  }

  /**
   * CateringService deleteMany
   */
  export type CateringServiceDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CateringServices to delete
     */
    where?: CateringServiceWhereInput
    /**
     * Limit how many CateringServices to delete.
     */
    limit?: number
  }

  /**
   * CateringService without action
   */
  export type CateringServiceDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CateringService
     */
    select?: CateringServiceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CateringService
     */
    omit?: CateringServiceOmit<ExtArgs> | null
  }


  /**
   * Model SecurityAgency
   */

  export type AggregateSecurityAgency = {
    _count: SecurityAgencyCountAggregateOutputType | null
    _avg: SecurityAgencyAvgAggregateOutputType | null
    _sum: SecurityAgencySumAggregateOutputType | null
    _min: SecurityAgencyMinAggregateOutputType | null
    _max: SecurityAgencyMaxAggregateOutputType | null
  }

  export type SecurityAgencyAvgAggregateOutputType = {
    id: number | null
  }

  export type SecurityAgencySumAggregateOutputType = {
    id: number | null
  }

  export type SecurityAgencyMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type SecurityAgencyMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type SecurityAgencyCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type SecurityAgencyAvgAggregateInputType = {
    id?: true
  }

  export type SecurityAgencySumAggregateInputType = {
    id?: true
  }

  export type SecurityAgencyMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type SecurityAgencyMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type SecurityAgencyCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type SecurityAgencyAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SecurityAgency to aggregate.
     */
    where?: SecurityAgencyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SecurityAgencies to fetch.
     */
    orderBy?: SecurityAgencyOrderByWithRelationInput | SecurityAgencyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SecurityAgencyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SecurityAgencies from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SecurityAgencies.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SecurityAgencies
    **/
    _count?: true | SecurityAgencyCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SecurityAgencyAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SecurityAgencySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SecurityAgencyMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SecurityAgencyMaxAggregateInputType
  }

  export type GetSecurityAgencyAggregateType<T extends SecurityAgencyAggregateArgs> = {
        [P in keyof T & keyof AggregateSecurityAgency]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSecurityAgency[P]>
      : GetScalarType<T[P], AggregateSecurityAgency[P]>
  }




  export type SecurityAgencyGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SecurityAgencyWhereInput
    orderBy?: SecurityAgencyOrderByWithAggregationInput | SecurityAgencyOrderByWithAggregationInput[]
    by: SecurityAgencyScalarFieldEnum[] | SecurityAgencyScalarFieldEnum
    having?: SecurityAgencyScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SecurityAgencyCountAggregateInputType | true
    _avg?: SecurityAgencyAvgAggregateInputType
    _sum?: SecurityAgencySumAggregateInputType
    _min?: SecurityAgencyMinAggregateInputType
    _max?: SecurityAgencyMaxAggregateInputType
  }

  export type SecurityAgencyGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: SecurityAgencyCountAggregateOutputType | null
    _avg: SecurityAgencyAvgAggregateOutputType | null
    _sum: SecurityAgencySumAggregateOutputType | null
    _min: SecurityAgencyMinAggregateOutputType | null
    _max: SecurityAgencyMaxAggregateOutputType | null
  }

  type GetSecurityAgencyGroupByPayload<T extends SecurityAgencyGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SecurityAgencyGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SecurityAgencyGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SecurityAgencyGroupByOutputType[P]>
            : GetScalarType<T[P], SecurityAgencyGroupByOutputType[P]>
        }
      >
    >


  export type SecurityAgencySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["securityAgency"]>



  export type SecurityAgencySelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type SecurityAgencyOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["securityAgency"]>

  export type $SecurityAgencyPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SecurityAgency"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["securityAgency"]>
    composites: {}
  }

  type SecurityAgencyGetPayload<S extends boolean | null | undefined | SecurityAgencyDefaultArgs> = $Result.GetResult<Prisma.$SecurityAgencyPayload, S>

  type SecurityAgencyCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SecurityAgencyFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SecurityAgencyCountAggregateInputType | true
    }

  export interface SecurityAgencyDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SecurityAgency'], meta: { name: 'SecurityAgency' } }
    /**
     * Find zero or one SecurityAgency that matches the filter.
     * @param {SecurityAgencyFindUniqueArgs} args - Arguments to find a SecurityAgency
     * @example
     * // Get one SecurityAgency
     * const securityAgency = await prisma.securityAgency.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SecurityAgencyFindUniqueArgs>(args: SelectSubset<T, SecurityAgencyFindUniqueArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SecurityAgency that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SecurityAgencyFindUniqueOrThrowArgs} args - Arguments to find a SecurityAgency
     * @example
     * // Get one SecurityAgency
     * const securityAgency = await prisma.securityAgency.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SecurityAgencyFindUniqueOrThrowArgs>(args: SelectSubset<T, SecurityAgencyFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SecurityAgency that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyFindFirstArgs} args - Arguments to find a SecurityAgency
     * @example
     * // Get one SecurityAgency
     * const securityAgency = await prisma.securityAgency.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SecurityAgencyFindFirstArgs>(args?: SelectSubset<T, SecurityAgencyFindFirstArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SecurityAgency that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyFindFirstOrThrowArgs} args - Arguments to find a SecurityAgency
     * @example
     * // Get one SecurityAgency
     * const securityAgency = await prisma.securityAgency.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SecurityAgencyFindFirstOrThrowArgs>(args?: SelectSubset<T, SecurityAgencyFindFirstOrThrowArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SecurityAgencies that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SecurityAgencies
     * const securityAgencies = await prisma.securityAgency.findMany()
     * 
     * // Get first 10 SecurityAgencies
     * const securityAgencies = await prisma.securityAgency.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const securityAgencyWithIdOnly = await prisma.securityAgency.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SecurityAgencyFindManyArgs>(args?: SelectSubset<T, SecurityAgencyFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SecurityAgency.
     * @param {SecurityAgencyCreateArgs} args - Arguments to create a SecurityAgency.
     * @example
     * // Create one SecurityAgency
     * const SecurityAgency = await prisma.securityAgency.create({
     *   data: {
     *     // ... data to create a SecurityAgency
     *   }
     * })
     * 
     */
    create<T extends SecurityAgencyCreateArgs>(args: SelectSubset<T, SecurityAgencyCreateArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SecurityAgencies.
     * @param {SecurityAgencyCreateManyArgs} args - Arguments to create many SecurityAgencies.
     * @example
     * // Create many SecurityAgencies
     * const securityAgency = await prisma.securityAgency.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SecurityAgencyCreateManyArgs>(args?: SelectSubset<T, SecurityAgencyCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SecurityAgency.
     * @param {SecurityAgencyDeleteArgs} args - Arguments to delete one SecurityAgency.
     * @example
     * // Delete one SecurityAgency
     * const SecurityAgency = await prisma.securityAgency.delete({
     *   where: {
     *     // ... filter to delete one SecurityAgency
     *   }
     * })
     * 
     */
    delete<T extends SecurityAgencyDeleteArgs>(args: SelectSubset<T, SecurityAgencyDeleteArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SecurityAgency.
     * @param {SecurityAgencyUpdateArgs} args - Arguments to update one SecurityAgency.
     * @example
     * // Update one SecurityAgency
     * const securityAgency = await prisma.securityAgency.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SecurityAgencyUpdateArgs>(args: SelectSubset<T, SecurityAgencyUpdateArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SecurityAgencies.
     * @param {SecurityAgencyDeleteManyArgs} args - Arguments to filter SecurityAgencies to delete.
     * @example
     * // Delete a few SecurityAgencies
     * const { count } = await prisma.securityAgency.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SecurityAgencyDeleteManyArgs>(args?: SelectSubset<T, SecurityAgencyDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SecurityAgencies.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SecurityAgencies
     * const securityAgency = await prisma.securityAgency.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SecurityAgencyUpdateManyArgs>(args: SelectSubset<T, SecurityAgencyUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SecurityAgency.
     * @param {SecurityAgencyUpsertArgs} args - Arguments to update or create a SecurityAgency.
     * @example
     * // Update or create a SecurityAgency
     * const securityAgency = await prisma.securityAgency.upsert({
     *   create: {
     *     // ... data to create a SecurityAgency
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SecurityAgency we want to update
     *   }
     * })
     */
    upsert<T extends SecurityAgencyUpsertArgs>(args: SelectSubset<T, SecurityAgencyUpsertArgs<ExtArgs>>): Prisma__SecurityAgencyClient<$Result.GetResult<Prisma.$SecurityAgencyPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SecurityAgencies.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyCountArgs} args - Arguments to filter SecurityAgencies to count.
     * @example
     * // Count the number of SecurityAgencies
     * const count = await prisma.securityAgency.count({
     *   where: {
     *     // ... the filter for the SecurityAgencies we want to count
     *   }
     * })
    **/
    count<T extends SecurityAgencyCountArgs>(
      args?: Subset<T, SecurityAgencyCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SecurityAgencyCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SecurityAgency.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SecurityAgencyAggregateArgs>(args: Subset<T, SecurityAgencyAggregateArgs>): Prisma.PrismaPromise<GetSecurityAgencyAggregateType<T>>

    /**
     * Group by SecurityAgency.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SecurityAgencyGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SecurityAgencyGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SecurityAgencyGroupByArgs['orderBy'] }
        : { orderBy?: SecurityAgencyGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SecurityAgencyGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSecurityAgencyGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SecurityAgency model
   */
  readonly fields: SecurityAgencyFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SecurityAgency.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SecurityAgencyClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SecurityAgency model
   */
  interface SecurityAgencyFieldRefs {
    readonly id: FieldRef<"SecurityAgency", 'Int'>
    readonly name: FieldRef<"SecurityAgency", 'String'>
    readonly contact: FieldRef<"SecurityAgency", 'String'>
    readonly location: FieldRef<"SecurityAgency", 'String'>
    readonly createdAt: FieldRef<"SecurityAgency", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SecurityAgency findUnique
   */
  export type SecurityAgencyFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter, which SecurityAgency to fetch.
     */
    where: SecurityAgencyWhereUniqueInput
  }

  /**
   * SecurityAgency findUniqueOrThrow
   */
  export type SecurityAgencyFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter, which SecurityAgency to fetch.
     */
    where: SecurityAgencyWhereUniqueInput
  }

  /**
   * SecurityAgency findFirst
   */
  export type SecurityAgencyFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter, which SecurityAgency to fetch.
     */
    where?: SecurityAgencyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SecurityAgencies to fetch.
     */
    orderBy?: SecurityAgencyOrderByWithRelationInput | SecurityAgencyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SecurityAgencies.
     */
    cursor?: SecurityAgencyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SecurityAgencies from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SecurityAgencies.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SecurityAgencies.
     */
    distinct?: SecurityAgencyScalarFieldEnum | SecurityAgencyScalarFieldEnum[]
  }

  /**
   * SecurityAgency findFirstOrThrow
   */
  export type SecurityAgencyFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter, which SecurityAgency to fetch.
     */
    where?: SecurityAgencyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SecurityAgencies to fetch.
     */
    orderBy?: SecurityAgencyOrderByWithRelationInput | SecurityAgencyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SecurityAgencies.
     */
    cursor?: SecurityAgencyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SecurityAgencies from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SecurityAgencies.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SecurityAgencies.
     */
    distinct?: SecurityAgencyScalarFieldEnum | SecurityAgencyScalarFieldEnum[]
  }

  /**
   * SecurityAgency findMany
   */
  export type SecurityAgencyFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter, which SecurityAgencies to fetch.
     */
    where?: SecurityAgencyWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SecurityAgencies to fetch.
     */
    orderBy?: SecurityAgencyOrderByWithRelationInput | SecurityAgencyOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SecurityAgencies.
     */
    cursor?: SecurityAgencyWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SecurityAgencies from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SecurityAgencies.
     */
    skip?: number
    distinct?: SecurityAgencyScalarFieldEnum | SecurityAgencyScalarFieldEnum[]
  }

  /**
   * SecurityAgency create
   */
  export type SecurityAgencyCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * The data needed to create a SecurityAgency.
     */
    data: XOR<SecurityAgencyCreateInput, SecurityAgencyUncheckedCreateInput>
  }

  /**
   * SecurityAgency createMany
   */
  export type SecurityAgencyCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SecurityAgencies.
     */
    data: SecurityAgencyCreateManyInput | SecurityAgencyCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SecurityAgency update
   */
  export type SecurityAgencyUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * The data needed to update a SecurityAgency.
     */
    data: XOR<SecurityAgencyUpdateInput, SecurityAgencyUncheckedUpdateInput>
    /**
     * Choose, which SecurityAgency to update.
     */
    where: SecurityAgencyWhereUniqueInput
  }

  /**
   * SecurityAgency updateMany
   */
  export type SecurityAgencyUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SecurityAgencies.
     */
    data: XOR<SecurityAgencyUpdateManyMutationInput, SecurityAgencyUncheckedUpdateManyInput>
    /**
     * Filter which SecurityAgencies to update
     */
    where?: SecurityAgencyWhereInput
    /**
     * Limit how many SecurityAgencies to update.
     */
    limit?: number
  }

  /**
   * SecurityAgency upsert
   */
  export type SecurityAgencyUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * The filter to search for the SecurityAgency to update in case it exists.
     */
    where: SecurityAgencyWhereUniqueInput
    /**
     * In case the SecurityAgency found by the `where` argument doesn't exist, create a new SecurityAgency with this data.
     */
    create: XOR<SecurityAgencyCreateInput, SecurityAgencyUncheckedCreateInput>
    /**
     * In case the SecurityAgency was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SecurityAgencyUpdateInput, SecurityAgencyUncheckedUpdateInput>
  }

  /**
   * SecurityAgency delete
   */
  export type SecurityAgencyDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
    /**
     * Filter which SecurityAgency to delete.
     */
    where: SecurityAgencyWhereUniqueInput
  }

  /**
   * SecurityAgency deleteMany
   */
  export type SecurityAgencyDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SecurityAgencies to delete
     */
    where?: SecurityAgencyWhereInput
    /**
     * Limit how many SecurityAgencies to delete.
     */
    limit?: number
  }

  /**
   * SecurityAgency without action
   */
  export type SecurityAgencyDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SecurityAgency
     */
    select?: SecurityAgencySelect<ExtArgs> | null
    /**
     * Omit specific fields from the SecurityAgency
     */
    omit?: SecurityAgencyOmit<ExtArgs> | null
  }


  /**
   * Model GiftShop
   */

  export type AggregateGiftShop = {
    _count: GiftShopCountAggregateOutputType | null
    _avg: GiftShopAvgAggregateOutputType | null
    _sum: GiftShopSumAggregateOutputType | null
    _min: GiftShopMinAggregateOutputType | null
    _max: GiftShopMaxAggregateOutputType | null
  }

  export type GiftShopAvgAggregateOutputType = {
    id: number | null
  }

  export type GiftShopSumAggregateOutputType = {
    id: number | null
  }

  export type GiftShopMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type GiftShopMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type GiftShopCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type GiftShopAvgAggregateInputType = {
    id?: true
  }

  export type GiftShopSumAggregateInputType = {
    id?: true
  }

  export type GiftShopMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type GiftShopMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type GiftShopCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type GiftShopAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which GiftShop to aggregate.
     */
    where?: GiftShopWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of GiftShops to fetch.
     */
    orderBy?: GiftShopOrderByWithRelationInput | GiftShopOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: GiftShopWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` GiftShops from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` GiftShops.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned GiftShops
    **/
    _count?: true | GiftShopCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: GiftShopAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: GiftShopSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GiftShopMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GiftShopMaxAggregateInputType
  }

  export type GetGiftShopAggregateType<T extends GiftShopAggregateArgs> = {
        [P in keyof T & keyof AggregateGiftShop]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGiftShop[P]>
      : GetScalarType<T[P], AggregateGiftShop[P]>
  }




  export type GiftShopGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: GiftShopWhereInput
    orderBy?: GiftShopOrderByWithAggregationInput | GiftShopOrderByWithAggregationInput[]
    by: GiftShopScalarFieldEnum[] | GiftShopScalarFieldEnum
    having?: GiftShopScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GiftShopCountAggregateInputType | true
    _avg?: GiftShopAvgAggregateInputType
    _sum?: GiftShopSumAggregateInputType
    _min?: GiftShopMinAggregateInputType
    _max?: GiftShopMaxAggregateInputType
  }

  export type GiftShopGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: GiftShopCountAggregateOutputType | null
    _avg: GiftShopAvgAggregateOutputType | null
    _sum: GiftShopSumAggregateOutputType | null
    _min: GiftShopMinAggregateOutputType | null
    _max: GiftShopMaxAggregateOutputType | null
  }

  type GetGiftShopGroupByPayload<T extends GiftShopGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<GiftShopGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GiftShopGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GiftShopGroupByOutputType[P]>
            : GetScalarType<T[P], GiftShopGroupByOutputType[P]>
        }
      >
    >


  export type GiftShopSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["giftShop"]>



  export type GiftShopSelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type GiftShopOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["giftShop"]>

  export type $GiftShopPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "GiftShop"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["giftShop"]>
    composites: {}
  }

  type GiftShopGetPayload<S extends boolean | null | undefined | GiftShopDefaultArgs> = $Result.GetResult<Prisma.$GiftShopPayload, S>

  type GiftShopCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<GiftShopFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: GiftShopCountAggregateInputType | true
    }

  export interface GiftShopDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['GiftShop'], meta: { name: 'GiftShop' } }
    /**
     * Find zero or one GiftShop that matches the filter.
     * @param {GiftShopFindUniqueArgs} args - Arguments to find a GiftShop
     * @example
     * // Get one GiftShop
     * const giftShop = await prisma.giftShop.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends GiftShopFindUniqueArgs>(args: SelectSubset<T, GiftShopFindUniqueArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one GiftShop that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {GiftShopFindUniqueOrThrowArgs} args - Arguments to find a GiftShop
     * @example
     * // Get one GiftShop
     * const giftShop = await prisma.giftShop.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends GiftShopFindUniqueOrThrowArgs>(args: SelectSubset<T, GiftShopFindUniqueOrThrowArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first GiftShop that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopFindFirstArgs} args - Arguments to find a GiftShop
     * @example
     * // Get one GiftShop
     * const giftShop = await prisma.giftShop.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends GiftShopFindFirstArgs>(args?: SelectSubset<T, GiftShopFindFirstArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first GiftShop that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopFindFirstOrThrowArgs} args - Arguments to find a GiftShop
     * @example
     * // Get one GiftShop
     * const giftShop = await prisma.giftShop.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends GiftShopFindFirstOrThrowArgs>(args?: SelectSubset<T, GiftShopFindFirstOrThrowArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more GiftShops that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all GiftShops
     * const giftShops = await prisma.giftShop.findMany()
     * 
     * // Get first 10 GiftShops
     * const giftShops = await prisma.giftShop.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const giftShopWithIdOnly = await prisma.giftShop.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends GiftShopFindManyArgs>(args?: SelectSubset<T, GiftShopFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a GiftShop.
     * @param {GiftShopCreateArgs} args - Arguments to create a GiftShop.
     * @example
     * // Create one GiftShop
     * const GiftShop = await prisma.giftShop.create({
     *   data: {
     *     // ... data to create a GiftShop
     *   }
     * })
     * 
     */
    create<T extends GiftShopCreateArgs>(args: SelectSubset<T, GiftShopCreateArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many GiftShops.
     * @param {GiftShopCreateManyArgs} args - Arguments to create many GiftShops.
     * @example
     * // Create many GiftShops
     * const giftShop = await prisma.giftShop.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends GiftShopCreateManyArgs>(args?: SelectSubset<T, GiftShopCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a GiftShop.
     * @param {GiftShopDeleteArgs} args - Arguments to delete one GiftShop.
     * @example
     * // Delete one GiftShop
     * const GiftShop = await prisma.giftShop.delete({
     *   where: {
     *     // ... filter to delete one GiftShop
     *   }
     * })
     * 
     */
    delete<T extends GiftShopDeleteArgs>(args: SelectSubset<T, GiftShopDeleteArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one GiftShop.
     * @param {GiftShopUpdateArgs} args - Arguments to update one GiftShop.
     * @example
     * // Update one GiftShop
     * const giftShop = await prisma.giftShop.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends GiftShopUpdateArgs>(args: SelectSubset<T, GiftShopUpdateArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more GiftShops.
     * @param {GiftShopDeleteManyArgs} args - Arguments to filter GiftShops to delete.
     * @example
     * // Delete a few GiftShops
     * const { count } = await prisma.giftShop.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends GiftShopDeleteManyArgs>(args?: SelectSubset<T, GiftShopDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more GiftShops.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many GiftShops
     * const giftShop = await prisma.giftShop.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends GiftShopUpdateManyArgs>(args: SelectSubset<T, GiftShopUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one GiftShop.
     * @param {GiftShopUpsertArgs} args - Arguments to update or create a GiftShop.
     * @example
     * // Update or create a GiftShop
     * const giftShop = await prisma.giftShop.upsert({
     *   create: {
     *     // ... data to create a GiftShop
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the GiftShop we want to update
     *   }
     * })
     */
    upsert<T extends GiftShopUpsertArgs>(args: SelectSubset<T, GiftShopUpsertArgs<ExtArgs>>): Prisma__GiftShopClient<$Result.GetResult<Prisma.$GiftShopPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of GiftShops.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopCountArgs} args - Arguments to filter GiftShops to count.
     * @example
     * // Count the number of GiftShops
     * const count = await prisma.giftShop.count({
     *   where: {
     *     // ... the filter for the GiftShops we want to count
     *   }
     * })
    **/
    count<T extends GiftShopCountArgs>(
      args?: Subset<T, GiftShopCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GiftShopCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a GiftShop.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GiftShopAggregateArgs>(args: Subset<T, GiftShopAggregateArgs>): Prisma.PrismaPromise<GetGiftShopAggregateType<T>>

    /**
     * Group by GiftShop.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GiftShopGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GiftShopGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GiftShopGroupByArgs['orderBy'] }
        : { orderBy?: GiftShopGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GiftShopGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGiftShopGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the GiftShop model
   */
  readonly fields: GiftShopFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for GiftShop.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__GiftShopClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the GiftShop model
   */
  interface GiftShopFieldRefs {
    readonly id: FieldRef<"GiftShop", 'Int'>
    readonly name: FieldRef<"GiftShop", 'String'>
    readonly contact: FieldRef<"GiftShop", 'String'>
    readonly location: FieldRef<"GiftShop", 'String'>
    readonly createdAt: FieldRef<"GiftShop", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * GiftShop findUnique
   */
  export type GiftShopFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter, which GiftShop to fetch.
     */
    where: GiftShopWhereUniqueInput
  }

  /**
   * GiftShop findUniqueOrThrow
   */
  export type GiftShopFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter, which GiftShop to fetch.
     */
    where: GiftShopWhereUniqueInput
  }

  /**
   * GiftShop findFirst
   */
  export type GiftShopFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter, which GiftShop to fetch.
     */
    where?: GiftShopWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of GiftShops to fetch.
     */
    orderBy?: GiftShopOrderByWithRelationInput | GiftShopOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for GiftShops.
     */
    cursor?: GiftShopWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` GiftShops from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` GiftShops.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of GiftShops.
     */
    distinct?: GiftShopScalarFieldEnum | GiftShopScalarFieldEnum[]
  }

  /**
   * GiftShop findFirstOrThrow
   */
  export type GiftShopFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter, which GiftShop to fetch.
     */
    where?: GiftShopWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of GiftShops to fetch.
     */
    orderBy?: GiftShopOrderByWithRelationInput | GiftShopOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for GiftShops.
     */
    cursor?: GiftShopWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` GiftShops from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` GiftShops.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of GiftShops.
     */
    distinct?: GiftShopScalarFieldEnum | GiftShopScalarFieldEnum[]
  }

  /**
   * GiftShop findMany
   */
  export type GiftShopFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter, which GiftShops to fetch.
     */
    where?: GiftShopWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of GiftShops to fetch.
     */
    orderBy?: GiftShopOrderByWithRelationInput | GiftShopOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing GiftShops.
     */
    cursor?: GiftShopWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` GiftShops from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` GiftShops.
     */
    skip?: number
    distinct?: GiftShopScalarFieldEnum | GiftShopScalarFieldEnum[]
  }

  /**
   * GiftShop create
   */
  export type GiftShopCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * The data needed to create a GiftShop.
     */
    data: XOR<GiftShopCreateInput, GiftShopUncheckedCreateInput>
  }

  /**
   * GiftShop createMany
   */
  export type GiftShopCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many GiftShops.
     */
    data: GiftShopCreateManyInput | GiftShopCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * GiftShop update
   */
  export type GiftShopUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * The data needed to update a GiftShop.
     */
    data: XOR<GiftShopUpdateInput, GiftShopUncheckedUpdateInput>
    /**
     * Choose, which GiftShop to update.
     */
    where: GiftShopWhereUniqueInput
  }

  /**
   * GiftShop updateMany
   */
  export type GiftShopUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update GiftShops.
     */
    data: XOR<GiftShopUpdateManyMutationInput, GiftShopUncheckedUpdateManyInput>
    /**
     * Filter which GiftShops to update
     */
    where?: GiftShopWhereInput
    /**
     * Limit how many GiftShops to update.
     */
    limit?: number
  }

  /**
   * GiftShop upsert
   */
  export type GiftShopUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * The filter to search for the GiftShop to update in case it exists.
     */
    where: GiftShopWhereUniqueInput
    /**
     * In case the GiftShop found by the `where` argument doesn't exist, create a new GiftShop with this data.
     */
    create: XOR<GiftShopCreateInput, GiftShopUncheckedCreateInput>
    /**
     * In case the GiftShop was found with the provided `where` argument, update it with this data.
     */
    update: XOR<GiftShopUpdateInput, GiftShopUncheckedUpdateInput>
  }

  /**
   * GiftShop delete
   */
  export type GiftShopDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
    /**
     * Filter which GiftShop to delete.
     */
    where: GiftShopWhereUniqueInput
  }

  /**
   * GiftShop deleteMany
   */
  export type GiftShopDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which GiftShops to delete
     */
    where?: GiftShopWhereInput
    /**
     * Limit how many GiftShops to delete.
     */
    limit?: number
  }

  /**
   * GiftShop without action
   */
  export type GiftShopDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GiftShop
     */
    select?: GiftShopSelect<ExtArgs> | null
    /**
     * Omit specific fields from the GiftShop
     */
    omit?: GiftShopOmit<ExtArgs> | null
  }


  /**
   * Model DJ
   */

  export type AggregateDJ = {
    _count: DJCountAggregateOutputType | null
    _avg: DJAvgAggregateOutputType | null
    _sum: DJSumAggregateOutputType | null
    _min: DJMinAggregateOutputType | null
    _max: DJMaxAggregateOutputType | null
  }

  export type DJAvgAggregateOutputType = {
    id: number | null
  }

  export type DJSumAggregateOutputType = {
    id: number | null
  }

  export type DJMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type DJMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type DJCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type DJAvgAggregateInputType = {
    id?: true
  }

  export type DJSumAggregateInputType = {
    id?: true
  }

  export type DJMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type DJMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type DJCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type DJAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which DJ to aggregate.
     */
    where?: DJWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DJS to fetch.
     */
    orderBy?: DJOrderByWithRelationInput | DJOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DJWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DJS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DJS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned DJS
    **/
    _count?: true | DJCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: DJAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: DJSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DJMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DJMaxAggregateInputType
  }

  export type GetDJAggregateType<T extends DJAggregateArgs> = {
        [P in keyof T & keyof AggregateDJ]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDJ[P]>
      : GetScalarType<T[P], AggregateDJ[P]>
  }




  export type DJGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DJWhereInput
    orderBy?: DJOrderByWithAggregationInput | DJOrderByWithAggregationInput[]
    by: DJScalarFieldEnum[] | DJScalarFieldEnum
    having?: DJScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DJCountAggregateInputType | true
    _avg?: DJAvgAggregateInputType
    _sum?: DJSumAggregateInputType
    _min?: DJMinAggregateInputType
    _max?: DJMaxAggregateInputType
  }

  export type DJGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: DJCountAggregateOutputType | null
    _avg: DJAvgAggregateOutputType | null
    _sum: DJSumAggregateOutputType | null
    _min: DJMinAggregateOutputType | null
    _max: DJMaxAggregateOutputType | null
  }

  type GetDJGroupByPayload<T extends DJGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DJGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DJGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DJGroupByOutputType[P]>
            : GetScalarType<T[P], DJGroupByOutputType[P]>
        }
      >
    >


  export type DJSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["dJ"]>



  export type DJSelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type DJOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["dJ"]>

  export type $DJPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "DJ"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["dJ"]>
    composites: {}
  }

  type DJGetPayload<S extends boolean | null | undefined | DJDefaultArgs> = $Result.GetResult<Prisma.$DJPayload, S>

  type DJCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<DJFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: DJCountAggregateInputType | true
    }

  export interface DJDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['DJ'], meta: { name: 'DJ' } }
    /**
     * Find zero or one DJ that matches the filter.
     * @param {DJFindUniqueArgs} args - Arguments to find a DJ
     * @example
     * // Get one DJ
     * const dJ = await prisma.dJ.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends DJFindUniqueArgs>(args: SelectSubset<T, DJFindUniqueArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one DJ that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {DJFindUniqueOrThrowArgs} args - Arguments to find a DJ
     * @example
     * // Get one DJ
     * const dJ = await prisma.dJ.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends DJFindUniqueOrThrowArgs>(args: SelectSubset<T, DJFindUniqueOrThrowArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first DJ that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJFindFirstArgs} args - Arguments to find a DJ
     * @example
     * // Get one DJ
     * const dJ = await prisma.dJ.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends DJFindFirstArgs>(args?: SelectSubset<T, DJFindFirstArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first DJ that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJFindFirstOrThrowArgs} args - Arguments to find a DJ
     * @example
     * // Get one DJ
     * const dJ = await prisma.dJ.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends DJFindFirstOrThrowArgs>(args?: SelectSubset<T, DJFindFirstOrThrowArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more DJS that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all DJS
     * const dJS = await prisma.dJ.findMany()
     * 
     * // Get first 10 DJS
     * const dJS = await prisma.dJ.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const dJWithIdOnly = await prisma.dJ.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends DJFindManyArgs>(args?: SelectSubset<T, DJFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a DJ.
     * @param {DJCreateArgs} args - Arguments to create a DJ.
     * @example
     * // Create one DJ
     * const DJ = await prisma.dJ.create({
     *   data: {
     *     // ... data to create a DJ
     *   }
     * })
     * 
     */
    create<T extends DJCreateArgs>(args: SelectSubset<T, DJCreateArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many DJS.
     * @param {DJCreateManyArgs} args - Arguments to create many DJS.
     * @example
     * // Create many DJS
     * const dJ = await prisma.dJ.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends DJCreateManyArgs>(args?: SelectSubset<T, DJCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a DJ.
     * @param {DJDeleteArgs} args - Arguments to delete one DJ.
     * @example
     * // Delete one DJ
     * const DJ = await prisma.dJ.delete({
     *   where: {
     *     // ... filter to delete one DJ
     *   }
     * })
     * 
     */
    delete<T extends DJDeleteArgs>(args: SelectSubset<T, DJDeleteArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one DJ.
     * @param {DJUpdateArgs} args - Arguments to update one DJ.
     * @example
     * // Update one DJ
     * const dJ = await prisma.dJ.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends DJUpdateArgs>(args: SelectSubset<T, DJUpdateArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more DJS.
     * @param {DJDeleteManyArgs} args - Arguments to filter DJS to delete.
     * @example
     * // Delete a few DJS
     * const { count } = await prisma.dJ.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends DJDeleteManyArgs>(args?: SelectSubset<T, DJDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more DJS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many DJS
     * const dJ = await prisma.dJ.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends DJUpdateManyArgs>(args: SelectSubset<T, DJUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one DJ.
     * @param {DJUpsertArgs} args - Arguments to update or create a DJ.
     * @example
     * // Update or create a DJ
     * const dJ = await prisma.dJ.upsert({
     *   create: {
     *     // ... data to create a DJ
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the DJ we want to update
     *   }
     * })
     */
    upsert<T extends DJUpsertArgs>(args: SelectSubset<T, DJUpsertArgs<ExtArgs>>): Prisma__DJClient<$Result.GetResult<Prisma.$DJPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of DJS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJCountArgs} args - Arguments to filter DJS to count.
     * @example
     * // Count the number of DJS
     * const count = await prisma.dJ.count({
     *   where: {
     *     // ... the filter for the DJS we want to count
     *   }
     * })
    **/
    count<T extends DJCountArgs>(
      args?: Subset<T, DJCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DJCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a DJ.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DJAggregateArgs>(args: Subset<T, DJAggregateArgs>): Prisma.PrismaPromise<GetDJAggregateType<T>>

    /**
     * Group by DJ.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DJGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DJGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DJGroupByArgs['orderBy'] }
        : { orderBy?: DJGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DJGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDJGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the DJ model
   */
  readonly fields: DJFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for DJ.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DJClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the DJ model
   */
  interface DJFieldRefs {
    readonly id: FieldRef<"DJ", 'Int'>
    readonly name: FieldRef<"DJ", 'String'>
    readonly contact: FieldRef<"DJ", 'String'>
    readonly location: FieldRef<"DJ", 'String'>
    readonly createdAt: FieldRef<"DJ", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * DJ findUnique
   */
  export type DJFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter, which DJ to fetch.
     */
    where: DJWhereUniqueInput
  }

  /**
   * DJ findUniqueOrThrow
   */
  export type DJFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter, which DJ to fetch.
     */
    where: DJWhereUniqueInput
  }

  /**
   * DJ findFirst
   */
  export type DJFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter, which DJ to fetch.
     */
    where?: DJWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DJS to fetch.
     */
    orderBy?: DJOrderByWithRelationInput | DJOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for DJS.
     */
    cursor?: DJWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DJS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DJS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of DJS.
     */
    distinct?: DJScalarFieldEnum | DJScalarFieldEnum[]
  }

  /**
   * DJ findFirstOrThrow
   */
  export type DJFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter, which DJ to fetch.
     */
    where?: DJWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DJS to fetch.
     */
    orderBy?: DJOrderByWithRelationInput | DJOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for DJS.
     */
    cursor?: DJWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DJS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DJS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of DJS.
     */
    distinct?: DJScalarFieldEnum | DJScalarFieldEnum[]
  }

  /**
   * DJ findMany
   */
  export type DJFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter, which DJS to fetch.
     */
    where?: DJWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of DJS to fetch.
     */
    orderBy?: DJOrderByWithRelationInput | DJOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing DJS.
     */
    cursor?: DJWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` DJS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` DJS.
     */
    skip?: number
    distinct?: DJScalarFieldEnum | DJScalarFieldEnum[]
  }

  /**
   * DJ create
   */
  export type DJCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * The data needed to create a DJ.
     */
    data: XOR<DJCreateInput, DJUncheckedCreateInput>
  }

  /**
   * DJ createMany
   */
  export type DJCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many DJS.
     */
    data: DJCreateManyInput | DJCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * DJ update
   */
  export type DJUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * The data needed to update a DJ.
     */
    data: XOR<DJUpdateInput, DJUncheckedUpdateInput>
    /**
     * Choose, which DJ to update.
     */
    where: DJWhereUniqueInput
  }

  /**
   * DJ updateMany
   */
  export type DJUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update DJS.
     */
    data: XOR<DJUpdateManyMutationInput, DJUncheckedUpdateManyInput>
    /**
     * Filter which DJS to update
     */
    where?: DJWhereInput
    /**
     * Limit how many DJS to update.
     */
    limit?: number
  }

  /**
   * DJ upsert
   */
  export type DJUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * The filter to search for the DJ to update in case it exists.
     */
    where: DJWhereUniqueInput
    /**
     * In case the DJ found by the `where` argument doesn't exist, create a new DJ with this data.
     */
    create: XOR<DJCreateInput, DJUncheckedCreateInput>
    /**
     * In case the DJ was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DJUpdateInput, DJUncheckedUpdateInput>
  }

  /**
   * DJ delete
   */
  export type DJDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
    /**
     * Filter which DJ to delete.
     */
    where: DJWhereUniqueInput
  }

  /**
   * DJ deleteMany
   */
  export type DJDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which DJS to delete
     */
    where?: DJWhereInput
    /**
     * Limit how many DJS to delete.
     */
    limit?: number
  }

  /**
   * DJ without action
   */
  export type DJDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DJ
     */
    select?: DJSelect<ExtArgs> | null
    /**
     * Omit specific fields from the DJ
     */
    omit?: DJOmit<ExtArgs> | null
  }


  /**
   * Model Photographer
   */

  export type AggregatePhotographer = {
    _count: PhotographerCountAggregateOutputType | null
    _avg: PhotographerAvgAggregateOutputType | null
    _sum: PhotographerSumAggregateOutputType | null
    _min: PhotographerMinAggregateOutputType | null
    _max: PhotographerMaxAggregateOutputType | null
  }

  export type PhotographerAvgAggregateOutputType = {
    id: number | null
  }

  export type PhotographerSumAggregateOutputType = {
    id: number | null
  }

  export type PhotographerMinAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type PhotographerMaxAggregateOutputType = {
    id: number | null
    name: string | null
    contact: string | null
    location: string | null
    createdAt: Date | null
  }

  export type PhotographerCountAggregateOutputType = {
    id: number
    name: number
    contact: number
    location: number
    createdAt: number
    _all: number
  }


  export type PhotographerAvgAggregateInputType = {
    id?: true
  }

  export type PhotographerSumAggregateInputType = {
    id?: true
  }

  export type PhotographerMinAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type PhotographerMaxAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
  }

  export type PhotographerCountAggregateInputType = {
    id?: true
    name?: true
    contact?: true
    location?: true
    createdAt?: true
    _all?: true
  }

  export type PhotographerAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Photographer to aggregate.
     */
    where?: PhotographerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photographers to fetch.
     */
    orderBy?: PhotographerOrderByWithRelationInput | PhotographerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PhotographerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photographers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photographers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Photographers
    **/
    _count?: true | PhotographerCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PhotographerAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PhotographerSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PhotographerMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PhotographerMaxAggregateInputType
  }

  export type GetPhotographerAggregateType<T extends PhotographerAggregateArgs> = {
        [P in keyof T & keyof AggregatePhotographer]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePhotographer[P]>
      : GetScalarType<T[P], AggregatePhotographer[P]>
  }




  export type PhotographerGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotographerWhereInput
    orderBy?: PhotographerOrderByWithAggregationInput | PhotographerOrderByWithAggregationInput[]
    by: PhotographerScalarFieldEnum[] | PhotographerScalarFieldEnum
    having?: PhotographerScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PhotographerCountAggregateInputType | true
    _avg?: PhotographerAvgAggregateInputType
    _sum?: PhotographerSumAggregateInputType
    _min?: PhotographerMinAggregateInputType
    _max?: PhotographerMaxAggregateInputType
  }

  export type PhotographerGroupByOutputType = {
    id: number
    name: string
    contact: string | null
    location: string | null
    createdAt: Date
    _count: PhotographerCountAggregateOutputType | null
    _avg: PhotographerAvgAggregateOutputType | null
    _sum: PhotographerSumAggregateOutputType | null
    _min: PhotographerMinAggregateOutputType | null
    _max: PhotographerMaxAggregateOutputType | null
  }

  type GetPhotographerGroupByPayload<T extends PhotographerGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PhotographerGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PhotographerGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PhotographerGroupByOutputType[P]>
            : GetScalarType<T[P], PhotographerGroupByOutputType[P]>
        }
      >
    >


  export type PhotographerSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["photographer"]>



  export type PhotographerSelectScalar = {
    id?: boolean
    name?: boolean
    contact?: boolean
    location?: boolean
    createdAt?: boolean
  }

  export type PhotographerOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "contact" | "location" | "createdAt", ExtArgs["result"]["photographer"]>

  export type $PhotographerPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Photographer"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      contact: string | null
      location: string | null
      createdAt: Date
    }, ExtArgs["result"]["photographer"]>
    composites: {}
  }

  type PhotographerGetPayload<S extends boolean | null | undefined | PhotographerDefaultArgs> = $Result.GetResult<Prisma.$PhotographerPayload, S>

  type PhotographerCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PhotographerFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PhotographerCountAggregateInputType | true
    }

  export interface PhotographerDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Photographer'], meta: { name: 'Photographer' } }
    /**
     * Find zero or one Photographer that matches the filter.
     * @param {PhotographerFindUniqueArgs} args - Arguments to find a Photographer
     * @example
     * // Get one Photographer
     * const photographer = await prisma.photographer.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PhotographerFindUniqueArgs>(args: SelectSubset<T, PhotographerFindUniqueArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Photographer that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PhotographerFindUniqueOrThrowArgs} args - Arguments to find a Photographer
     * @example
     * // Get one Photographer
     * const photographer = await prisma.photographer.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PhotographerFindUniqueOrThrowArgs>(args: SelectSubset<T, PhotographerFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Photographer that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerFindFirstArgs} args - Arguments to find a Photographer
     * @example
     * // Get one Photographer
     * const photographer = await prisma.photographer.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PhotographerFindFirstArgs>(args?: SelectSubset<T, PhotographerFindFirstArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Photographer that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerFindFirstOrThrowArgs} args - Arguments to find a Photographer
     * @example
     * // Get one Photographer
     * const photographer = await prisma.photographer.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PhotographerFindFirstOrThrowArgs>(args?: SelectSubset<T, PhotographerFindFirstOrThrowArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Photographers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Photographers
     * const photographers = await prisma.photographer.findMany()
     * 
     * // Get first 10 Photographers
     * const photographers = await prisma.photographer.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const photographerWithIdOnly = await prisma.photographer.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PhotographerFindManyArgs>(args?: SelectSubset<T, PhotographerFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Photographer.
     * @param {PhotographerCreateArgs} args - Arguments to create a Photographer.
     * @example
     * // Create one Photographer
     * const Photographer = await prisma.photographer.create({
     *   data: {
     *     // ... data to create a Photographer
     *   }
     * })
     * 
     */
    create<T extends PhotographerCreateArgs>(args: SelectSubset<T, PhotographerCreateArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Photographers.
     * @param {PhotographerCreateManyArgs} args - Arguments to create many Photographers.
     * @example
     * // Create many Photographers
     * const photographer = await prisma.photographer.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PhotographerCreateManyArgs>(args?: SelectSubset<T, PhotographerCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Photographer.
     * @param {PhotographerDeleteArgs} args - Arguments to delete one Photographer.
     * @example
     * // Delete one Photographer
     * const Photographer = await prisma.photographer.delete({
     *   where: {
     *     // ... filter to delete one Photographer
     *   }
     * })
     * 
     */
    delete<T extends PhotographerDeleteArgs>(args: SelectSubset<T, PhotographerDeleteArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Photographer.
     * @param {PhotographerUpdateArgs} args - Arguments to update one Photographer.
     * @example
     * // Update one Photographer
     * const photographer = await prisma.photographer.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PhotographerUpdateArgs>(args: SelectSubset<T, PhotographerUpdateArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Photographers.
     * @param {PhotographerDeleteManyArgs} args - Arguments to filter Photographers to delete.
     * @example
     * // Delete a few Photographers
     * const { count } = await prisma.photographer.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PhotographerDeleteManyArgs>(args?: SelectSubset<T, PhotographerDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Photographers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Photographers
     * const photographer = await prisma.photographer.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PhotographerUpdateManyArgs>(args: SelectSubset<T, PhotographerUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Photographer.
     * @param {PhotographerUpsertArgs} args - Arguments to update or create a Photographer.
     * @example
     * // Update or create a Photographer
     * const photographer = await prisma.photographer.upsert({
     *   create: {
     *     // ... data to create a Photographer
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Photographer we want to update
     *   }
     * })
     */
    upsert<T extends PhotographerUpsertArgs>(args: SelectSubset<T, PhotographerUpsertArgs<ExtArgs>>): Prisma__PhotographerClient<$Result.GetResult<Prisma.$PhotographerPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Photographers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerCountArgs} args - Arguments to filter Photographers to count.
     * @example
     * // Count the number of Photographers
     * const count = await prisma.photographer.count({
     *   where: {
     *     // ... the filter for the Photographers we want to count
     *   }
     * })
    **/
    count<T extends PhotographerCountArgs>(
      args?: Subset<T, PhotographerCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PhotographerCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Photographer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PhotographerAggregateArgs>(args: Subset<T, PhotographerAggregateArgs>): Prisma.PrismaPromise<GetPhotographerAggregateType<T>>

    /**
     * Group by Photographer.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotographerGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PhotographerGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PhotographerGroupByArgs['orderBy'] }
        : { orderBy?: PhotographerGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PhotographerGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPhotographerGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Photographer model
   */
  readonly fields: PhotographerFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Photographer.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PhotographerClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Photographer model
   */
  interface PhotographerFieldRefs {
    readonly id: FieldRef<"Photographer", 'Int'>
    readonly name: FieldRef<"Photographer", 'String'>
    readonly contact: FieldRef<"Photographer", 'String'>
    readonly location: FieldRef<"Photographer", 'String'>
    readonly createdAt: FieldRef<"Photographer", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Photographer findUnique
   */
  export type PhotographerFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter, which Photographer to fetch.
     */
    where: PhotographerWhereUniqueInput
  }

  /**
   * Photographer findUniqueOrThrow
   */
  export type PhotographerFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter, which Photographer to fetch.
     */
    where: PhotographerWhereUniqueInput
  }

  /**
   * Photographer findFirst
   */
  export type PhotographerFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter, which Photographer to fetch.
     */
    where?: PhotographerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photographers to fetch.
     */
    orderBy?: PhotographerOrderByWithRelationInput | PhotographerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Photographers.
     */
    cursor?: PhotographerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photographers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photographers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Photographers.
     */
    distinct?: PhotographerScalarFieldEnum | PhotographerScalarFieldEnum[]
  }

  /**
   * Photographer findFirstOrThrow
   */
  export type PhotographerFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter, which Photographer to fetch.
     */
    where?: PhotographerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photographers to fetch.
     */
    orderBy?: PhotographerOrderByWithRelationInput | PhotographerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Photographers.
     */
    cursor?: PhotographerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photographers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photographers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Photographers.
     */
    distinct?: PhotographerScalarFieldEnum | PhotographerScalarFieldEnum[]
  }

  /**
   * Photographer findMany
   */
  export type PhotographerFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter, which Photographers to fetch.
     */
    where?: PhotographerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photographers to fetch.
     */
    orderBy?: PhotographerOrderByWithRelationInput | PhotographerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Photographers.
     */
    cursor?: PhotographerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photographers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photographers.
     */
    skip?: number
    distinct?: PhotographerScalarFieldEnum | PhotographerScalarFieldEnum[]
  }

  /**
   * Photographer create
   */
  export type PhotographerCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * The data needed to create a Photographer.
     */
    data: XOR<PhotographerCreateInput, PhotographerUncheckedCreateInput>
  }

  /**
   * Photographer createMany
   */
  export type PhotographerCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Photographers.
     */
    data: PhotographerCreateManyInput | PhotographerCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Photographer update
   */
  export type PhotographerUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * The data needed to update a Photographer.
     */
    data: XOR<PhotographerUpdateInput, PhotographerUncheckedUpdateInput>
    /**
     * Choose, which Photographer to update.
     */
    where: PhotographerWhereUniqueInput
  }

  /**
   * Photographer updateMany
   */
  export type PhotographerUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Photographers.
     */
    data: XOR<PhotographerUpdateManyMutationInput, PhotographerUncheckedUpdateManyInput>
    /**
     * Filter which Photographers to update
     */
    where?: PhotographerWhereInput
    /**
     * Limit how many Photographers to update.
     */
    limit?: number
  }

  /**
   * Photographer upsert
   */
  export type PhotographerUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * The filter to search for the Photographer to update in case it exists.
     */
    where: PhotographerWhereUniqueInput
    /**
     * In case the Photographer found by the `where` argument doesn't exist, create a new Photographer with this data.
     */
    create: XOR<PhotographerCreateInput, PhotographerUncheckedCreateInput>
    /**
     * In case the Photographer was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PhotographerUpdateInput, PhotographerUncheckedUpdateInput>
  }

  /**
   * Photographer delete
   */
  export type PhotographerDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
    /**
     * Filter which Photographer to delete.
     */
    where: PhotographerWhereUniqueInput
  }

  /**
   * Photographer deleteMany
   */
  export type PhotographerDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Photographers to delete
     */
    where?: PhotographerWhereInput
    /**
     * Limit how many Photographers to delete.
     */
    limit?: number
  }

  /**
   * Photographer without action
   */
  export type PhotographerDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photographer
     */
    select?: PhotographerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photographer
     */
    omit?: PhotographerOmit<ExtArgs> | null
  }


  /**
   * Model EventType
   */

  export type AggregateEventType = {
    _count: EventTypeCountAggregateOutputType | null
    _avg: EventTypeAvgAggregateOutputType | null
    _sum: EventTypeSumAggregateOutputType | null
    _min: EventTypeMinAggregateOutputType | null
    _max: EventTypeMaxAggregateOutputType | null
  }

  export type EventTypeAvgAggregateOutputType = {
    id: number | null
    events: number | null
  }

  export type EventTypeSumAggregateOutputType = {
    id: number | null
    events: number | null
  }

  export type EventTypeMinAggregateOutputType = {
    id: number | null
    name: string | null
    color: string | null
    events: number | null
    active: boolean | null
    description: string | null
    category: string | null
    subEvents: string | null
    createdAt: Date | null
  }

  export type EventTypeMaxAggregateOutputType = {
    id: number | null
    name: string | null
    color: string | null
    events: number | null
    active: boolean | null
    description: string | null
    category: string | null
    subEvents: string | null
    createdAt: Date | null
  }

  export type EventTypeCountAggregateOutputType = {
    id: number
    name: number
    color: number
    events: number
    active: number
    description: number
    category: number
    subEvents: number
    createdAt: number
    _all: number
  }


  export type EventTypeAvgAggregateInputType = {
    id?: true
    events?: true
  }

  export type EventTypeSumAggregateInputType = {
    id?: true
    events?: true
  }

  export type EventTypeMinAggregateInputType = {
    id?: true
    name?: true
    color?: true
    events?: true
    active?: true
    description?: true
    category?: true
    subEvents?: true
    createdAt?: true
  }

  export type EventTypeMaxAggregateInputType = {
    id?: true
    name?: true
    color?: true
    events?: true
    active?: true
    description?: true
    category?: true
    subEvents?: true
    createdAt?: true
  }

  export type EventTypeCountAggregateInputType = {
    id?: true
    name?: true
    color?: true
    events?: true
    active?: true
    description?: true
    category?: true
    subEvents?: true
    createdAt?: true
    _all?: true
  }

  export type EventTypeAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which EventType to aggregate.
     */
    where?: EventTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EventTypes to fetch.
     */
    orderBy?: EventTypeOrderByWithRelationInput | EventTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EventTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EventTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EventTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned EventTypes
    **/
    _count?: true | EventTypeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EventTypeAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EventTypeSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EventTypeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EventTypeMaxAggregateInputType
  }

  export type GetEventTypeAggregateType<T extends EventTypeAggregateArgs> = {
        [P in keyof T & keyof AggregateEventType]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEventType[P]>
      : GetScalarType<T[P], AggregateEventType[P]>
  }




  export type EventTypeGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EventTypeWhereInput
    orderBy?: EventTypeOrderByWithAggregationInput | EventTypeOrderByWithAggregationInput[]
    by: EventTypeScalarFieldEnum[] | EventTypeScalarFieldEnum
    having?: EventTypeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EventTypeCountAggregateInputType | true
    _avg?: EventTypeAvgAggregateInputType
    _sum?: EventTypeSumAggregateInputType
    _min?: EventTypeMinAggregateInputType
    _max?: EventTypeMaxAggregateInputType
  }

  export type EventTypeGroupByOutputType = {
    id: number
    name: string
    color: string
    events: number
    active: boolean
    description: string | null
    category: string | null
    subEvents: string | null
    createdAt: Date
    _count: EventTypeCountAggregateOutputType | null
    _avg: EventTypeAvgAggregateOutputType | null
    _sum: EventTypeSumAggregateOutputType | null
    _min: EventTypeMinAggregateOutputType | null
    _max: EventTypeMaxAggregateOutputType | null
  }

  type GetEventTypeGroupByPayload<T extends EventTypeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EventTypeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EventTypeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EventTypeGroupByOutputType[P]>
            : GetScalarType<T[P], EventTypeGroupByOutputType[P]>
        }
      >
    >


  export type EventTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    color?: boolean
    events?: boolean
    active?: boolean
    description?: boolean
    category?: boolean
    subEvents?: boolean
    createdAt?: boolean
    venues?: boolean | EventType$venuesArgs<ExtArgs>
    _count?: boolean | EventTypeCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["eventType"]>



  export type EventTypeSelectScalar = {
    id?: boolean
    name?: boolean
    color?: boolean
    events?: boolean
    active?: boolean
    description?: boolean
    category?: boolean
    subEvents?: boolean
    createdAt?: boolean
  }

  export type EventTypeOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "color" | "events" | "active" | "description" | "category" | "subEvents" | "createdAt", ExtArgs["result"]["eventType"]>
  export type EventTypeInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    venues?: boolean | EventType$venuesArgs<ExtArgs>
    _count?: boolean | EventTypeCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $EventTypePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "EventType"
    objects: {
      venues: Prisma.$VenuePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      color: string
      events: number
      active: boolean
      description: string | null
      category: string | null
      subEvents: string | null
      createdAt: Date
    }, ExtArgs["result"]["eventType"]>
    composites: {}
  }

  type EventTypeGetPayload<S extends boolean | null | undefined | EventTypeDefaultArgs> = $Result.GetResult<Prisma.$EventTypePayload, S>

  type EventTypeCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EventTypeFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EventTypeCountAggregateInputType | true
    }

  export interface EventTypeDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['EventType'], meta: { name: 'EventType' } }
    /**
     * Find zero or one EventType that matches the filter.
     * @param {EventTypeFindUniqueArgs} args - Arguments to find a EventType
     * @example
     * // Get one EventType
     * const eventType = await prisma.eventType.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EventTypeFindUniqueArgs>(args: SelectSubset<T, EventTypeFindUniqueArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one EventType that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EventTypeFindUniqueOrThrowArgs} args - Arguments to find a EventType
     * @example
     * // Get one EventType
     * const eventType = await prisma.eventType.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EventTypeFindUniqueOrThrowArgs>(args: SelectSubset<T, EventTypeFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first EventType that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeFindFirstArgs} args - Arguments to find a EventType
     * @example
     * // Get one EventType
     * const eventType = await prisma.eventType.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EventTypeFindFirstArgs>(args?: SelectSubset<T, EventTypeFindFirstArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first EventType that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeFindFirstOrThrowArgs} args - Arguments to find a EventType
     * @example
     * // Get one EventType
     * const eventType = await prisma.eventType.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EventTypeFindFirstOrThrowArgs>(args?: SelectSubset<T, EventTypeFindFirstOrThrowArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more EventTypes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all EventTypes
     * const eventTypes = await prisma.eventType.findMany()
     * 
     * // Get first 10 EventTypes
     * const eventTypes = await prisma.eventType.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const eventTypeWithIdOnly = await prisma.eventType.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EventTypeFindManyArgs>(args?: SelectSubset<T, EventTypeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a EventType.
     * @param {EventTypeCreateArgs} args - Arguments to create a EventType.
     * @example
     * // Create one EventType
     * const EventType = await prisma.eventType.create({
     *   data: {
     *     // ... data to create a EventType
     *   }
     * })
     * 
     */
    create<T extends EventTypeCreateArgs>(args: SelectSubset<T, EventTypeCreateArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many EventTypes.
     * @param {EventTypeCreateManyArgs} args - Arguments to create many EventTypes.
     * @example
     * // Create many EventTypes
     * const eventType = await prisma.eventType.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EventTypeCreateManyArgs>(args?: SelectSubset<T, EventTypeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a EventType.
     * @param {EventTypeDeleteArgs} args - Arguments to delete one EventType.
     * @example
     * // Delete one EventType
     * const EventType = await prisma.eventType.delete({
     *   where: {
     *     // ... filter to delete one EventType
     *   }
     * })
     * 
     */
    delete<T extends EventTypeDeleteArgs>(args: SelectSubset<T, EventTypeDeleteArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one EventType.
     * @param {EventTypeUpdateArgs} args - Arguments to update one EventType.
     * @example
     * // Update one EventType
     * const eventType = await prisma.eventType.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EventTypeUpdateArgs>(args: SelectSubset<T, EventTypeUpdateArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more EventTypes.
     * @param {EventTypeDeleteManyArgs} args - Arguments to filter EventTypes to delete.
     * @example
     * // Delete a few EventTypes
     * const { count } = await prisma.eventType.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EventTypeDeleteManyArgs>(args?: SelectSubset<T, EventTypeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more EventTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many EventTypes
     * const eventType = await prisma.eventType.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EventTypeUpdateManyArgs>(args: SelectSubset<T, EventTypeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one EventType.
     * @param {EventTypeUpsertArgs} args - Arguments to update or create a EventType.
     * @example
     * // Update or create a EventType
     * const eventType = await prisma.eventType.upsert({
     *   create: {
     *     // ... data to create a EventType
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the EventType we want to update
     *   }
     * })
     */
    upsert<T extends EventTypeUpsertArgs>(args: SelectSubset<T, EventTypeUpsertArgs<ExtArgs>>): Prisma__EventTypeClient<$Result.GetResult<Prisma.$EventTypePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of EventTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeCountArgs} args - Arguments to filter EventTypes to count.
     * @example
     * // Count the number of EventTypes
     * const count = await prisma.eventType.count({
     *   where: {
     *     // ... the filter for the EventTypes we want to count
     *   }
     * })
    **/
    count<T extends EventTypeCountArgs>(
      args?: Subset<T, EventTypeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EventTypeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a EventType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EventTypeAggregateArgs>(args: Subset<T, EventTypeAggregateArgs>): Prisma.PrismaPromise<GetEventTypeAggregateType<T>>

    /**
     * Group by EventType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventTypeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EventTypeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EventTypeGroupByArgs['orderBy'] }
        : { orderBy?: EventTypeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EventTypeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEventTypeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the EventType model
   */
  readonly fields: EventTypeFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for EventType.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EventTypeClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    venues<T extends EventType$venuesArgs<ExtArgs> = {}>(args?: Subset<T, EventType$venuesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VenuePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the EventType model
   */
  interface EventTypeFieldRefs {
    readonly id: FieldRef<"EventType", 'Int'>
    readonly name: FieldRef<"EventType", 'String'>
    readonly color: FieldRef<"EventType", 'String'>
    readonly events: FieldRef<"EventType", 'Int'>
    readonly active: FieldRef<"EventType", 'Boolean'>
    readonly description: FieldRef<"EventType", 'String'>
    readonly category: FieldRef<"EventType", 'String'>
    readonly subEvents: FieldRef<"EventType", 'String'>
    readonly createdAt: FieldRef<"EventType", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * EventType findUnique
   */
  export type EventTypeFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter, which EventType to fetch.
     */
    where: EventTypeWhereUniqueInput
  }

  /**
   * EventType findUniqueOrThrow
   */
  export type EventTypeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter, which EventType to fetch.
     */
    where: EventTypeWhereUniqueInput
  }

  /**
   * EventType findFirst
   */
  export type EventTypeFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter, which EventType to fetch.
     */
    where?: EventTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EventTypes to fetch.
     */
    orderBy?: EventTypeOrderByWithRelationInput | EventTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for EventTypes.
     */
    cursor?: EventTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EventTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EventTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of EventTypes.
     */
    distinct?: EventTypeScalarFieldEnum | EventTypeScalarFieldEnum[]
  }

  /**
   * EventType findFirstOrThrow
   */
  export type EventTypeFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter, which EventType to fetch.
     */
    where?: EventTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EventTypes to fetch.
     */
    orderBy?: EventTypeOrderByWithRelationInput | EventTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for EventTypes.
     */
    cursor?: EventTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EventTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EventTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of EventTypes.
     */
    distinct?: EventTypeScalarFieldEnum | EventTypeScalarFieldEnum[]
  }

  /**
   * EventType findMany
   */
  export type EventTypeFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter, which EventTypes to fetch.
     */
    where?: EventTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EventTypes to fetch.
     */
    orderBy?: EventTypeOrderByWithRelationInput | EventTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing EventTypes.
     */
    cursor?: EventTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EventTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EventTypes.
     */
    skip?: number
    distinct?: EventTypeScalarFieldEnum | EventTypeScalarFieldEnum[]
  }

  /**
   * EventType create
   */
  export type EventTypeCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * The data needed to create a EventType.
     */
    data: XOR<EventTypeCreateInput, EventTypeUncheckedCreateInput>
  }

  /**
   * EventType createMany
   */
  export type EventTypeCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many EventTypes.
     */
    data: EventTypeCreateManyInput | EventTypeCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * EventType update
   */
  export type EventTypeUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * The data needed to update a EventType.
     */
    data: XOR<EventTypeUpdateInput, EventTypeUncheckedUpdateInput>
    /**
     * Choose, which EventType to update.
     */
    where: EventTypeWhereUniqueInput
  }

  /**
   * EventType updateMany
   */
  export type EventTypeUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update EventTypes.
     */
    data: XOR<EventTypeUpdateManyMutationInput, EventTypeUncheckedUpdateManyInput>
    /**
     * Filter which EventTypes to update
     */
    where?: EventTypeWhereInput
    /**
     * Limit how many EventTypes to update.
     */
    limit?: number
  }

  /**
   * EventType upsert
   */
  export type EventTypeUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * The filter to search for the EventType to update in case it exists.
     */
    where: EventTypeWhereUniqueInput
    /**
     * In case the EventType found by the `where` argument doesn't exist, create a new EventType with this data.
     */
    create: XOR<EventTypeCreateInput, EventTypeUncheckedCreateInput>
    /**
     * In case the EventType was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EventTypeUpdateInput, EventTypeUncheckedUpdateInput>
  }

  /**
   * EventType delete
   */
  export type EventTypeDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
    /**
     * Filter which EventType to delete.
     */
    where: EventTypeWhereUniqueInput
  }

  /**
   * EventType deleteMany
   */
  export type EventTypeDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which EventTypes to delete
     */
    where?: EventTypeWhereInput
    /**
     * Limit how many EventTypes to delete.
     */
    limit?: number
  }

  /**
   * EventType.venues
   */
  export type EventType$venuesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Venue
     */
    select?: VenueSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Venue
     */
    omit?: VenueOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VenueInclude<ExtArgs> | null
    where?: VenueWhereInput
    orderBy?: VenueOrderByWithRelationInput | VenueOrderByWithRelationInput[]
    cursor?: VenueWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VenueScalarFieldEnum | VenueScalarFieldEnum[]
  }

  /**
   * EventType without action
   */
  export type EventTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventType
     */
    select?: EventTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EventType
     */
    omit?: EventTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EventTypeInclude<ExtArgs> | null
  }


  /**
   * Model Vendor
   */

  export type AggregateVendor = {
    _count: VendorCountAggregateOutputType | null
    _avg: VendorAvgAggregateOutputType | null
    _sum: VendorSumAggregateOutputType | null
    _min: VendorMinAggregateOutputType | null
    _max: VendorMaxAggregateOutputType | null
  }

  export type VendorAvgAggregateOutputType = {
    id: number | null
  }

  export type VendorSumAggregateOutputType = {
    id: number | null
  }

  export type VendorMinAggregateOutputType = {
    id: number | null
    name: string | null
    category: string | null
    contact: string | null
    email: string | null
    address: string | null
    website: string | null
    createdAt: Date | null
  }

  export type VendorMaxAggregateOutputType = {
    id: number | null
    name: string | null
    category: string | null
    contact: string | null
    email: string | null
    address: string | null
    website: string | null
    createdAt: Date | null
  }

  export type VendorCountAggregateOutputType = {
    id: number
    name: number
    category: number
    contact: number
    email: number
    address: number
    website: number
    createdAt: number
    _all: number
  }


  export type VendorAvgAggregateInputType = {
    id?: true
  }

  export type VendorSumAggregateInputType = {
    id?: true
  }

  export type VendorMinAggregateInputType = {
    id?: true
    name?: true
    category?: true
    contact?: true
    email?: true
    address?: true
    website?: true
    createdAt?: true
  }

  export type VendorMaxAggregateInputType = {
    id?: true
    name?: true
    category?: true
    contact?: true
    email?: true
    address?: true
    website?: true
    createdAt?: true
  }

  export type VendorCountAggregateInputType = {
    id?: true
    name?: true
    category?: true
    contact?: true
    email?: true
    address?: true
    website?: true
    createdAt?: true
    _all?: true
  }

  export type VendorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Vendor to aggregate.
     */
    where?: VendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vendors to fetch.
     */
    orderBy?: VendorOrderByWithRelationInput | VendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Vendors
    **/
    _count?: true | VendorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VendorAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VendorSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VendorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VendorMaxAggregateInputType
  }

  export type GetVendorAggregateType<T extends VendorAggregateArgs> = {
        [P in keyof T & keyof AggregateVendor]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVendor[P]>
      : GetScalarType<T[P], AggregateVendor[P]>
  }




  export type VendorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VendorWhereInput
    orderBy?: VendorOrderByWithAggregationInput | VendorOrderByWithAggregationInput[]
    by: VendorScalarFieldEnum[] | VendorScalarFieldEnum
    having?: VendorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VendorCountAggregateInputType | true
    _avg?: VendorAvgAggregateInputType
    _sum?: VendorSumAggregateInputType
    _min?: VendorMinAggregateInputType
    _max?: VendorMaxAggregateInputType
  }

  export type VendorGroupByOutputType = {
    id: number
    name: string
    category: string
    contact: string
    email: string
    address: string
    website: string | null
    createdAt: Date
    _count: VendorCountAggregateOutputType | null
    _avg: VendorAvgAggregateOutputType | null
    _sum: VendorSumAggregateOutputType | null
    _min: VendorMinAggregateOutputType | null
    _max: VendorMaxAggregateOutputType | null
  }

  type GetVendorGroupByPayload<T extends VendorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VendorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VendorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VendorGroupByOutputType[P]>
            : GetScalarType<T[P], VendorGroupByOutputType[P]>
        }
      >
    >


  export type VendorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    category?: boolean
    contact?: boolean
    email?: boolean
    address?: boolean
    website?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["vendor"]>



  export type VendorSelectScalar = {
    id?: boolean
    name?: boolean
    category?: boolean
    contact?: boolean
    email?: boolean
    address?: boolean
    website?: boolean
    createdAt?: boolean
  }

  export type VendorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "category" | "contact" | "email" | "address" | "website" | "createdAt", ExtArgs["result"]["vendor"]>

  export type $VendorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Vendor"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      category: string
      contact: string
      email: string
      address: string
      website: string | null
      createdAt: Date
    }, ExtArgs["result"]["vendor"]>
    composites: {}
  }

  type VendorGetPayload<S extends boolean | null | undefined | VendorDefaultArgs> = $Result.GetResult<Prisma.$VendorPayload, S>

  type VendorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VendorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VendorCountAggregateInputType | true
    }

  export interface VendorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Vendor'], meta: { name: 'Vendor' } }
    /**
     * Find zero or one Vendor that matches the filter.
     * @param {VendorFindUniqueArgs} args - Arguments to find a Vendor
     * @example
     * // Get one Vendor
     * const vendor = await prisma.vendor.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VendorFindUniqueArgs>(args: SelectSubset<T, VendorFindUniqueArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Vendor that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VendorFindUniqueOrThrowArgs} args - Arguments to find a Vendor
     * @example
     * // Get one Vendor
     * const vendor = await prisma.vendor.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VendorFindUniqueOrThrowArgs>(args: SelectSubset<T, VendorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Vendor that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorFindFirstArgs} args - Arguments to find a Vendor
     * @example
     * // Get one Vendor
     * const vendor = await prisma.vendor.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VendorFindFirstArgs>(args?: SelectSubset<T, VendorFindFirstArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Vendor that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorFindFirstOrThrowArgs} args - Arguments to find a Vendor
     * @example
     * // Get one Vendor
     * const vendor = await prisma.vendor.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VendorFindFirstOrThrowArgs>(args?: SelectSubset<T, VendorFindFirstOrThrowArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Vendors that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Vendors
     * const vendors = await prisma.vendor.findMany()
     * 
     * // Get first 10 Vendors
     * const vendors = await prisma.vendor.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const vendorWithIdOnly = await prisma.vendor.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VendorFindManyArgs>(args?: SelectSubset<T, VendorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Vendor.
     * @param {VendorCreateArgs} args - Arguments to create a Vendor.
     * @example
     * // Create one Vendor
     * const Vendor = await prisma.vendor.create({
     *   data: {
     *     // ... data to create a Vendor
     *   }
     * })
     * 
     */
    create<T extends VendorCreateArgs>(args: SelectSubset<T, VendorCreateArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Vendors.
     * @param {VendorCreateManyArgs} args - Arguments to create many Vendors.
     * @example
     * // Create many Vendors
     * const vendor = await prisma.vendor.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VendorCreateManyArgs>(args?: SelectSubset<T, VendorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Vendor.
     * @param {VendorDeleteArgs} args - Arguments to delete one Vendor.
     * @example
     * // Delete one Vendor
     * const Vendor = await prisma.vendor.delete({
     *   where: {
     *     // ... filter to delete one Vendor
     *   }
     * })
     * 
     */
    delete<T extends VendorDeleteArgs>(args: SelectSubset<T, VendorDeleteArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Vendor.
     * @param {VendorUpdateArgs} args - Arguments to update one Vendor.
     * @example
     * // Update one Vendor
     * const vendor = await prisma.vendor.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VendorUpdateArgs>(args: SelectSubset<T, VendorUpdateArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Vendors.
     * @param {VendorDeleteManyArgs} args - Arguments to filter Vendors to delete.
     * @example
     * // Delete a few Vendors
     * const { count } = await prisma.vendor.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VendorDeleteManyArgs>(args?: SelectSubset<T, VendorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Vendors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Vendors
     * const vendor = await prisma.vendor.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VendorUpdateManyArgs>(args: SelectSubset<T, VendorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Vendor.
     * @param {VendorUpsertArgs} args - Arguments to update or create a Vendor.
     * @example
     * // Update or create a Vendor
     * const vendor = await prisma.vendor.upsert({
     *   create: {
     *     // ... data to create a Vendor
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Vendor we want to update
     *   }
     * })
     */
    upsert<T extends VendorUpsertArgs>(args: SelectSubset<T, VendorUpsertArgs<ExtArgs>>): Prisma__VendorClient<$Result.GetResult<Prisma.$VendorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Vendors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorCountArgs} args - Arguments to filter Vendors to count.
     * @example
     * // Count the number of Vendors
     * const count = await prisma.vendor.count({
     *   where: {
     *     // ... the filter for the Vendors we want to count
     *   }
     * })
    **/
    count<T extends VendorCountArgs>(
      args?: Subset<T, VendorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VendorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Vendor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VendorAggregateArgs>(args: Subset<T, VendorAggregateArgs>): Prisma.PrismaPromise<GetVendorAggregateType<T>>

    /**
     * Group by Vendor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VendorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VendorGroupByArgs['orderBy'] }
        : { orderBy?: VendorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VendorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVendorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Vendor model
   */
  readonly fields: VendorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Vendor.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VendorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Vendor model
   */
  interface VendorFieldRefs {
    readonly id: FieldRef<"Vendor", 'Int'>
    readonly name: FieldRef<"Vendor", 'String'>
    readonly category: FieldRef<"Vendor", 'String'>
    readonly contact: FieldRef<"Vendor", 'String'>
    readonly email: FieldRef<"Vendor", 'String'>
    readonly address: FieldRef<"Vendor", 'String'>
    readonly website: FieldRef<"Vendor", 'String'>
    readonly createdAt: FieldRef<"Vendor", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Vendor findUnique
   */
  export type VendorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter, which Vendor to fetch.
     */
    where: VendorWhereUniqueInput
  }

  /**
   * Vendor findUniqueOrThrow
   */
  export type VendorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter, which Vendor to fetch.
     */
    where: VendorWhereUniqueInput
  }

  /**
   * Vendor findFirst
   */
  export type VendorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter, which Vendor to fetch.
     */
    where?: VendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vendors to fetch.
     */
    orderBy?: VendorOrderByWithRelationInput | VendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Vendors.
     */
    cursor?: VendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Vendors.
     */
    distinct?: VendorScalarFieldEnum | VendorScalarFieldEnum[]
  }

  /**
   * Vendor findFirstOrThrow
   */
  export type VendorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter, which Vendor to fetch.
     */
    where?: VendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vendors to fetch.
     */
    orderBy?: VendorOrderByWithRelationInput | VendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Vendors.
     */
    cursor?: VendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vendors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Vendors.
     */
    distinct?: VendorScalarFieldEnum | VendorScalarFieldEnum[]
  }

  /**
   * Vendor findMany
   */
  export type VendorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter, which Vendors to fetch.
     */
    where?: VendorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vendors to fetch.
     */
    orderBy?: VendorOrderByWithRelationInput | VendorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Vendors.
     */
    cursor?: VendorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vendors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vendors.
     */
    skip?: number
    distinct?: VendorScalarFieldEnum | VendorScalarFieldEnum[]
  }

  /**
   * Vendor create
   */
  export type VendorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * The data needed to create a Vendor.
     */
    data: XOR<VendorCreateInput, VendorUncheckedCreateInput>
  }

  /**
   * Vendor createMany
   */
  export type VendorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Vendors.
     */
    data: VendorCreateManyInput | VendorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Vendor update
   */
  export type VendorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * The data needed to update a Vendor.
     */
    data: XOR<VendorUpdateInput, VendorUncheckedUpdateInput>
    /**
     * Choose, which Vendor to update.
     */
    where: VendorWhereUniqueInput
  }

  /**
   * Vendor updateMany
   */
  export type VendorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Vendors.
     */
    data: XOR<VendorUpdateManyMutationInput, VendorUncheckedUpdateManyInput>
    /**
     * Filter which Vendors to update
     */
    where?: VendorWhereInput
    /**
     * Limit how many Vendors to update.
     */
    limit?: number
  }

  /**
   * Vendor upsert
   */
  export type VendorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * The filter to search for the Vendor to update in case it exists.
     */
    where: VendorWhereUniqueInput
    /**
     * In case the Vendor found by the `where` argument doesn't exist, create a new Vendor with this data.
     */
    create: XOR<VendorCreateInput, VendorUncheckedCreateInput>
    /**
     * In case the Vendor was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VendorUpdateInput, VendorUncheckedUpdateInput>
  }

  /**
   * Vendor delete
   */
  export type VendorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
    /**
     * Filter which Vendor to delete.
     */
    where: VendorWhereUniqueInput
  }

  /**
   * Vendor deleteMany
   */
  export type VendorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Vendors to delete
     */
    where?: VendorWhereInput
    /**
     * Limit how many Vendors to delete.
     */
    limit?: number
  }

  /**
   * Vendor without action
   */
  export type VendorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vendor
     */
    select?: VendorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Vendor
     */
    omit?: VendorOmit<ExtArgs> | null
  }


  /**
   * Model ContentPage
   */

  export type AggregateContentPage = {
    _count: ContentPageCountAggregateOutputType | null
    _avg: ContentPageAvgAggregateOutputType | null
    _sum: ContentPageSumAggregateOutputType | null
    _min: ContentPageMinAggregateOutputType | null
    _max: ContentPageMaxAggregateOutputType | null
  }

  export type ContentPageAvgAggregateOutputType = {
    id: number | null
  }

  export type ContentPageSumAggregateOutputType = {
    id: number | null
  }

  export type ContentPageMinAggregateOutputType = {
    id: number | null
    title: string | null
    content: string | null
    status: $Enums.ContentStatus | null
    lastModified: string | null
    slug: string | null
    createdAt: Date | null
  }

  export type ContentPageMaxAggregateOutputType = {
    id: number | null
    title: string | null
    content: string | null
    status: $Enums.ContentStatus | null
    lastModified: string | null
    slug: string | null
    createdAt: Date | null
  }

  export type ContentPageCountAggregateOutputType = {
    id: number
    title: number
    content: number
    status: number
    lastModified: number
    slug: number
    createdAt: number
    _all: number
  }


  export type ContentPageAvgAggregateInputType = {
    id?: true
  }

  export type ContentPageSumAggregateInputType = {
    id?: true
  }

  export type ContentPageMinAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    lastModified?: true
    slug?: true
    createdAt?: true
  }

  export type ContentPageMaxAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    lastModified?: true
    slug?: true
    createdAt?: true
  }

  export type ContentPageCountAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    lastModified?: true
    slug?: true
    createdAt?: true
    _all?: true
  }

  export type ContentPageAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ContentPage to aggregate.
     */
    where?: ContentPageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ContentPages to fetch.
     */
    orderBy?: ContentPageOrderByWithRelationInput | ContentPageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ContentPageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ContentPages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ContentPages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ContentPages
    **/
    _count?: true | ContentPageCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ContentPageAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ContentPageSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ContentPageMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ContentPageMaxAggregateInputType
  }

  export type GetContentPageAggregateType<T extends ContentPageAggregateArgs> = {
        [P in keyof T & keyof AggregateContentPage]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateContentPage[P]>
      : GetScalarType<T[P], AggregateContentPage[P]>
  }




  export type ContentPageGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContentPageWhereInput
    orderBy?: ContentPageOrderByWithAggregationInput | ContentPageOrderByWithAggregationInput[]
    by: ContentPageScalarFieldEnum[] | ContentPageScalarFieldEnum
    having?: ContentPageScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ContentPageCountAggregateInputType | true
    _avg?: ContentPageAvgAggregateInputType
    _sum?: ContentPageSumAggregateInputType
    _min?: ContentPageMinAggregateInputType
    _max?: ContentPageMaxAggregateInputType
  }

  export type ContentPageGroupByOutputType = {
    id: number
    title: string
    content: string
    status: $Enums.ContentStatus
    lastModified: string
    slug: string
    createdAt: Date
    _count: ContentPageCountAggregateOutputType | null
    _avg: ContentPageAvgAggregateOutputType | null
    _sum: ContentPageSumAggregateOutputType | null
    _min: ContentPageMinAggregateOutputType | null
    _max: ContentPageMaxAggregateOutputType | null
  }

  type GetContentPageGroupByPayload<T extends ContentPageGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ContentPageGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ContentPageGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ContentPageGroupByOutputType[P]>
            : GetScalarType<T[P], ContentPageGroupByOutputType[P]>
        }
      >
    >


  export type ContentPageSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    content?: boolean
    status?: boolean
    lastModified?: boolean
    slug?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["contentPage"]>



  export type ContentPageSelectScalar = {
    id?: boolean
    title?: boolean
    content?: boolean
    status?: boolean
    lastModified?: boolean
    slug?: boolean
    createdAt?: boolean
  }

  export type ContentPageOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "title" | "content" | "status" | "lastModified" | "slug" | "createdAt", ExtArgs["result"]["contentPage"]>

  export type $ContentPagePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ContentPage"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      title: string
      content: string
      status: $Enums.ContentStatus
      lastModified: string
      slug: string
      createdAt: Date
    }, ExtArgs["result"]["contentPage"]>
    composites: {}
  }

  type ContentPageGetPayload<S extends boolean | null | undefined | ContentPageDefaultArgs> = $Result.GetResult<Prisma.$ContentPagePayload, S>

  type ContentPageCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ContentPageFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ContentPageCountAggregateInputType | true
    }

  export interface ContentPageDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ContentPage'], meta: { name: 'ContentPage' } }
    /**
     * Find zero or one ContentPage that matches the filter.
     * @param {ContentPageFindUniqueArgs} args - Arguments to find a ContentPage
     * @example
     * // Get one ContentPage
     * const contentPage = await prisma.contentPage.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ContentPageFindUniqueArgs>(args: SelectSubset<T, ContentPageFindUniqueArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ContentPage that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ContentPageFindUniqueOrThrowArgs} args - Arguments to find a ContentPage
     * @example
     * // Get one ContentPage
     * const contentPage = await prisma.contentPage.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ContentPageFindUniqueOrThrowArgs>(args: SelectSubset<T, ContentPageFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ContentPage that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageFindFirstArgs} args - Arguments to find a ContentPage
     * @example
     * // Get one ContentPage
     * const contentPage = await prisma.contentPage.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ContentPageFindFirstArgs>(args?: SelectSubset<T, ContentPageFindFirstArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ContentPage that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageFindFirstOrThrowArgs} args - Arguments to find a ContentPage
     * @example
     * // Get one ContentPage
     * const contentPage = await prisma.contentPage.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ContentPageFindFirstOrThrowArgs>(args?: SelectSubset<T, ContentPageFindFirstOrThrowArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ContentPages that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ContentPages
     * const contentPages = await prisma.contentPage.findMany()
     * 
     * // Get first 10 ContentPages
     * const contentPages = await prisma.contentPage.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const contentPageWithIdOnly = await prisma.contentPage.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ContentPageFindManyArgs>(args?: SelectSubset<T, ContentPageFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ContentPage.
     * @param {ContentPageCreateArgs} args - Arguments to create a ContentPage.
     * @example
     * // Create one ContentPage
     * const ContentPage = await prisma.contentPage.create({
     *   data: {
     *     // ... data to create a ContentPage
     *   }
     * })
     * 
     */
    create<T extends ContentPageCreateArgs>(args: SelectSubset<T, ContentPageCreateArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ContentPages.
     * @param {ContentPageCreateManyArgs} args - Arguments to create many ContentPages.
     * @example
     * // Create many ContentPages
     * const contentPage = await prisma.contentPage.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ContentPageCreateManyArgs>(args?: SelectSubset<T, ContentPageCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ContentPage.
     * @param {ContentPageDeleteArgs} args - Arguments to delete one ContentPage.
     * @example
     * // Delete one ContentPage
     * const ContentPage = await prisma.contentPage.delete({
     *   where: {
     *     // ... filter to delete one ContentPage
     *   }
     * })
     * 
     */
    delete<T extends ContentPageDeleteArgs>(args: SelectSubset<T, ContentPageDeleteArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ContentPage.
     * @param {ContentPageUpdateArgs} args - Arguments to update one ContentPage.
     * @example
     * // Update one ContentPage
     * const contentPage = await prisma.contentPage.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ContentPageUpdateArgs>(args: SelectSubset<T, ContentPageUpdateArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ContentPages.
     * @param {ContentPageDeleteManyArgs} args - Arguments to filter ContentPages to delete.
     * @example
     * // Delete a few ContentPages
     * const { count } = await prisma.contentPage.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ContentPageDeleteManyArgs>(args?: SelectSubset<T, ContentPageDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ContentPages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ContentPages
     * const contentPage = await prisma.contentPage.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ContentPageUpdateManyArgs>(args: SelectSubset<T, ContentPageUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ContentPage.
     * @param {ContentPageUpsertArgs} args - Arguments to update or create a ContentPage.
     * @example
     * // Update or create a ContentPage
     * const contentPage = await prisma.contentPage.upsert({
     *   create: {
     *     // ... data to create a ContentPage
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ContentPage we want to update
     *   }
     * })
     */
    upsert<T extends ContentPageUpsertArgs>(args: SelectSubset<T, ContentPageUpsertArgs<ExtArgs>>): Prisma__ContentPageClient<$Result.GetResult<Prisma.$ContentPagePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ContentPages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageCountArgs} args - Arguments to filter ContentPages to count.
     * @example
     * // Count the number of ContentPages
     * const count = await prisma.contentPage.count({
     *   where: {
     *     // ... the filter for the ContentPages we want to count
     *   }
     * })
    **/
    count<T extends ContentPageCountArgs>(
      args?: Subset<T, ContentPageCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ContentPageCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ContentPage.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ContentPageAggregateArgs>(args: Subset<T, ContentPageAggregateArgs>): Prisma.PrismaPromise<GetContentPageAggregateType<T>>

    /**
     * Group by ContentPage.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContentPageGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ContentPageGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ContentPageGroupByArgs['orderBy'] }
        : { orderBy?: ContentPageGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ContentPageGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetContentPageGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ContentPage model
   */
  readonly fields: ContentPageFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ContentPage.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ContentPageClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ContentPage model
   */
  interface ContentPageFieldRefs {
    readonly id: FieldRef<"ContentPage", 'Int'>
    readonly title: FieldRef<"ContentPage", 'String'>
    readonly content: FieldRef<"ContentPage", 'String'>
    readonly status: FieldRef<"ContentPage", 'ContentStatus'>
    readonly lastModified: FieldRef<"ContentPage", 'String'>
    readonly slug: FieldRef<"ContentPage", 'String'>
    readonly createdAt: FieldRef<"ContentPage", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * ContentPage findUnique
   */
  export type ContentPageFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter, which ContentPage to fetch.
     */
    where: ContentPageWhereUniqueInput
  }

  /**
   * ContentPage findUniqueOrThrow
   */
  export type ContentPageFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter, which ContentPage to fetch.
     */
    where: ContentPageWhereUniqueInput
  }

  /**
   * ContentPage findFirst
   */
  export type ContentPageFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter, which ContentPage to fetch.
     */
    where?: ContentPageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ContentPages to fetch.
     */
    orderBy?: ContentPageOrderByWithRelationInput | ContentPageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ContentPages.
     */
    cursor?: ContentPageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ContentPages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ContentPages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ContentPages.
     */
    distinct?: ContentPageScalarFieldEnum | ContentPageScalarFieldEnum[]
  }

  /**
   * ContentPage findFirstOrThrow
   */
  export type ContentPageFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter, which ContentPage to fetch.
     */
    where?: ContentPageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ContentPages to fetch.
     */
    orderBy?: ContentPageOrderByWithRelationInput | ContentPageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ContentPages.
     */
    cursor?: ContentPageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ContentPages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ContentPages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ContentPages.
     */
    distinct?: ContentPageScalarFieldEnum | ContentPageScalarFieldEnum[]
  }

  /**
   * ContentPage findMany
   */
  export type ContentPageFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter, which ContentPages to fetch.
     */
    where?: ContentPageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ContentPages to fetch.
     */
    orderBy?: ContentPageOrderByWithRelationInput | ContentPageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ContentPages.
     */
    cursor?: ContentPageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ContentPages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ContentPages.
     */
    skip?: number
    distinct?: ContentPageScalarFieldEnum | ContentPageScalarFieldEnum[]
  }

  /**
   * ContentPage create
   */
  export type ContentPageCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * The data needed to create a ContentPage.
     */
    data: XOR<ContentPageCreateInput, ContentPageUncheckedCreateInput>
  }

  /**
   * ContentPage createMany
   */
  export type ContentPageCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ContentPages.
     */
    data: ContentPageCreateManyInput | ContentPageCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ContentPage update
   */
  export type ContentPageUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * The data needed to update a ContentPage.
     */
    data: XOR<ContentPageUpdateInput, ContentPageUncheckedUpdateInput>
    /**
     * Choose, which ContentPage to update.
     */
    where: ContentPageWhereUniqueInput
  }

  /**
   * ContentPage updateMany
   */
  export type ContentPageUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ContentPages.
     */
    data: XOR<ContentPageUpdateManyMutationInput, ContentPageUncheckedUpdateManyInput>
    /**
     * Filter which ContentPages to update
     */
    where?: ContentPageWhereInput
    /**
     * Limit how many ContentPages to update.
     */
    limit?: number
  }

  /**
   * ContentPage upsert
   */
  export type ContentPageUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * The filter to search for the ContentPage to update in case it exists.
     */
    where: ContentPageWhereUniqueInput
    /**
     * In case the ContentPage found by the `where` argument doesn't exist, create a new ContentPage with this data.
     */
    create: XOR<ContentPageCreateInput, ContentPageUncheckedCreateInput>
    /**
     * In case the ContentPage was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ContentPageUpdateInput, ContentPageUncheckedUpdateInput>
  }

  /**
   * ContentPage delete
   */
  export type ContentPageDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
    /**
     * Filter which ContentPage to delete.
     */
    where: ContentPageWhereUniqueInput
  }

  /**
   * ContentPage deleteMany
   */
  export type ContentPageDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ContentPages to delete
     */
    where?: ContentPageWhereInput
    /**
     * Limit how many ContentPages to delete.
     */
    limit?: number
  }

  /**
   * ContentPage without action
   */
  export type ContentPageDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ContentPage
     */
    select?: ContentPageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ContentPage
     */
    omit?: ContentPageOmit<ExtArgs> | null
  }


  /**
   * Model MediaItem
   */

  export type AggregateMediaItem = {
    _count: MediaItemCountAggregateOutputType | null
    _avg: MediaItemAvgAggregateOutputType | null
    _sum: MediaItemSumAggregateOutputType | null
    _min: MediaItemMinAggregateOutputType | null
    _max: MediaItemMaxAggregateOutputType | null
  }

  export type MediaItemAvgAggregateOutputType = {
    id: number | null
  }

  export type MediaItemSumAggregateOutputType = {
    id: number | null
  }

  export type MediaItemMinAggregateOutputType = {
    id: number | null
    name: string | null
    type: $Enums.MediaType | null
    size: string | null
    uploaded: string | null
    url: string | null
    createdAt: Date | null
  }

  export type MediaItemMaxAggregateOutputType = {
    id: number | null
    name: string | null
    type: $Enums.MediaType | null
    size: string | null
    uploaded: string | null
    url: string | null
    createdAt: Date | null
  }

  export type MediaItemCountAggregateOutputType = {
    id: number
    name: number
    type: number
    size: number
    uploaded: number
    url: number
    createdAt: number
    _all: number
  }


  export type MediaItemAvgAggregateInputType = {
    id?: true
  }

  export type MediaItemSumAggregateInputType = {
    id?: true
  }

  export type MediaItemMinAggregateInputType = {
    id?: true
    name?: true
    type?: true
    size?: true
    uploaded?: true
    url?: true
    createdAt?: true
  }

  export type MediaItemMaxAggregateInputType = {
    id?: true
    name?: true
    type?: true
    size?: true
    uploaded?: true
    url?: true
    createdAt?: true
  }

  export type MediaItemCountAggregateInputType = {
    id?: true
    name?: true
    type?: true
    size?: true
    uploaded?: true
    url?: true
    createdAt?: true
    _all?: true
  }

  export type MediaItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MediaItem to aggregate.
     */
    where?: MediaItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MediaItems to fetch.
     */
    orderBy?: MediaItemOrderByWithRelationInput | MediaItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MediaItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MediaItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MediaItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MediaItems
    **/
    _count?: true | MediaItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MediaItemAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MediaItemSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MediaItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MediaItemMaxAggregateInputType
  }

  export type GetMediaItemAggregateType<T extends MediaItemAggregateArgs> = {
        [P in keyof T & keyof AggregateMediaItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMediaItem[P]>
      : GetScalarType<T[P], AggregateMediaItem[P]>
  }




  export type MediaItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MediaItemWhereInput
    orderBy?: MediaItemOrderByWithAggregationInput | MediaItemOrderByWithAggregationInput[]
    by: MediaItemScalarFieldEnum[] | MediaItemScalarFieldEnum
    having?: MediaItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MediaItemCountAggregateInputType | true
    _avg?: MediaItemAvgAggregateInputType
    _sum?: MediaItemSumAggregateInputType
    _min?: MediaItemMinAggregateInputType
    _max?: MediaItemMaxAggregateInputType
  }

  export type MediaItemGroupByOutputType = {
    id: number
    name: string
    type: $Enums.MediaType
    size: string
    uploaded: string
    url: string | null
    createdAt: Date
    _count: MediaItemCountAggregateOutputType | null
    _avg: MediaItemAvgAggregateOutputType | null
    _sum: MediaItemSumAggregateOutputType | null
    _min: MediaItemMinAggregateOutputType | null
    _max: MediaItemMaxAggregateOutputType | null
  }

  type GetMediaItemGroupByPayload<T extends MediaItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MediaItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MediaItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MediaItemGroupByOutputType[P]>
            : GetScalarType<T[P], MediaItemGroupByOutputType[P]>
        }
      >
    >


  export type MediaItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    type?: boolean
    size?: boolean
    uploaded?: boolean
    url?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["mediaItem"]>



  export type MediaItemSelectScalar = {
    id?: boolean
    name?: boolean
    type?: boolean
    size?: boolean
    uploaded?: boolean
    url?: boolean
    createdAt?: boolean
  }

  export type MediaItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "type" | "size" | "uploaded" | "url" | "createdAt", ExtArgs["result"]["mediaItem"]>

  export type $MediaItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MediaItem"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      type: $Enums.MediaType
      size: string
      uploaded: string
      url: string | null
      createdAt: Date
    }, ExtArgs["result"]["mediaItem"]>
    composites: {}
  }

  type MediaItemGetPayload<S extends boolean | null | undefined | MediaItemDefaultArgs> = $Result.GetResult<Prisma.$MediaItemPayload, S>

  type MediaItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MediaItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MediaItemCountAggregateInputType | true
    }

  export interface MediaItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MediaItem'], meta: { name: 'MediaItem' } }
    /**
     * Find zero or one MediaItem that matches the filter.
     * @param {MediaItemFindUniqueArgs} args - Arguments to find a MediaItem
     * @example
     * // Get one MediaItem
     * const mediaItem = await prisma.mediaItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MediaItemFindUniqueArgs>(args: SelectSubset<T, MediaItemFindUniqueArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MediaItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MediaItemFindUniqueOrThrowArgs} args - Arguments to find a MediaItem
     * @example
     * // Get one MediaItem
     * const mediaItem = await prisma.mediaItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MediaItemFindUniqueOrThrowArgs>(args: SelectSubset<T, MediaItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MediaItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemFindFirstArgs} args - Arguments to find a MediaItem
     * @example
     * // Get one MediaItem
     * const mediaItem = await prisma.mediaItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MediaItemFindFirstArgs>(args?: SelectSubset<T, MediaItemFindFirstArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MediaItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemFindFirstOrThrowArgs} args - Arguments to find a MediaItem
     * @example
     * // Get one MediaItem
     * const mediaItem = await prisma.mediaItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MediaItemFindFirstOrThrowArgs>(args?: SelectSubset<T, MediaItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MediaItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MediaItems
     * const mediaItems = await prisma.mediaItem.findMany()
     * 
     * // Get first 10 MediaItems
     * const mediaItems = await prisma.mediaItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const mediaItemWithIdOnly = await prisma.mediaItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MediaItemFindManyArgs>(args?: SelectSubset<T, MediaItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MediaItem.
     * @param {MediaItemCreateArgs} args - Arguments to create a MediaItem.
     * @example
     * // Create one MediaItem
     * const MediaItem = await prisma.mediaItem.create({
     *   data: {
     *     // ... data to create a MediaItem
     *   }
     * })
     * 
     */
    create<T extends MediaItemCreateArgs>(args: SelectSubset<T, MediaItemCreateArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MediaItems.
     * @param {MediaItemCreateManyArgs} args - Arguments to create many MediaItems.
     * @example
     * // Create many MediaItems
     * const mediaItem = await prisma.mediaItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MediaItemCreateManyArgs>(args?: SelectSubset<T, MediaItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a MediaItem.
     * @param {MediaItemDeleteArgs} args - Arguments to delete one MediaItem.
     * @example
     * // Delete one MediaItem
     * const MediaItem = await prisma.mediaItem.delete({
     *   where: {
     *     // ... filter to delete one MediaItem
     *   }
     * })
     * 
     */
    delete<T extends MediaItemDeleteArgs>(args: SelectSubset<T, MediaItemDeleteArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MediaItem.
     * @param {MediaItemUpdateArgs} args - Arguments to update one MediaItem.
     * @example
     * // Update one MediaItem
     * const mediaItem = await prisma.mediaItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MediaItemUpdateArgs>(args: SelectSubset<T, MediaItemUpdateArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MediaItems.
     * @param {MediaItemDeleteManyArgs} args - Arguments to filter MediaItems to delete.
     * @example
     * // Delete a few MediaItems
     * const { count } = await prisma.mediaItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MediaItemDeleteManyArgs>(args?: SelectSubset<T, MediaItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MediaItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MediaItems
     * const mediaItem = await prisma.mediaItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MediaItemUpdateManyArgs>(args: SelectSubset<T, MediaItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one MediaItem.
     * @param {MediaItemUpsertArgs} args - Arguments to update or create a MediaItem.
     * @example
     * // Update or create a MediaItem
     * const mediaItem = await prisma.mediaItem.upsert({
     *   create: {
     *     // ... data to create a MediaItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MediaItem we want to update
     *   }
     * })
     */
    upsert<T extends MediaItemUpsertArgs>(args: SelectSubset<T, MediaItemUpsertArgs<ExtArgs>>): Prisma__MediaItemClient<$Result.GetResult<Prisma.$MediaItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MediaItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemCountArgs} args - Arguments to filter MediaItems to count.
     * @example
     * // Count the number of MediaItems
     * const count = await prisma.mediaItem.count({
     *   where: {
     *     // ... the filter for the MediaItems we want to count
     *   }
     * })
    **/
    count<T extends MediaItemCountArgs>(
      args?: Subset<T, MediaItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MediaItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MediaItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MediaItemAggregateArgs>(args: Subset<T, MediaItemAggregateArgs>): Prisma.PrismaPromise<GetMediaItemAggregateType<T>>

    /**
     * Group by MediaItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MediaItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MediaItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MediaItemGroupByArgs['orderBy'] }
        : { orderBy?: MediaItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MediaItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMediaItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MediaItem model
   */
  readonly fields: MediaItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MediaItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MediaItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MediaItem model
   */
  interface MediaItemFieldRefs {
    readonly id: FieldRef<"MediaItem", 'Int'>
    readonly name: FieldRef<"MediaItem", 'String'>
    readonly type: FieldRef<"MediaItem", 'MediaType'>
    readonly size: FieldRef<"MediaItem", 'String'>
    readonly uploaded: FieldRef<"MediaItem", 'String'>
    readonly url: FieldRef<"MediaItem", 'String'>
    readonly createdAt: FieldRef<"MediaItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MediaItem findUnique
   */
  export type MediaItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter, which MediaItem to fetch.
     */
    where: MediaItemWhereUniqueInput
  }

  /**
   * MediaItem findUniqueOrThrow
   */
  export type MediaItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter, which MediaItem to fetch.
     */
    where: MediaItemWhereUniqueInput
  }

  /**
   * MediaItem findFirst
   */
  export type MediaItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter, which MediaItem to fetch.
     */
    where?: MediaItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MediaItems to fetch.
     */
    orderBy?: MediaItemOrderByWithRelationInput | MediaItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MediaItems.
     */
    cursor?: MediaItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MediaItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MediaItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MediaItems.
     */
    distinct?: MediaItemScalarFieldEnum | MediaItemScalarFieldEnum[]
  }

  /**
   * MediaItem findFirstOrThrow
   */
  export type MediaItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter, which MediaItem to fetch.
     */
    where?: MediaItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MediaItems to fetch.
     */
    orderBy?: MediaItemOrderByWithRelationInput | MediaItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MediaItems.
     */
    cursor?: MediaItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MediaItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MediaItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MediaItems.
     */
    distinct?: MediaItemScalarFieldEnum | MediaItemScalarFieldEnum[]
  }

  /**
   * MediaItem findMany
   */
  export type MediaItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter, which MediaItems to fetch.
     */
    where?: MediaItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MediaItems to fetch.
     */
    orderBy?: MediaItemOrderByWithRelationInput | MediaItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MediaItems.
     */
    cursor?: MediaItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MediaItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MediaItems.
     */
    skip?: number
    distinct?: MediaItemScalarFieldEnum | MediaItemScalarFieldEnum[]
  }

  /**
   * MediaItem create
   */
  export type MediaItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * The data needed to create a MediaItem.
     */
    data: XOR<MediaItemCreateInput, MediaItemUncheckedCreateInput>
  }

  /**
   * MediaItem createMany
   */
  export type MediaItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MediaItems.
     */
    data: MediaItemCreateManyInput | MediaItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MediaItem update
   */
  export type MediaItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * The data needed to update a MediaItem.
     */
    data: XOR<MediaItemUpdateInput, MediaItemUncheckedUpdateInput>
    /**
     * Choose, which MediaItem to update.
     */
    where: MediaItemWhereUniqueInput
  }

  /**
   * MediaItem updateMany
   */
  export type MediaItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MediaItems.
     */
    data: XOR<MediaItemUpdateManyMutationInput, MediaItemUncheckedUpdateManyInput>
    /**
     * Filter which MediaItems to update
     */
    where?: MediaItemWhereInput
    /**
     * Limit how many MediaItems to update.
     */
    limit?: number
  }

  /**
   * MediaItem upsert
   */
  export type MediaItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * The filter to search for the MediaItem to update in case it exists.
     */
    where: MediaItemWhereUniqueInput
    /**
     * In case the MediaItem found by the `where` argument doesn't exist, create a new MediaItem with this data.
     */
    create: XOR<MediaItemCreateInput, MediaItemUncheckedCreateInput>
    /**
     * In case the MediaItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MediaItemUpdateInput, MediaItemUncheckedUpdateInput>
  }

  /**
   * MediaItem delete
   */
  export type MediaItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
    /**
     * Filter which MediaItem to delete.
     */
    where: MediaItemWhereUniqueInput
  }

  /**
   * MediaItem deleteMany
   */
  export type MediaItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MediaItems to delete
     */
    where?: MediaItemWhereInput
    /**
     * Limit how many MediaItems to delete.
     */
    limit?: number
  }

  /**
   * MediaItem without action
   */
  export type MediaItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MediaItem
     */
    select?: MediaItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MediaItem
     */
    omit?: MediaItemOmit<ExtArgs> | null
  }


  /**
   * Model NewsItem
   */

  export type AggregateNewsItem = {
    _count: NewsItemCountAggregateOutputType | null
    _avg: NewsItemAvgAggregateOutputType | null
    _sum: NewsItemSumAggregateOutputType | null
    _min: NewsItemMinAggregateOutputType | null
    _max: NewsItemMaxAggregateOutputType | null
  }

  export type NewsItemAvgAggregateOutputType = {
    id: number | null
    views: number | null
  }

  export type NewsItemSumAggregateOutputType = {
    id: number | null
    views: number | null
  }

  export type NewsItemMinAggregateOutputType = {
    id: number | null
    title: string | null
    content: string | null
    status: $Enums.ContentStatus | null
    date: string | null
    views: number | null
    author: string | null
    tags: string | null
    imageUrl: string | null
    createdAt: Date | null
  }

  export type NewsItemMaxAggregateOutputType = {
    id: number | null
    title: string | null
    content: string | null
    status: $Enums.ContentStatus | null
    date: string | null
    views: number | null
    author: string | null
    tags: string | null
    imageUrl: string | null
    createdAt: Date | null
  }

  export type NewsItemCountAggregateOutputType = {
    id: number
    title: number
    content: number
    status: number
    date: number
    views: number
    author: number
    tags: number
    imageUrl: number
    createdAt: number
    _all: number
  }


  export type NewsItemAvgAggregateInputType = {
    id?: true
    views?: true
  }

  export type NewsItemSumAggregateInputType = {
    id?: true
    views?: true
  }

  export type NewsItemMinAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    date?: true
    views?: true
    author?: true
    tags?: true
    imageUrl?: true
    createdAt?: true
  }

  export type NewsItemMaxAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    date?: true
    views?: true
    author?: true
    tags?: true
    imageUrl?: true
    createdAt?: true
  }

  export type NewsItemCountAggregateInputType = {
    id?: true
    title?: true
    content?: true
    status?: true
    date?: true
    views?: true
    author?: true
    tags?: true
    imageUrl?: true
    createdAt?: true
    _all?: true
  }

  export type NewsItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which NewsItem to aggregate.
     */
    where?: NewsItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NewsItems to fetch.
     */
    orderBy?: NewsItemOrderByWithRelationInput | NewsItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: NewsItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NewsItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NewsItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned NewsItems
    **/
    _count?: true | NewsItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: NewsItemAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: NewsItemSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: NewsItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: NewsItemMaxAggregateInputType
  }

  export type GetNewsItemAggregateType<T extends NewsItemAggregateArgs> = {
        [P in keyof T & keyof AggregateNewsItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateNewsItem[P]>
      : GetScalarType<T[P], AggregateNewsItem[P]>
  }




  export type NewsItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: NewsItemWhereInput
    orderBy?: NewsItemOrderByWithAggregationInput | NewsItemOrderByWithAggregationInput[]
    by: NewsItemScalarFieldEnum[] | NewsItemScalarFieldEnum
    having?: NewsItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: NewsItemCountAggregateInputType | true
    _avg?: NewsItemAvgAggregateInputType
    _sum?: NewsItemSumAggregateInputType
    _min?: NewsItemMinAggregateInputType
    _max?: NewsItemMaxAggregateInputType
  }

  export type NewsItemGroupByOutputType = {
    id: number
    title: string
    content: string
    status: $Enums.ContentStatus
    date: string
    views: number
    author: string | null
    tags: string | null
    imageUrl: string | null
    createdAt: Date
    _count: NewsItemCountAggregateOutputType | null
    _avg: NewsItemAvgAggregateOutputType | null
    _sum: NewsItemSumAggregateOutputType | null
    _min: NewsItemMinAggregateOutputType | null
    _max: NewsItemMaxAggregateOutputType | null
  }

  type GetNewsItemGroupByPayload<T extends NewsItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<NewsItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof NewsItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], NewsItemGroupByOutputType[P]>
            : GetScalarType<T[P], NewsItemGroupByOutputType[P]>
        }
      >
    >


  export type NewsItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    content?: boolean
    status?: boolean
    date?: boolean
    views?: boolean
    author?: boolean
    tags?: boolean
    imageUrl?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["newsItem"]>



  export type NewsItemSelectScalar = {
    id?: boolean
    title?: boolean
    content?: boolean
    status?: boolean
    date?: boolean
    views?: boolean
    author?: boolean
    tags?: boolean
    imageUrl?: boolean
    createdAt?: boolean
  }

  export type NewsItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "title" | "content" | "status" | "date" | "views" | "author" | "tags" | "imageUrl" | "createdAt", ExtArgs["result"]["newsItem"]>

  export type $NewsItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "NewsItem"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      title: string
      content: string
      status: $Enums.ContentStatus
      date: string
      views: number
      author: string | null
      tags: string | null
      imageUrl: string | null
      createdAt: Date
    }, ExtArgs["result"]["newsItem"]>
    composites: {}
  }

  type NewsItemGetPayload<S extends boolean | null | undefined | NewsItemDefaultArgs> = $Result.GetResult<Prisma.$NewsItemPayload, S>

  type NewsItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<NewsItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: NewsItemCountAggregateInputType | true
    }

  export interface NewsItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['NewsItem'], meta: { name: 'NewsItem' } }
    /**
     * Find zero or one NewsItem that matches the filter.
     * @param {NewsItemFindUniqueArgs} args - Arguments to find a NewsItem
     * @example
     * // Get one NewsItem
     * const newsItem = await prisma.newsItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends NewsItemFindUniqueArgs>(args: SelectSubset<T, NewsItemFindUniqueArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one NewsItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {NewsItemFindUniqueOrThrowArgs} args - Arguments to find a NewsItem
     * @example
     * // Get one NewsItem
     * const newsItem = await prisma.newsItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends NewsItemFindUniqueOrThrowArgs>(args: SelectSubset<T, NewsItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first NewsItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemFindFirstArgs} args - Arguments to find a NewsItem
     * @example
     * // Get one NewsItem
     * const newsItem = await prisma.newsItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends NewsItemFindFirstArgs>(args?: SelectSubset<T, NewsItemFindFirstArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first NewsItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemFindFirstOrThrowArgs} args - Arguments to find a NewsItem
     * @example
     * // Get one NewsItem
     * const newsItem = await prisma.newsItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends NewsItemFindFirstOrThrowArgs>(args?: SelectSubset<T, NewsItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more NewsItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all NewsItems
     * const newsItems = await prisma.newsItem.findMany()
     * 
     * // Get first 10 NewsItems
     * const newsItems = await prisma.newsItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const newsItemWithIdOnly = await prisma.newsItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends NewsItemFindManyArgs>(args?: SelectSubset<T, NewsItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a NewsItem.
     * @param {NewsItemCreateArgs} args - Arguments to create a NewsItem.
     * @example
     * // Create one NewsItem
     * const NewsItem = await prisma.newsItem.create({
     *   data: {
     *     // ... data to create a NewsItem
     *   }
     * })
     * 
     */
    create<T extends NewsItemCreateArgs>(args: SelectSubset<T, NewsItemCreateArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many NewsItems.
     * @param {NewsItemCreateManyArgs} args - Arguments to create many NewsItems.
     * @example
     * // Create many NewsItems
     * const newsItem = await prisma.newsItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends NewsItemCreateManyArgs>(args?: SelectSubset<T, NewsItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a NewsItem.
     * @param {NewsItemDeleteArgs} args - Arguments to delete one NewsItem.
     * @example
     * // Delete one NewsItem
     * const NewsItem = await prisma.newsItem.delete({
     *   where: {
     *     // ... filter to delete one NewsItem
     *   }
     * })
     * 
     */
    delete<T extends NewsItemDeleteArgs>(args: SelectSubset<T, NewsItemDeleteArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one NewsItem.
     * @param {NewsItemUpdateArgs} args - Arguments to update one NewsItem.
     * @example
     * // Update one NewsItem
     * const newsItem = await prisma.newsItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends NewsItemUpdateArgs>(args: SelectSubset<T, NewsItemUpdateArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more NewsItems.
     * @param {NewsItemDeleteManyArgs} args - Arguments to filter NewsItems to delete.
     * @example
     * // Delete a few NewsItems
     * const { count } = await prisma.newsItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends NewsItemDeleteManyArgs>(args?: SelectSubset<T, NewsItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more NewsItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many NewsItems
     * const newsItem = await prisma.newsItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends NewsItemUpdateManyArgs>(args: SelectSubset<T, NewsItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one NewsItem.
     * @param {NewsItemUpsertArgs} args - Arguments to update or create a NewsItem.
     * @example
     * // Update or create a NewsItem
     * const newsItem = await prisma.newsItem.upsert({
     *   create: {
     *     // ... data to create a NewsItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the NewsItem we want to update
     *   }
     * })
     */
    upsert<T extends NewsItemUpsertArgs>(args: SelectSubset<T, NewsItemUpsertArgs<ExtArgs>>): Prisma__NewsItemClient<$Result.GetResult<Prisma.$NewsItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of NewsItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemCountArgs} args - Arguments to filter NewsItems to count.
     * @example
     * // Count the number of NewsItems
     * const count = await prisma.newsItem.count({
     *   where: {
     *     // ... the filter for the NewsItems we want to count
     *   }
     * })
    **/
    count<T extends NewsItemCountArgs>(
      args?: Subset<T, NewsItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], NewsItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a NewsItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends NewsItemAggregateArgs>(args: Subset<T, NewsItemAggregateArgs>): Prisma.PrismaPromise<GetNewsItemAggregateType<T>>

    /**
     * Group by NewsItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NewsItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends NewsItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: NewsItemGroupByArgs['orderBy'] }
        : { orderBy?: NewsItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, NewsItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNewsItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the NewsItem model
   */
  readonly fields: NewsItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for NewsItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__NewsItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the NewsItem model
   */
  interface NewsItemFieldRefs {
    readonly id: FieldRef<"NewsItem", 'Int'>
    readonly title: FieldRef<"NewsItem", 'String'>
    readonly content: FieldRef<"NewsItem", 'String'>
    readonly status: FieldRef<"NewsItem", 'ContentStatus'>
    readonly date: FieldRef<"NewsItem", 'String'>
    readonly views: FieldRef<"NewsItem", 'Int'>
    readonly author: FieldRef<"NewsItem", 'String'>
    readonly tags: FieldRef<"NewsItem", 'String'>
    readonly imageUrl: FieldRef<"NewsItem", 'String'>
    readonly createdAt: FieldRef<"NewsItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * NewsItem findUnique
   */
  export type NewsItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter, which NewsItem to fetch.
     */
    where: NewsItemWhereUniqueInput
  }

  /**
   * NewsItem findUniqueOrThrow
   */
  export type NewsItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter, which NewsItem to fetch.
     */
    where: NewsItemWhereUniqueInput
  }

  /**
   * NewsItem findFirst
   */
  export type NewsItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter, which NewsItem to fetch.
     */
    where?: NewsItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NewsItems to fetch.
     */
    orderBy?: NewsItemOrderByWithRelationInput | NewsItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for NewsItems.
     */
    cursor?: NewsItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NewsItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NewsItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of NewsItems.
     */
    distinct?: NewsItemScalarFieldEnum | NewsItemScalarFieldEnum[]
  }

  /**
   * NewsItem findFirstOrThrow
   */
  export type NewsItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter, which NewsItem to fetch.
     */
    where?: NewsItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NewsItems to fetch.
     */
    orderBy?: NewsItemOrderByWithRelationInput | NewsItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for NewsItems.
     */
    cursor?: NewsItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NewsItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NewsItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of NewsItems.
     */
    distinct?: NewsItemScalarFieldEnum | NewsItemScalarFieldEnum[]
  }

  /**
   * NewsItem findMany
   */
  export type NewsItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter, which NewsItems to fetch.
     */
    where?: NewsItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NewsItems to fetch.
     */
    orderBy?: NewsItemOrderByWithRelationInput | NewsItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing NewsItems.
     */
    cursor?: NewsItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NewsItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NewsItems.
     */
    skip?: number
    distinct?: NewsItemScalarFieldEnum | NewsItemScalarFieldEnum[]
  }

  /**
   * NewsItem create
   */
  export type NewsItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * The data needed to create a NewsItem.
     */
    data: XOR<NewsItemCreateInput, NewsItemUncheckedCreateInput>
  }

  /**
   * NewsItem createMany
   */
  export type NewsItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many NewsItems.
     */
    data: NewsItemCreateManyInput | NewsItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * NewsItem update
   */
  export type NewsItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * The data needed to update a NewsItem.
     */
    data: XOR<NewsItemUpdateInput, NewsItemUncheckedUpdateInput>
    /**
     * Choose, which NewsItem to update.
     */
    where: NewsItemWhereUniqueInput
  }

  /**
   * NewsItem updateMany
   */
  export type NewsItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update NewsItems.
     */
    data: XOR<NewsItemUpdateManyMutationInput, NewsItemUncheckedUpdateManyInput>
    /**
     * Filter which NewsItems to update
     */
    where?: NewsItemWhereInput
    /**
     * Limit how many NewsItems to update.
     */
    limit?: number
  }

  /**
   * NewsItem upsert
   */
  export type NewsItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * The filter to search for the NewsItem to update in case it exists.
     */
    where: NewsItemWhereUniqueInput
    /**
     * In case the NewsItem found by the `where` argument doesn't exist, create a new NewsItem with this data.
     */
    create: XOR<NewsItemCreateInput, NewsItemUncheckedCreateInput>
    /**
     * In case the NewsItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<NewsItemUpdateInput, NewsItemUncheckedUpdateInput>
  }

  /**
   * NewsItem delete
   */
  export type NewsItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
    /**
     * Filter which NewsItem to delete.
     */
    where: NewsItemWhereUniqueInput
  }

  /**
   * NewsItem deleteMany
   */
  export type NewsItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which NewsItems to delete
     */
    where?: NewsItemWhereInput
    /**
     * Limit how many NewsItems to delete.
     */
    limit?: number
  }

  /**
   * NewsItem without action
   */
  export type NewsItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NewsItem
     */
    select?: NewsItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NewsItem
     */
    omit?: NewsItemOmit<ExtArgs> | null
  }


  /**
   * Model Student
   */

  export type AggregateStudent = {
    _count: StudentCountAggregateOutputType | null
    _avg: StudentAvgAggregateOutputType | null
    _sum: StudentSumAggregateOutputType | null
    _min: StudentMinAggregateOutputType | null
    _max: StudentMaxAggregateOutputType | null
  }

  export type StudentAvgAggregateOutputType = {
    id: number | null
  }

  export type StudentSumAggregateOutputType = {
    id: number | null
  }

  export type StudentMinAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    phone: string | null
    status: $Enums.StudentStatus | null
    address: string | null
    organisation: string | null
    createdAt: Date | null
  }

  export type StudentMaxAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    phone: string | null
    status: $Enums.StudentStatus | null
    address: string | null
    organisation: string | null
    createdAt: Date | null
  }

  export type StudentCountAggregateOutputType = {
    id: number
    name: number
    email: number
    phone: number
    status: number
    address: number
    organisation: number
    createdAt: number
    _all: number
  }


  export type StudentAvgAggregateInputType = {
    id?: true
  }

  export type StudentSumAggregateInputType = {
    id?: true
  }

  export type StudentMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    phone?: true
    status?: true
    address?: true
    organisation?: true
    createdAt?: true
  }

  export type StudentMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    phone?: true
    status?: true
    address?: true
    organisation?: true
    createdAt?: true
  }

  export type StudentCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    phone?: true
    status?: true
    address?: true
    organisation?: true
    createdAt?: true
    _all?: true
  }

  export type StudentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Student to aggregate.
     */
    where?: StudentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Students to fetch.
     */
    orderBy?: StudentOrderByWithRelationInput | StudentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: StudentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Students from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Students.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Students
    **/
    _count?: true | StudentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: StudentAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: StudentSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: StudentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: StudentMaxAggregateInputType
  }

  export type GetStudentAggregateType<T extends StudentAggregateArgs> = {
        [P in keyof T & keyof AggregateStudent]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateStudent[P]>
      : GetScalarType<T[P], AggregateStudent[P]>
  }




  export type StudentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: StudentWhereInput
    orderBy?: StudentOrderByWithAggregationInput | StudentOrderByWithAggregationInput[]
    by: StudentScalarFieldEnum[] | StudentScalarFieldEnum
    having?: StudentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: StudentCountAggregateInputType | true
    _avg?: StudentAvgAggregateInputType
    _sum?: StudentSumAggregateInputType
    _min?: StudentMinAggregateInputType
    _max?: StudentMaxAggregateInputType
  }

  export type StudentGroupByOutputType = {
    id: number
    name: string
    email: string
    phone: string
    status: $Enums.StudentStatus
    address: string | null
    organisation: string | null
    createdAt: Date
    _count: StudentCountAggregateOutputType | null
    _avg: StudentAvgAggregateOutputType | null
    _sum: StudentSumAggregateOutputType | null
    _min: StudentMinAggregateOutputType | null
    _max: StudentMaxAggregateOutputType | null
  }

  type GetStudentGroupByPayload<T extends StudentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<StudentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof StudentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], StudentGroupByOutputType[P]>
            : GetScalarType<T[P], StudentGroupByOutputType[P]>
        }
      >
    >


  export type StudentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    status?: boolean
    address?: boolean
    organisation?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["student"]>



  export type StudentSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    status?: boolean
    address?: boolean
    organisation?: boolean
    createdAt?: boolean
  }

  export type StudentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "phone" | "status" | "address" | "organisation" | "createdAt", ExtArgs["result"]["student"]>

  export type $StudentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Student"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      email: string
      phone: string
      status: $Enums.StudentStatus
      address: string | null
      organisation: string | null
      createdAt: Date
    }, ExtArgs["result"]["student"]>
    composites: {}
  }

  type StudentGetPayload<S extends boolean | null | undefined | StudentDefaultArgs> = $Result.GetResult<Prisma.$StudentPayload, S>

  type StudentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<StudentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: StudentCountAggregateInputType | true
    }

  export interface StudentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Student'], meta: { name: 'Student' } }
    /**
     * Find zero or one Student that matches the filter.
     * @param {StudentFindUniqueArgs} args - Arguments to find a Student
     * @example
     * // Get one Student
     * const student = await prisma.student.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends StudentFindUniqueArgs>(args: SelectSubset<T, StudentFindUniqueArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Student that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {StudentFindUniqueOrThrowArgs} args - Arguments to find a Student
     * @example
     * // Get one Student
     * const student = await prisma.student.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends StudentFindUniqueOrThrowArgs>(args: SelectSubset<T, StudentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Student that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentFindFirstArgs} args - Arguments to find a Student
     * @example
     * // Get one Student
     * const student = await prisma.student.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends StudentFindFirstArgs>(args?: SelectSubset<T, StudentFindFirstArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Student that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentFindFirstOrThrowArgs} args - Arguments to find a Student
     * @example
     * // Get one Student
     * const student = await prisma.student.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends StudentFindFirstOrThrowArgs>(args?: SelectSubset<T, StudentFindFirstOrThrowArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Students that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Students
     * const students = await prisma.student.findMany()
     * 
     * // Get first 10 Students
     * const students = await prisma.student.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const studentWithIdOnly = await prisma.student.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends StudentFindManyArgs>(args?: SelectSubset<T, StudentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Student.
     * @param {StudentCreateArgs} args - Arguments to create a Student.
     * @example
     * // Create one Student
     * const Student = await prisma.student.create({
     *   data: {
     *     // ... data to create a Student
     *   }
     * })
     * 
     */
    create<T extends StudentCreateArgs>(args: SelectSubset<T, StudentCreateArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Students.
     * @param {StudentCreateManyArgs} args - Arguments to create many Students.
     * @example
     * // Create many Students
     * const student = await prisma.student.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends StudentCreateManyArgs>(args?: SelectSubset<T, StudentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Student.
     * @param {StudentDeleteArgs} args - Arguments to delete one Student.
     * @example
     * // Delete one Student
     * const Student = await prisma.student.delete({
     *   where: {
     *     // ... filter to delete one Student
     *   }
     * })
     * 
     */
    delete<T extends StudentDeleteArgs>(args: SelectSubset<T, StudentDeleteArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Student.
     * @param {StudentUpdateArgs} args - Arguments to update one Student.
     * @example
     * // Update one Student
     * const student = await prisma.student.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends StudentUpdateArgs>(args: SelectSubset<T, StudentUpdateArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Students.
     * @param {StudentDeleteManyArgs} args - Arguments to filter Students to delete.
     * @example
     * // Delete a few Students
     * const { count } = await prisma.student.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends StudentDeleteManyArgs>(args?: SelectSubset<T, StudentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Students.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Students
     * const student = await prisma.student.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends StudentUpdateManyArgs>(args: SelectSubset<T, StudentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Student.
     * @param {StudentUpsertArgs} args - Arguments to update or create a Student.
     * @example
     * // Update or create a Student
     * const student = await prisma.student.upsert({
     *   create: {
     *     // ... data to create a Student
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Student we want to update
     *   }
     * })
     */
    upsert<T extends StudentUpsertArgs>(args: SelectSubset<T, StudentUpsertArgs<ExtArgs>>): Prisma__StudentClient<$Result.GetResult<Prisma.$StudentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Students.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentCountArgs} args - Arguments to filter Students to count.
     * @example
     * // Count the number of Students
     * const count = await prisma.student.count({
     *   where: {
     *     // ... the filter for the Students we want to count
     *   }
     * })
    **/
    count<T extends StudentCountArgs>(
      args?: Subset<T, StudentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], StudentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Student.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends StudentAggregateArgs>(args: Subset<T, StudentAggregateArgs>): Prisma.PrismaPromise<GetStudentAggregateType<T>>

    /**
     * Group by Student.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StudentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends StudentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: StudentGroupByArgs['orderBy'] }
        : { orderBy?: StudentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, StudentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetStudentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Student model
   */
  readonly fields: StudentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Student.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__StudentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Student model
   */
  interface StudentFieldRefs {
    readonly id: FieldRef<"Student", 'Int'>
    readonly name: FieldRef<"Student", 'String'>
    readonly email: FieldRef<"Student", 'String'>
    readonly phone: FieldRef<"Student", 'String'>
    readonly status: FieldRef<"Student", 'StudentStatus'>
    readonly address: FieldRef<"Student", 'String'>
    readonly organisation: FieldRef<"Student", 'String'>
    readonly createdAt: FieldRef<"Student", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Student findUnique
   */
  export type StudentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter, which Student to fetch.
     */
    where: StudentWhereUniqueInput
  }

  /**
   * Student findUniqueOrThrow
   */
  export type StudentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter, which Student to fetch.
     */
    where: StudentWhereUniqueInput
  }

  /**
   * Student findFirst
   */
  export type StudentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter, which Student to fetch.
     */
    where?: StudentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Students to fetch.
     */
    orderBy?: StudentOrderByWithRelationInput | StudentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Students.
     */
    cursor?: StudentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Students from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Students.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Students.
     */
    distinct?: StudentScalarFieldEnum | StudentScalarFieldEnum[]
  }

  /**
   * Student findFirstOrThrow
   */
  export type StudentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter, which Student to fetch.
     */
    where?: StudentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Students to fetch.
     */
    orderBy?: StudentOrderByWithRelationInput | StudentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Students.
     */
    cursor?: StudentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Students from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Students.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Students.
     */
    distinct?: StudentScalarFieldEnum | StudentScalarFieldEnum[]
  }

  /**
   * Student findMany
   */
  export type StudentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter, which Students to fetch.
     */
    where?: StudentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Students to fetch.
     */
    orderBy?: StudentOrderByWithRelationInput | StudentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Students.
     */
    cursor?: StudentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Students from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Students.
     */
    skip?: number
    distinct?: StudentScalarFieldEnum | StudentScalarFieldEnum[]
  }

  /**
   * Student create
   */
  export type StudentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * The data needed to create a Student.
     */
    data: XOR<StudentCreateInput, StudentUncheckedCreateInput>
  }

  /**
   * Student createMany
   */
  export type StudentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Students.
     */
    data: StudentCreateManyInput | StudentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Student update
   */
  export type StudentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * The data needed to update a Student.
     */
    data: XOR<StudentUpdateInput, StudentUncheckedUpdateInput>
    /**
     * Choose, which Student to update.
     */
    where: StudentWhereUniqueInput
  }

  /**
   * Student updateMany
   */
  export type StudentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Students.
     */
    data: XOR<StudentUpdateManyMutationInput, StudentUncheckedUpdateManyInput>
    /**
     * Filter which Students to update
     */
    where?: StudentWhereInput
    /**
     * Limit how many Students to update.
     */
    limit?: number
  }

  /**
   * Student upsert
   */
  export type StudentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * The filter to search for the Student to update in case it exists.
     */
    where: StudentWhereUniqueInput
    /**
     * In case the Student found by the `where` argument doesn't exist, create a new Student with this data.
     */
    create: XOR<StudentCreateInput, StudentUncheckedCreateInput>
    /**
     * In case the Student was found with the provided `where` argument, update it with this data.
     */
    update: XOR<StudentUpdateInput, StudentUncheckedUpdateInput>
  }

  /**
   * Student delete
   */
  export type StudentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
    /**
     * Filter which Student to delete.
     */
    where: StudentWhereUniqueInput
  }

  /**
   * Student deleteMany
   */
  export type StudentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Students to delete
     */
    where?: StudentWhereInput
    /**
     * Limit how many Students to delete.
     */
    limit?: number
  }

  /**
   * Student without action
   */
  export type StudentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Student
     */
    select?: StudentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Student
     */
    omit?: StudentOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    role: 'role',
    createdAt: 'createdAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const EventScalarFieldEnum: {
    id: 'id',
    title: 'title',
    description: 'description',
    date: 'date',
    location: 'location',
    studentId: 'studentId',
    status: 'status',
    createdAt: 'createdAt'
  };

  export type EventScalarFieldEnum = (typeof EventScalarFieldEnum)[keyof typeof EventScalarFieldEnum]


  export const VenueScalarFieldEnum: {
    id: 'id',
    name: 'name',
    capacity: 'capacity',
    location: 'location',
    status: 'status',
    bookings: 'bookings',
    description: 'description',
    amenities: 'amenities',
    eventTypeId: 'eventTypeId',
    createdAt: 'createdAt'
  };

  export type VenueScalarFieldEnum = (typeof VenueScalarFieldEnum)[keyof typeof VenueScalarFieldEnum]


  export const LogisticsServiceProviderScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type LogisticsServiceProviderScalarFieldEnum = (typeof LogisticsServiceProviderScalarFieldEnum)[keyof typeof LogisticsServiceProviderScalarFieldEnum]


  export const CateringServiceScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type CateringServiceScalarFieldEnum = (typeof CateringServiceScalarFieldEnum)[keyof typeof CateringServiceScalarFieldEnum]


  export const SecurityAgencyScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type SecurityAgencyScalarFieldEnum = (typeof SecurityAgencyScalarFieldEnum)[keyof typeof SecurityAgencyScalarFieldEnum]


  export const GiftShopScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type GiftShopScalarFieldEnum = (typeof GiftShopScalarFieldEnum)[keyof typeof GiftShopScalarFieldEnum]


  export const DJScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type DJScalarFieldEnum = (typeof DJScalarFieldEnum)[keyof typeof DJScalarFieldEnum]


  export const PhotographerScalarFieldEnum: {
    id: 'id',
    name: 'name',
    contact: 'contact',
    location: 'location',
    createdAt: 'createdAt'
  };

  export type PhotographerScalarFieldEnum = (typeof PhotographerScalarFieldEnum)[keyof typeof PhotographerScalarFieldEnum]


  export const EventTypeScalarFieldEnum: {
    id: 'id',
    name: 'name',
    color: 'color',
    events: 'events',
    active: 'active',
    description: 'description',
    category: 'category',
    subEvents: 'subEvents',
    createdAt: 'createdAt'
  };

  export type EventTypeScalarFieldEnum = (typeof EventTypeScalarFieldEnum)[keyof typeof EventTypeScalarFieldEnum]


  export const VendorScalarFieldEnum: {
    id: 'id',
    name: 'name',
    category: 'category',
    contact: 'contact',
    email: 'email',
    address: 'address',
    website: 'website',
    createdAt: 'createdAt'
  };

  export type VendorScalarFieldEnum = (typeof VendorScalarFieldEnum)[keyof typeof VendorScalarFieldEnum]


  export const ContentPageScalarFieldEnum: {
    id: 'id',
    title: 'title',
    content: 'content',
    status: 'status',
    lastModified: 'lastModified',
    slug: 'slug',
    createdAt: 'createdAt'
  };

  export type ContentPageScalarFieldEnum = (typeof ContentPageScalarFieldEnum)[keyof typeof ContentPageScalarFieldEnum]


  export const MediaItemScalarFieldEnum: {
    id: 'id',
    name: 'name',
    type: 'type',
    size: 'size',
    uploaded: 'uploaded',
    url: 'url',
    createdAt: 'createdAt'
  };

  export type MediaItemScalarFieldEnum = (typeof MediaItemScalarFieldEnum)[keyof typeof MediaItemScalarFieldEnum]


  export const NewsItemScalarFieldEnum: {
    id: 'id',
    title: 'title',
    content: 'content',
    status: 'status',
    date: 'date',
    views: 'views',
    author: 'author',
    tags: 'tags',
    imageUrl: 'imageUrl',
    createdAt: 'createdAt'
  };

  export type NewsItemScalarFieldEnum = (typeof NewsItemScalarFieldEnum)[keyof typeof NewsItemScalarFieldEnum]


  export const StudentScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    phone: 'phone',
    status: 'status',
    address: 'address',
    organisation: 'organisation',
    createdAt: 'createdAt'
  };

  export type StudentScalarFieldEnum = (typeof StudentScalarFieldEnum)[keyof typeof StudentScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const UserOrderByRelevanceFieldEnum: {
    name: 'name',
    email: 'email',
    password: 'password'
  };

  export type UserOrderByRelevanceFieldEnum = (typeof UserOrderByRelevanceFieldEnum)[keyof typeof UserOrderByRelevanceFieldEnum]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const EventOrderByRelevanceFieldEnum: {
    title: 'title',
    description: 'description',
    location: 'location'
  };

  export type EventOrderByRelevanceFieldEnum = (typeof EventOrderByRelevanceFieldEnum)[keyof typeof EventOrderByRelevanceFieldEnum]


  export const VenueOrderByRelevanceFieldEnum: {
    name: 'name',
    location: 'location',
    description: 'description',
    amenities: 'amenities'
  };

  export type VenueOrderByRelevanceFieldEnum = (typeof VenueOrderByRelevanceFieldEnum)[keyof typeof VenueOrderByRelevanceFieldEnum]


  export const LogisticsServiceProviderOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type LogisticsServiceProviderOrderByRelevanceFieldEnum = (typeof LogisticsServiceProviderOrderByRelevanceFieldEnum)[keyof typeof LogisticsServiceProviderOrderByRelevanceFieldEnum]


  export const CateringServiceOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type CateringServiceOrderByRelevanceFieldEnum = (typeof CateringServiceOrderByRelevanceFieldEnum)[keyof typeof CateringServiceOrderByRelevanceFieldEnum]


  export const SecurityAgencyOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type SecurityAgencyOrderByRelevanceFieldEnum = (typeof SecurityAgencyOrderByRelevanceFieldEnum)[keyof typeof SecurityAgencyOrderByRelevanceFieldEnum]


  export const GiftShopOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type GiftShopOrderByRelevanceFieldEnum = (typeof GiftShopOrderByRelevanceFieldEnum)[keyof typeof GiftShopOrderByRelevanceFieldEnum]


  export const DJOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type DJOrderByRelevanceFieldEnum = (typeof DJOrderByRelevanceFieldEnum)[keyof typeof DJOrderByRelevanceFieldEnum]


  export const PhotographerOrderByRelevanceFieldEnum: {
    name: 'name',
    contact: 'contact',
    location: 'location'
  };

  export type PhotographerOrderByRelevanceFieldEnum = (typeof PhotographerOrderByRelevanceFieldEnum)[keyof typeof PhotographerOrderByRelevanceFieldEnum]


  export const EventTypeOrderByRelevanceFieldEnum: {
    name: 'name',
    color: 'color',
    description: 'description',
    category: 'category',
    subEvents: 'subEvents'
  };

  export type EventTypeOrderByRelevanceFieldEnum = (typeof EventTypeOrderByRelevanceFieldEnum)[keyof typeof EventTypeOrderByRelevanceFieldEnum]


  export const VendorOrderByRelevanceFieldEnum: {
    name: 'name',
    category: 'category',
    contact: 'contact',
    email: 'email',
    address: 'address',
    website: 'website'
  };

  export type VendorOrderByRelevanceFieldEnum = (typeof VendorOrderByRelevanceFieldEnum)[keyof typeof VendorOrderByRelevanceFieldEnum]


  export const ContentPageOrderByRelevanceFieldEnum: {
    title: 'title',
    content: 'content',
    lastModified: 'lastModified',
    slug: 'slug'
  };

  export type ContentPageOrderByRelevanceFieldEnum = (typeof ContentPageOrderByRelevanceFieldEnum)[keyof typeof ContentPageOrderByRelevanceFieldEnum]


  export const MediaItemOrderByRelevanceFieldEnum: {
    name: 'name',
    size: 'size',
    uploaded: 'uploaded',
    url: 'url'
  };

  export type MediaItemOrderByRelevanceFieldEnum = (typeof MediaItemOrderByRelevanceFieldEnum)[keyof typeof MediaItemOrderByRelevanceFieldEnum]


  export const NewsItemOrderByRelevanceFieldEnum: {
    title: 'title',
    content: 'content',
    date: 'date',
    author: 'author',
    tags: 'tags',
    imageUrl: 'imageUrl'
  };

  export type NewsItemOrderByRelevanceFieldEnum = (typeof NewsItemOrderByRelevanceFieldEnum)[keyof typeof NewsItemOrderByRelevanceFieldEnum]


  export const StudentOrderByRelevanceFieldEnum: {
    name: 'name',
    email: 'email',
    phone: 'phone',
    address: 'address',
    organisation: 'organisation'
  };

  export type StudentOrderByRelevanceFieldEnum = (typeof StudentOrderByRelevanceFieldEnum)[keyof typeof StudentOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'EventStatus'
   */
  export type EnumEventStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EventStatus'>
    


  /**
   * Reference to a field of type 'VenueStatus'
   */
  export type EnumVenueStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'VenueStatus'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'ContentStatus'
   */
  export type EnumContentStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ContentStatus'>
    


  /**
   * Reference to a field of type 'MediaType'
   */
  export type EnumMediaTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MediaType'>
    


  /**
   * Reference to a field of type 'StudentStatus'
   */
  export type EnumStudentStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'StudentStatus'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: IntFilter<"User"> | number
    name?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    createdAt?: DateTimeFilter<"User"> | Date | string
    events?: EventListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    events?: EventOrderByRelationAggregateInput
    _relevance?: UserOrderByRelevanceInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    createdAt?: DateTimeFilter<"User"> | Date | string
    events?: EventListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"User"> | number
    name?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    password?: StringWithAggregatesFilter<"User"> | string
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type EventWhereInput = {
    AND?: EventWhereInput | EventWhereInput[]
    OR?: EventWhereInput[]
    NOT?: EventWhereInput | EventWhereInput[]
    id?: IntFilter<"Event"> | number
    title?: StringFilter<"Event"> | string
    description?: StringNullableFilter<"Event"> | string | null
    date?: DateTimeFilter<"Event"> | Date | string
    location?: StringFilter<"Event"> | string
    studentId?: IntFilter<"Event"> | number
    status?: EnumEventStatusFilter<"Event"> | $Enums.EventStatus
    createdAt?: DateTimeFilter<"Event"> | Date | string
    student?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type EventOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrderInput | SortOrder
    date?: SortOrder
    location?: SortOrder
    studentId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    student?: UserOrderByWithRelationInput
    _relevance?: EventOrderByRelevanceInput
  }

  export type EventWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: EventWhereInput | EventWhereInput[]
    OR?: EventWhereInput[]
    NOT?: EventWhereInput | EventWhereInput[]
    title?: StringFilter<"Event"> | string
    description?: StringNullableFilter<"Event"> | string | null
    date?: DateTimeFilter<"Event"> | Date | string
    location?: StringFilter<"Event"> | string
    studentId?: IntFilter<"Event"> | number
    status?: EnumEventStatusFilter<"Event"> | $Enums.EventStatus
    createdAt?: DateTimeFilter<"Event"> | Date | string
    student?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type EventOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrderInput | SortOrder
    date?: SortOrder
    location?: SortOrder
    studentId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    _count?: EventCountOrderByAggregateInput
    _avg?: EventAvgOrderByAggregateInput
    _max?: EventMaxOrderByAggregateInput
    _min?: EventMinOrderByAggregateInput
    _sum?: EventSumOrderByAggregateInput
  }

  export type EventScalarWhereWithAggregatesInput = {
    AND?: EventScalarWhereWithAggregatesInput | EventScalarWhereWithAggregatesInput[]
    OR?: EventScalarWhereWithAggregatesInput[]
    NOT?: EventScalarWhereWithAggregatesInput | EventScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Event"> | number
    title?: StringWithAggregatesFilter<"Event"> | string
    description?: StringNullableWithAggregatesFilter<"Event"> | string | null
    date?: DateTimeWithAggregatesFilter<"Event"> | Date | string
    location?: StringWithAggregatesFilter<"Event"> | string
    studentId?: IntWithAggregatesFilter<"Event"> | number
    status?: EnumEventStatusWithAggregatesFilter<"Event"> | $Enums.EventStatus
    createdAt?: DateTimeWithAggregatesFilter<"Event"> | Date | string
  }

  export type VenueWhereInput = {
    AND?: VenueWhereInput | VenueWhereInput[]
    OR?: VenueWhereInput[]
    NOT?: VenueWhereInput | VenueWhereInput[]
    id?: IntFilter<"Venue"> | number
    name?: StringFilter<"Venue"> | string
    capacity?: IntFilter<"Venue"> | number
    location?: StringFilter<"Venue"> | string
    status?: EnumVenueStatusFilter<"Venue"> | $Enums.VenueStatus
    bookings?: IntFilter<"Venue"> | number
    description?: StringNullableFilter<"Venue"> | string | null
    amenities?: StringNullableFilter<"Venue"> | string | null
    eventTypeId?: IntNullableFilter<"Venue"> | number | null
    createdAt?: DateTimeFilter<"Venue"> | Date | string
    eventType?: XOR<EventTypeNullableScalarRelationFilter, EventTypeWhereInput> | null
  }

  export type VenueOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    capacity?: SortOrder
    location?: SortOrder
    status?: SortOrder
    bookings?: SortOrder
    description?: SortOrderInput | SortOrder
    amenities?: SortOrderInput | SortOrder
    eventTypeId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    eventType?: EventTypeOrderByWithRelationInput
    _relevance?: VenueOrderByRelevanceInput
  }

  export type VenueWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: VenueWhereInput | VenueWhereInput[]
    OR?: VenueWhereInput[]
    NOT?: VenueWhereInput | VenueWhereInput[]
    name?: StringFilter<"Venue"> | string
    capacity?: IntFilter<"Venue"> | number
    location?: StringFilter<"Venue"> | string
    status?: EnumVenueStatusFilter<"Venue"> | $Enums.VenueStatus
    bookings?: IntFilter<"Venue"> | number
    description?: StringNullableFilter<"Venue"> | string | null
    amenities?: StringNullableFilter<"Venue"> | string | null
    eventTypeId?: IntNullableFilter<"Venue"> | number | null
    createdAt?: DateTimeFilter<"Venue"> | Date | string
    eventType?: XOR<EventTypeNullableScalarRelationFilter, EventTypeWhereInput> | null
  }, "id">

  export type VenueOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    capacity?: SortOrder
    location?: SortOrder
    status?: SortOrder
    bookings?: SortOrder
    description?: SortOrderInput | SortOrder
    amenities?: SortOrderInput | SortOrder
    eventTypeId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: VenueCountOrderByAggregateInput
    _avg?: VenueAvgOrderByAggregateInput
    _max?: VenueMaxOrderByAggregateInput
    _min?: VenueMinOrderByAggregateInput
    _sum?: VenueSumOrderByAggregateInput
  }

  export type VenueScalarWhereWithAggregatesInput = {
    AND?: VenueScalarWhereWithAggregatesInput | VenueScalarWhereWithAggregatesInput[]
    OR?: VenueScalarWhereWithAggregatesInput[]
    NOT?: VenueScalarWhereWithAggregatesInput | VenueScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Venue"> | number
    name?: StringWithAggregatesFilter<"Venue"> | string
    capacity?: IntWithAggregatesFilter<"Venue"> | number
    location?: StringWithAggregatesFilter<"Venue"> | string
    status?: EnumVenueStatusWithAggregatesFilter<"Venue"> | $Enums.VenueStatus
    bookings?: IntWithAggregatesFilter<"Venue"> | number
    description?: StringNullableWithAggregatesFilter<"Venue"> | string | null
    amenities?: StringNullableWithAggregatesFilter<"Venue"> | string | null
    eventTypeId?: IntNullableWithAggregatesFilter<"Venue"> | number | null
    createdAt?: DateTimeWithAggregatesFilter<"Venue"> | Date | string
  }

  export type LogisticsServiceProviderWhereInput = {
    AND?: LogisticsServiceProviderWhereInput | LogisticsServiceProviderWhereInput[]
    OR?: LogisticsServiceProviderWhereInput[]
    NOT?: LogisticsServiceProviderWhereInput | LogisticsServiceProviderWhereInput[]
    id?: IntFilter<"LogisticsServiceProvider"> | number
    name?: StringFilter<"LogisticsServiceProvider"> | string
    contact?: StringNullableFilter<"LogisticsServiceProvider"> | string | null
    location?: StringNullableFilter<"LogisticsServiceProvider"> | string | null
    createdAt?: DateTimeFilter<"LogisticsServiceProvider"> | Date | string
  }

  export type LogisticsServiceProviderOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: LogisticsServiceProviderOrderByRelevanceInput
  }

  export type LogisticsServiceProviderWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: LogisticsServiceProviderWhereInput | LogisticsServiceProviderWhereInput[]
    OR?: LogisticsServiceProviderWhereInput[]
    NOT?: LogisticsServiceProviderWhereInput | LogisticsServiceProviderWhereInput[]
    name?: StringFilter<"LogisticsServiceProvider"> | string
    contact?: StringNullableFilter<"LogisticsServiceProvider"> | string | null
    location?: StringNullableFilter<"LogisticsServiceProvider"> | string | null
    createdAt?: DateTimeFilter<"LogisticsServiceProvider"> | Date | string
  }, "id">

  export type LogisticsServiceProviderOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: LogisticsServiceProviderCountOrderByAggregateInput
    _avg?: LogisticsServiceProviderAvgOrderByAggregateInput
    _max?: LogisticsServiceProviderMaxOrderByAggregateInput
    _min?: LogisticsServiceProviderMinOrderByAggregateInput
    _sum?: LogisticsServiceProviderSumOrderByAggregateInput
  }

  export type LogisticsServiceProviderScalarWhereWithAggregatesInput = {
    AND?: LogisticsServiceProviderScalarWhereWithAggregatesInput | LogisticsServiceProviderScalarWhereWithAggregatesInput[]
    OR?: LogisticsServiceProviderScalarWhereWithAggregatesInput[]
    NOT?: LogisticsServiceProviderScalarWhereWithAggregatesInput | LogisticsServiceProviderScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"LogisticsServiceProvider"> | number
    name?: StringWithAggregatesFilter<"LogisticsServiceProvider"> | string
    contact?: StringNullableWithAggregatesFilter<"LogisticsServiceProvider"> | string | null
    location?: StringNullableWithAggregatesFilter<"LogisticsServiceProvider"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"LogisticsServiceProvider"> | Date | string
  }

  export type CateringServiceWhereInput = {
    AND?: CateringServiceWhereInput | CateringServiceWhereInput[]
    OR?: CateringServiceWhereInput[]
    NOT?: CateringServiceWhereInput | CateringServiceWhereInput[]
    id?: IntFilter<"CateringService"> | number
    name?: StringFilter<"CateringService"> | string
    contact?: StringNullableFilter<"CateringService"> | string | null
    location?: StringNullableFilter<"CateringService"> | string | null
    createdAt?: DateTimeFilter<"CateringService"> | Date | string
  }

  export type CateringServiceOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: CateringServiceOrderByRelevanceInput
  }

  export type CateringServiceWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: CateringServiceWhereInput | CateringServiceWhereInput[]
    OR?: CateringServiceWhereInput[]
    NOT?: CateringServiceWhereInput | CateringServiceWhereInput[]
    name?: StringFilter<"CateringService"> | string
    contact?: StringNullableFilter<"CateringService"> | string | null
    location?: StringNullableFilter<"CateringService"> | string | null
    createdAt?: DateTimeFilter<"CateringService"> | Date | string
  }, "id">

  export type CateringServiceOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: CateringServiceCountOrderByAggregateInput
    _avg?: CateringServiceAvgOrderByAggregateInput
    _max?: CateringServiceMaxOrderByAggregateInput
    _min?: CateringServiceMinOrderByAggregateInput
    _sum?: CateringServiceSumOrderByAggregateInput
  }

  export type CateringServiceScalarWhereWithAggregatesInput = {
    AND?: CateringServiceScalarWhereWithAggregatesInput | CateringServiceScalarWhereWithAggregatesInput[]
    OR?: CateringServiceScalarWhereWithAggregatesInput[]
    NOT?: CateringServiceScalarWhereWithAggregatesInput | CateringServiceScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"CateringService"> | number
    name?: StringWithAggregatesFilter<"CateringService"> | string
    contact?: StringNullableWithAggregatesFilter<"CateringService"> | string | null
    location?: StringNullableWithAggregatesFilter<"CateringService"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"CateringService"> | Date | string
  }

  export type SecurityAgencyWhereInput = {
    AND?: SecurityAgencyWhereInput | SecurityAgencyWhereInput[]
    OR?: SecurityAgencyWhereInput[]
    NOT?: SecurityAgencyWhereInput | SecurityAgencyWhereInput[]
    id?: IntFilter<"SecurityAgency"> | number
    name?: StringFilter<"SecurityAgency"> | string
    contact?: StringNullableFilter<"SecurityAgency"> | string | null
    location?: StringNullableFilter<"SecurityAgency"> | string | null
    createdAt?: DateTimeFilter<"SecurityAgency"> | Date | string
  }

  export type SecurityAgencyOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: SecurityAgencyOrderByRelevanceInput
  }

  export type SecurityAgencyWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: SecurityAgencyWhereInput | SecurityAgencyWhereInput[]
    OR?: SecurityAgencyWhereInput[]
    NOT?: SecurityAgencyWhereInput | SecurityAgencyWhereInput[]
    name?: StringFilter<"SecurityAgency"> | string
    contact?: StringNullableFilter<"SecurityAgency"> | string | null
    location?: StringNullableFilter<"SecurityAgency"> | string | null
    createdAt?: DateTimeFilter<"SecurityAgency"> | Date | string
  }, "id">

  export type SecurityAgencyOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: SecurityAgencyCountOrderByAggregateInput
    _avg?: SecurityAgencyAvgOrderByAggregateInput
    _max?: SecurityAgencyMaxOrderByAggregateInput
    _min?: SecurityAgencyMinOrderByAggregateInput
    _sum?: SecurityAgencySumOrderByAggregateInput
  }

  export type SecurityAgencyScalarWhereWithAggregatesInput = {
    AND?: SecurityAgencyScalarWhereWithAggregatesInput | SecurityAgencyScalarWhereWithAggregatesInput[]
    OR?: SecurityAgencyScalarWhereWithAggregatesInput[]
    NOT?: SecurityAgencyScalarWhereWithAggregatesInput | SecurityAgencyScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"SecurityAgency"> | number
    name?: StringWithAggregatesFilter<"SecurityAgency"> | string
    contact?: StringNullableWithAggregatesFilter<"SecurityAgency"> | string | null
    location?: StringNullableWithAggregatesFilter<"SecurityAgency"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"SecurityAgency"> | Date | string
  }

  export type GiftShopWhereInput = {
    AND?: GiftShopWhereInput | GiftShopWhereInput[]
    OR?: GiftShopWhereInput[]
    NOT?: GiftShopWhereInput | GiftShopWhereInput[]
    id?: IntFilter<"GiftShop"> | number
    name?: StringFilter<"GiftShop"> | string
    contact?: StringNullableFilter<"GiftShop"> | string | null
    location?: StringNullableFilter<"GiftShop"> | string | null
    createdAt?: DateTimeFilter<"GiftShop"> | Date | string
  }

  export type GiftShopOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: GiftShopOrderByRelevanceInput
  }

  export type GiftShopWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: GiftShopWhereInput | GiftShopWhereInput[]
    OR?: GiftShopWhereInput[]
    NOT?: GiftShopWhereInput | GiftShopWhereInput[]
    name?: StringFilter<"GiftShop"> | string
    contact?: StringNullableFilter<"GiftShop"> | string | null
    location?: StringNullableFilter<"GiftShop"> | string | null
    createdAt?: DateTimeFilter<"GiftShop"> | Date | string
  }, "id">

  export type GiftShopOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: GiftShopCountOrderByAggregateInput
    _avg?: GiftShopAvgOrderByAggregateInput
    _max?: GiftShopMaxOrderByAggregateInput
    _min?: GiftShopMinOrderByAggregateInput
    _sum?: GiftShopSumOrderByAggregateInput
  }

  export type GiftShopScalarWhereWithAggregatesInput = {
    AND?: GiftShopScalarWhereWithAggregatesInput | GiftShopScalarWhereWithAggregatesInput[]
    OR?: GiftShopScalarWhereWithAggregatesInput[]
    NOT?: GiftShopScalarWhereWithAggregatesInput | GiftShopScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"GiftShop"> | number
    name?: StringWithAggregatesFilter<"GiftShop"> | string
    contact?: StringNullableWithAggregatesFilter<"GiftShop"> | string | null
    location?: StringNullableWithAggregatesFilter<"GiftShop"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"GiftShop"> | Date | string
  }

  export type DJWhereInput = {
    AND?: DJWhereInput | DJWhereInput[]
    OR?: DJWhereInput[]
    NOT?: DJWhereInput | DJWhereInput[]
    id?: IntFilter<"DJ"> | number
    name?: StringFilter<"DJ"> | string
    contact?: StringNullableFilter<"DJ"> | string | null
    location?: StringNullableFilter<"DJ"> | string | null
    createdAt?: DateTimeFilter<"DJ"> | Date | string
  }

  export type DJOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: DJOrderByRelevanceInput
  }

  export type DJWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: DJWhereInput | DJWhereInput[]
    OR?: DJWhereInput[]
    NOT?: DJWhereInput | DJWhereInput[]
    name?: StringFilter<"DJ"> | string
    contact?: StringNullableFilter<"DJ"> | string | null
    location?: StringNullableFilter<"DJ"> | string | null
    createdAt?: DateTimeFilter<"DJ"> | Date | string
  }, "id">

  export type DJOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: DJCountOrderByAggregateInput
    _avg?: DJAvgOrderByAggregateInput
    _max?: DJMaxOrderByAggregateInput
    _min?: DJMinOrderByAggregateInput
    _sum?: DJSumOrderByAggregateInput
  }

  export type DJScalarWhereWithAggregatesInput = {
    AND?: DJScalarWhereWithAggregatesInput | DJScalarWhereWithAggregatesInput[]
    OR?: DJScalarWhereWithAggregatesInput[]
    NOT?: DJScalarWhereWithAggregatesInput | DJScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"DJ"> | number
    name?: StringWithAggregatesFilter<"DJ"> | string
    contact?: StringNullableWithAggregatesFilter<"DJ"> | string | null
    location?: StringNullableWithAggregatesFilter<"DJ"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"DJ"> | Date | string
  }

  export type PhotographerWhereInput = {
    AND?: PhotographerWhereInput | PhotographerWhereInput[]
    OR?: PhotographerWhereInput[]
    NOT?: PhotographerWhereInput | PhotographerWhereInput[]
    id?: IntFilter<"Photographer"> | number
    name?: StringFilter<"Photographer"> | string
    contact?: StringNullableFilter<"Photographer"> | string | null
    location?: StringNullableFilter<"Photographer"> | string | null
    createdAt?: DateTimeFilter<"Photographer"> | Date | string
  }

  export type PhotographerOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: PhotographerOrderByRelevanceInput
  }

  export type PhotographerWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: PhotographerWhereInput | PhotographerWhereInput[]
    OR?: PhotographerWhereInput[]
    NOT?: PhotographerWhereInput | PhotographerWhereInput[]
    name?: StringFilter<"Photographer"> | string
    contact?: StringNullableFilter<"Photographer"> | string | null
    location?: StringNullableFilter<"Photographer"> | string | null
    createdAt?: DateTimeFilter<"Photographer"> | Date | string
  }, "id">

  export type PhotographerOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrderInput | SortOrder
    location?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: PhotographerCountOrderByAggregateInput
    _avg?: PhotographerAvgOrderByAggregateInput
    _max?: PhotographerMaxOrderByAggregateInput
    _min?: PhotographerMinOrderByAggregateInput
    _sum?: PhotographerSumOrderByAggregateInput
  }

  export type PhotographerScalarWhereWithAggregatesInput = {
    AND?: PhotographerScalarWhereWithAggregatesInput | PhotographerScalarWhereWithAggregatesInput[]
    OR?: PhotographerScalarWhereWithAggregatesInput[]
    NOT?: PhotographerScalarWhereWithAggregatesInput | PhotographerScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Photographer"> | number
    name?: StringWithAggregatesFilter<"Photographer"> | string
    contact?: StringNullableWithAggregatesFilter<"Photographer"> | string | null
    location?: StringNullableWithAggregatesFilter<"Photographer"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Photographer"> | Date | string
  }

  export type EventTypeWhereInput = {
    AND?: EventTypeWhereInput | EventTypeWhereInput[]
    OR?: EventTypeWhereInput[]
    NOT?: EventTypeWhereInput | EventTypeWhereInput[]
    id?: IntFilter<"EventType"> | number
    name?: StringFilter<"EventType"> | string
    color?: StringFilter<"EventType"> | string
    events?: IntFilter<"EventType"> | number
    active?: BoolFilter<"EventType"> | boolean
    description?: StringNullableFilter<"EventType"> | string | null
    category?: StringNullableFilter<"EventType"> | string | null
    subEvents?: StringNullableFilter<"EventType"> | string | null
    createdAt?: DateTimeFilter<"EventType"> | Date | string
    venues?: VenueListRelationFilter
  }

  export type EventTypeOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    color?: SortOrder
    events?: SortOrder
    active?: SortOrder
    description?: SortOrderInput | SortOrder
    category?: SortOrderInput | SortOrder
    subEvents?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    venues?: VenueOrderByRelationAggregateInput
    _relevance?: EventTypeOrderByRelevanceInput
  }

  export type EventTypeWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: EventTypeWhereInput | EventTypeWhereInput[]
    OR?: EventTypeWhereInput[]
    NOT?: EventTypeWhereInput | EventTypeWhereInput[]
    name?: StringFilter<"EventType"> | string
    color?: StringFilter<"EventType"> | string
    events?: IntFilter<"EventType"> | number
    active?: BoolFilter<"EventType"> | boolean
    description?: StringNullableFilter<"EventType"> | string | null
    category?: StringNullableFilter<"EventType"> | string | null
    subEvents?: StringNullableFilter<"EventType"> | string | null
    createdAt?: DateTimeFilter<"EventType"> | Date | string
    venues?: VenueListRelationFilter
  }, "id">

  export type EventTypeOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    color?: SortOrder
    events?: SortOrder
    active?: SortOrder
    description?: SortOrderInput | SortOrder
    category?: SortOrderInput | SortOrder
    subEvents?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: EventTypeCountOrderByAggregateInput
    _avg?: EventTypeAvgOrderByAggregateInput
    _max?: EventTypeMaxOrderByAggregateInput
    _min?: EventTypeMinOrderByAggregateInput
    _sum?: EventTypeSumOrderByAggregateInput
  }

  export type EventTypeScalarWhereWithAggregatesInput = {
    AND?: EventTypeScalarWhereWithAggregatesInput | EventTypeScalarWhereWithAggregatesInput[]
    OR?: EventTypeScalarWhereWithAggregatesInput[]
    NOT?: EventTypeScalarWhereWithAggregatesInput | EventTypeScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"EventType"> | number
    name?: StringWithAggregatesFilter<"EventType"> | string
    color?: StringWithAggregatesFilter<"EventType"> | string
    events?: IntWithAggregatesFilter<"EventType"> | number
    active?: BoolWithAggregatesFilter<"EventType"> | boolean
    description?: StringNullableWithAggregatesFilter<"EventType"> | string | null
    category?: StringNullableWithAggregatesFilter<"EventType"> | string | null
    subEvents?: StringNullableWithAggregatesFilter<"EventType"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"EventType"> | Date | string
  }

  export type VendorWhereInput = {
    AND?: VendorWhereInput | VendorWhereInput[]
    OR?: VendorWhereInput[]
    NOT?: VendorWhereInput | VendorWhereInput[]
    id?: IntFilter<"Vendor"> | number
    name?: StringFilter<"Vendor"> | string
    category?: StringFilter<"Vendor"> | string
    contact?: StringFilter<"Vendor"> | string
    email?: StringFilter<"Vendor"> | string
    address?: StringFilter<"Vendor"> | string
    website?: StringNullableFilter<"Vendor"> | string | null
    createdAt?: DateTimeFilter<"Vendor"> | Date | string
  }

  export type VendorOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    contact?: SortOrder
    email?: SortOrder
    address?: SortOrder
    website?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: VendorOrderByRelevanceInput
  }

  export type VendorWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: VendorWhereInput | VendorWhereInput[]
    OR?: VendorWhereInput[]
    NOT?: VendorWhereInput | VendorWhereInput[]
    name?: StringFilter<"Vendor"> | string
    category?: StringFilter<"Vendor"> | string
    contact?: StringFilter<"Vendor"> | string
    email?: StringFilter<"Vendor"> | string
    address?: StringFilter<"Vendor"> | string
    website?: StringNullableFilter<"Vendor"> | string | null
    createdAt?: DateTimeFilter<"Vendor"> | Date | string
  }, "id">

  export type VendorOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    contact?: SortOrder
    email?: SortOrder
    address?: SortOrder
    website?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: VendorCountOrderByAggregateInput
    _avg?: VendorAvgOrderByAggregateInput
    _max?: VendorMaxOrderByAggregateInput
    _min?: VendorMinOrderByAggregateInput
    _sum?: VendorSumOrderByAggregateInput
  }

  export type VendorScalarWhereWithAggregatesInput = {
    AND?: VendorScalarWhereWithAggregatesInput | VendorScalarWhereWithAggregatesInput[]
    OR?: VendorScalarWhereWithAggregatesInput[]
    NOT?: VendorScalarWhereWithAggregatesInput | VendorScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Vendor"> | number
    name?: StringWithAggregatesFilter<"Vendor"> | string
    category?: StringWithAggregatesFilter<"Vendor"> | string
    contact?: StringWithAggregatesFilter<"Vendor"> | string
    email?: StringWithAggregatesFilter<"Vendor"> | string
    address?: StringWithAggregatesFilter<"Vendor"> | string
    website?: StringNullableWithAggregatesFilter<"Vendor"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Vendor"> | Date | string
  }

  export type ContentPageWhereInput = {
    AND?: ContentPageWhereInput | ContentPageWhereInput[]
    OR?: ContentPageWhereInput[]
    NOT?: ContentPageWhereInput | ContentPageWhereInput[]
    id?: IntFilter<"ContentPage"> | number
    title?: StringFilter<"ContentPage"> | string
    content?: StringFilter<"ContentPage"> | string
    status?: EnumContentStatusFilter<"ContentPage"> | $Enums.ContentStatus
    lastModified?: StringFilter<"ContentPage"> | string
    slug?: StringFilter<"ContentPage"> | string
    createdAt?: DateTimeFilter<"ContentPage"> | Date | string
  }

  export type ContentPageOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    lastModified?: SortOrder
    slug?: SortOrder
    createdAt?: SortOrder
    _relevance?: ContentPageOrderByRelevanceInput
  }

  export type ContentPageWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    slug?: string
    AND?: ContentPageWhereInput | ContentPageWhereInput[]
    OR?: ContentPageWhereInput[]
    NOT?: ContentPageWhereInput | ContentPageWhereInput[]
    title?: StringFilter<"ContentPage"> | string
    content?: StringFilter<"ContentPage"> | string
    status?: EnumContentStatusFilter<"ContentPage"> | $Enums.ContentStatus
    lastModified?: StringFilter<"ContentPage"> | string
    createdAt?: DateTimeFilter<"ContentPage"> | Date | string
  }, "id" | "slug">

  export type ContentPageOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    lastModified?: SortOrder
    slug?: SortOrder
    createdAt?: SortOrder
    _count?: ContentPageCountOrderByAggregateInput
    _avg?: ContentPageAvgOrderByAggregateInput
    _max?: ContentPageMaxOrderByAggregateInput
    _min?: ContentPageMinOrderByAggregateInput
    _sum?: ContentPageSumOrderByAggregateInput
  }

  export type ContentPageScalarWhereWithAggregatesInput = {
    AND?: ContentPageScalarWhereWithAggregatesInput | ContentPageScalarWhereWithAggregatesInput[]
    OR?: ContentPageScalarWhereWithAggregatesInput[]
    NOT?: ContentPageScalarWhereWithAggregatesInput | ContentPageScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ContentPage"> | number
    title?: StringWithAggregatesFilter<"ContentPage"> | string
    content?: StringWithAggregatesFilter<"ContentPage"> | string
    status?: EnumContentStatusWithAggregatesFilter<"ContentPage"> | $Enums.ContentStatus
    lastModified?: StringWithAggregatesFilter<"ContentPage"> | string
    slug?: StringWithAggregatesFilter<"ContentPage"> | string
    createdAt?: DateTimeWithAggregatesFilter<"ContentPage"> | Date | string
  }

  export type MediaItemWhereInput = {
    AND?: MediaItemWhereInput | MediaItemWhereInput[]
    OR?: MediaItemWhereInput[]
    NOT?: MediaItemWhereInput | MediaItemWhereInput[]
    id?: IntFilter<"MediaItem"> | number
    name?: StringFilter<"MediaItem"> | string
    type?: EnumMediaTypeFilter<"MediaItem"> | $Enums.MediaType
    size?: StringFilter<"MediaItem"> | string
    uploaded?: StringFilter<"MediaItem"> | string
    url?: StringNullableFilter<"MediaItem"> | string | null
    createdAt?: DateTimeFilter<"MediaItem"> | Date | string
  }

  export type MediaItemOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    type?: SortOrder
    size?: SortOrder
    uploaded?: SortOrder
    url?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: MediaItemOrderByRelevanceInput
  }

  export type MediaItemWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MediaItemWhereInput | MediaItemWhereInput[]
    OR?: MediaItemWhereInput[]
    NOT?: MediaItemWhereInput | MediaItemWhereInput[]
    name?: StringFilter<"MediaItem"> | string
    type?: EnumMediaTypeFilter<"MediaItem"> | $Enums.MediaType
    size?: StringFilter<"MediaItem"> | string
    uploaded?: StringFilter<"MediaItem"> | string
    url?: StringNullableFilter<"MediaItem"> | string | null
    createdAt?: DateTimeFilter<"MediaItem"> | Date | string
  }, "id">

  export type MediaItemOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    type?: SortOrder
    size?: SortOrder
    uploaded?: SortOrder
    url?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: MediaItemCountOrderByAggregateInput
    _avg?: MediaItemAvgOrderByAggregateInput
    _max?: MediaItemMaxOrderByAggregateInput
    _min?: MediaItemMinOrderByAggregateInput
    _sum?: MediaItemSumOrderByAggregateInput
  }

  export type MediaItemScalarWhereWithAggregatesInput = {
    AND?: MediaItemScalarWhereWithAggregatesInput | MediaItemScalarWhereWithAggregatesInput[]
    OR?: MediaItemScalarWhereWithAggregatesInput[]
    NOT?: MediaItemScalarWhereWithAggregatesInput | MediaItemScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MediaItem"> | number
    name?: StringWithAggregatesFilter<"MediaItem"> | string
    type?: EnumMediaTypeWithAggregatesFilter<"MediaItem"> | $Enums.MediaType
    size?: StringWithAggregatesFilter<"MediaItem"> | string
    uploaded?: StringWithAggregatesFilter<"MediaItem"> | string
    url?: StringNullableWithAggregatesFilter<"MediaItem"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"MediaItem"> | Date | string
  }

  export type NewsItemWhereInput = {
    AND?: NewsItemWhereInput | NewsItemWhereInput[]
    OR?: NewsItemWhereInput[]
    NOT?: NewsItemWhereInput | NewsItemWhereInput[]
    id?: IntFilter<"NewsItem"> | number
    title?: StringFilter<"NewsItem"> | string
    content?: StringFilter<"NewsItem"> | string
    status?: EnumContentStatusFilter<"NewsItem"> | $Enums.ContentStatus
    date?: StringFilter<"NewsItem"> | string
    views?: IntFilter<"NewsItem"> | number
    author?: StringNullableFilter<"NewsItem"> | string | null
    tags?: StringNullableFilter<"NewsItem"> | string | null
    imageUrl?: StringNullableFilter<"NewsItem"> | string | null
    createdAt?: DateTimeFilter<"NewsItem"> | Date | string
  }

  export type NewsItemOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    date?: SortOrder
    views?: SortOrder
    author?: SortOrderInput | SortOrder
    tags?: SortOrderInput | SortOrder
    imageUrl?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: NewsItemOrderByRelevanceInput
  }

  export type NewsItemWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: NewsItemWhereInput | NewsItemWhereInput[]
    OR?: NewsItemWhereInput[]
    NOT?: NewsItemWhereInput | NewsItemWhereInput[]
    title?: StringFilter<"NewsItem"> | string
    content?: StringFilter<"NewsItem"> | string
    status?: EnumContentStatusFilter<"NewsItem"> | $Enums.ContentStatus
    date?: StringFilter<"NewsItem"> | string
    views?: IntFilter<"NewsItem"> | number
    author?: StringNullableFilter<"NewsItem"> | string | null
    tags?: StringNullableFilter<"NewsItem"> | string | null
    imageUrl?: StringNullableFilter<"NewsItem"> | string | null
    createdAt?: DateTimeFilter<"NewsItem"> | Date | string
  }, "id">

  export type NewsItemOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    date?: SortOrder
    views?: SortOrder
    author?: SortOrderInput | SortOrder
    tags?: SortOrderInput | SortOrder
    imageUrl?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: NewsItemCountOrderByAggregateInput
    _avg?: NewsItemAvgOrderByAggregateInput
    _max?: NewsItemMaxOrderByAggregateInput
    _min?: NewsItemMinOrderByAggregateInput
    _sum?: NewsItemSumOrderByAggregateInput
  }

  export type NewsItemScalarWhereWithAggregatesInput = {
    AND?: NewsItemScalarWhereWithAggregatesInput | NewsItemScalarWhereWithAggregatesInput[]
    OR?: NewsItemScalarWhereWithAggregatesInput[]
    NOT?: NewsItemScalarWhereWithAggregatesInput | NewsItemScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"NewsItem"> | number
    title?: StringWithAggregatesFilter<"NewsItem"> | string
    content?: StringWithAggregatesFilter<"NewsItem"> | string
    status?: EnumContentStatusWithAggregatesFilter<"NewsItem"> | $Enums.ContentStatus
    date?: StringWithAggregatesFilter<"NewsItem"> | string
    views?: IntWithAggregatesFilter<"NewsItem"> | number
    author?: StringNullableWithAggregatesFilter<"NewsItem"> | string | null
    tags?: StringNullableWithAggregatesFilter<"NewsItem"> | string | null
    imageUrl?: StringNullableWithAggregatesFilter<"NewsItem"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"NewsItem"> | Date | string
  }

  export type StudentWhereInput = {
    AND?: StudentWhereInput | StudentWhereInput[]
    OR?: StudentWhereInput[]
    NOT?: StudentWhereInput | StudentWhereInput[]
    id?: IntFilter<"Student"> | number
    name?: StringFilter<"Student"> | string
    email?: StringFilter<"Student"> | string
    phone?: StringFilter<"Student"> | string
    status?: EnumStudentStatusFilter<"Student"> | $Enums.StudentStatus
    address?: StringNullableFilter<"Student"> | string | null
    organisation?: StringNullableFilter<"Student"> | string | null
    createdAt?: DateTimeFilter<"Student"> | Date | string
  }

  export type StudentOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    status?: SortOrder
    address?: SortOrderInput | SortOrder
    organisation?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _relevance?: StudentOrderByRelevanceInput
  }

  export type StudentWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: StudentWhereInput | StudentWhereInput[]
    OR?: StudentWhereInput[]
    NOT?: StudentWhereInput | StudentWhereInput[]
    name?: StringFilter<"Student"> | string
    phone?: StringFilter<"Student"> | string
    status?: EnumStudentStatusFilter<"Student"> | $Enums.StudentStatus
    address?: StringNullableFilter<"Student"> | string | null
    organisation?: StringNullableFilter<"Student"> | string | null
    createdAt?: DateTimeFilter<"Student"> | Date | string
  }, "id" | "email">

  export type StudentOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    status?: SortOrder
    address?: SortOrderInput | SortOrder
    organisation?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: StudentCountOrderByAggregateInput
    _avg?: StudentAvgOrderByAggregateInput
    _max?: StudentMaxOrderByAggregateInput
    _min?: StudentMinOrderByAggregateInput
    _sum?: StudentSumOrderByAggregateInput
  }

  export type StudentScalarWhereWithAggregatesInput = {
    AND?: StudentScalarWhereWithAggregatesInput | StudentScalarWhereWithAggregatesInput[]
    OR?: StudentScalarWhereWithAggregatesInput[]
    NOT?: StudentScalarWhereWithAggregatesInput | StudentScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Student"> | number
    name?: StringWithAggregatesFilter<"Student"> | string
    email?: StringWithAggregatesFilter<"Student"> | string
    phone?: StringWithAggregatesFilter<"Student"> | string
    status?: EnumStudentStatusWithAggregatesFilter<"Student"> | $Enums.StudentStatus
    address?: StringNullableWithAggregatesFilter<"Student"> | string | null
    organisation?: StringNullableWithAggregatesFilter<"Student"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Student"> | Date | string
  }

  export type UserCreateInput = {
    name: string
    email: string
    password: string
    role?: $Enums.Role
    createdAt?: Date | string
    events?: EventCreateNestedManyWithoutStudentInput
  }

  export type UserUncheckedCreateInput = {
    id?: number
    name: string
    email: string
    password: string
    role?: $Enums.Role
    createdAt?: Date | string
    events?: EventUncheckedCreateNestedManyWithoutStudentInput
  }

  export type UserUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    events?: EventUpdateManyWithoutStudentNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    events?: EventUncheckedUpdateManyWithoutStudentNestedInput
  }

  export type UserCreateManyInput = {
    id?: number
    name: string
    email: string
    password: string
    role?: $Enums.Role
    createdAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventCreateInput = {
    title: string
    description?: string | null
    date: Date | string
    location: string
    status?: $Enums.EventStatus
    createdAt?: Date | string
    student: UserCreateNestedOneWithoutEventsInput
  }

  export type EventUncheckedCreateInput = {
    id?: number
    title: string
    description?: string | null
    date: Date | string
    location: string
    studentId: number
    status?: $Enums.EventStatus
    createdAt?: Date | string
  }

  export type EventUpdateInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    student?: UserUpdateOneRequiredWithoutEventsNestedInput
  }

  export type EventUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    studentId?: IntFieldUpdateOperationsInput | number
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventCreateManyInput = {
    id?: number
    title: string
    description?: string | null
    date: Date | string
    location: string
    studentId: number
    status?: $Enums.EventStatus
    createdAt?: Date | string
  }

  export type EventUpdateManyMutationInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    studentId?: IntFieldUpdateOperationsInput | number
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueCreateInput = {
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    createdAt?: Date | string
    eventType?: EventTypeCreateNestedOneWithoutVenuesInput
  }

  export type VenueUncheckedCreateInput = {
    id?: number
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    eventTypeId?: number | null
    createdAt?: Date | string
  }

  export type VenueUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    eventType?: EventTypeUpdateOneWithoutVenuesNestedInput
  }

  export type VenueUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    eventTypeId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueCreateManyInput = {
    id?: number
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    eventTypeId?: number | null
    createdAt?: Date | string
  }

  export type VenueUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    eventTypeId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LogisticsServiceProviderCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type LogisticsServiceProviderUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type LogisticsServiceProviderUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LogisticsServiceProviderUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LogisticsServiceProviderCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type LogisticsServiceProviderUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type LogisticsServiceProviderUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CateringServiceCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type CateringServiceUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type CateringServiceUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CateringServiceUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CateringServiceCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type CateringServiceUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CateringServiceUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SecurityAgencyCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type SecurityAgencyUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type SecurityAgencyUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SecurityAgencyUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SecurityAgencyCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type SecurityAgencyUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SecurityAgencyUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type GiftShopCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type GiftShopUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type GiftShopUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type GiftShopUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type GiftShopCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type GiftShopUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type GiftShopUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DJCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type DJUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type DJUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DJUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DJCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type DJUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DJUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotographerCreateInput = {
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type PhotographerUncheckedCreateInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type PhotographerUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotographerUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotographerCreateManyInput = {
    id?: number
    name: string
    contact?: string | null
    location?: string | null
    createdAt?: Date | string
  }

  export type PhotographerUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotographerUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    location?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventTypeCreateInput = {
    name: string
    color: string
    events?: number
    active?: boolean
    description?: string | null
    category?: string | null
    subEvents?: string | null
    createdAt?: Date | string
    venues?: VenueCreateNestedManyWithoutEventTypeInput
  }

  export type EventTypeUncheckedCreateInput = {
    id?: number
    name: string
    color: string
    events?: number
    active?: boolean
    description?: string | null
    category?: string | null
    subEvents?: string | null
    createdAt?: Date | string
    venues?: VenueUncheckedCreateNestedManyWithoutEventTypeInput
  }

  export type EventTypeUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    venues?: VenueUpdateManyWithoutEventTypeNestedInput
  }

  export type EventTypeUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    venues?: VenueUncheckedUpdateManyWithoutEventTypeNestedInput
  }

  export type EventTypeCreateManyInput = {
    id?: number
    name: string
    color: string
    events?: number
    active?: boolean
    description?: string | null
    category?: string | null
    subEvents?: string | null
    createdAt?: Date | string
  }

  export type EventTypeUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventTypeUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorCreateInput = {
    name: string
    category: string
    contact: string
    email: string
    address: string
    website?: string | null
    createdAt?: Date | string
  }

  export type VendorUncheckedCreateInput = {
    id?: number
    name: string
    category: string
    contact: string
    email: string
    address: string
    website?: string | null
    createdAt?: Date | string
  }

  export type VendorUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    contact?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    website?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    contact?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    website?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorCreateManyInput = {
    id?: number
    name: string
    category: string
    contact: string
    email: string
    address: string
    website?: string | null
    createdAt?: Date | string
  }

  export type VendorUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    contact?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    website?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    contact?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    website?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContentPageCreateInput = {
    title: string
    content: string
    status?: $Enums.ContentStatus
    lastModified: string
    slug: string
    createdAt?: Date | string
  }

  export type ContentPageUncheckedCreateInput = {
    id?: number
    title: string
    content: string
    status?: $Enums.ContentStatus
    lastModified: string
    slug: string
    createdAt?: Date | string
  }

  export type ContentPageUpdateInput = {
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    lastModified?: StringFieldUpdateOperationsInput | string
    slug?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContentPageUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    lastModified?: StringFieldUpdateOperationsInput | string
    slug?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContentPageCreateManyInput = {
    id?: number
    title: string
    content: string
    status?: $Enums.ContentStatus
    lastModified: string
    slug: string
    createdAt?: Date | string
  }

  export type ContentPageUpdateManyMutationInput = {
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    lastModified?: StringFieldUpdateOperationsInput | string
    slug?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContentPageUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    lastModified?: StringFieldUpdateOperationsInput | string
    slug?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MediaItemCreateInput = {
    name: string
    type: $Enums.MediaType
    size: string
    uploaded: string
    url?: string | null
    createdAt?: Date | string
  }

  export type MediaItemUncheckedCreateInput = {
    id?: number
    name: string
    type: $Enums.MediaType
    size: string
    uploaded: string
    url?: string | null
    createdAt?: Date | string
  }

  export type MediaItemUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    type?: EnumMediaTypeFieldUpdateOperationsInput | $Enums.MediaType
    size?: StringFieldUpdateOperationsInput | string
    uploaded?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MediaItemUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    type?: EnumMediaTypeFieldUpdateOperationsInput | $Enums.MediaType
    size?: StringFieldUpdateOperationsInput | string
    uploaded?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MediaItemCreateManyInput = {
    id?: number
    name: string
    type: $Enums.MediaType
    size: string
    uploaded: string
    url?: string | null
    createdAt?: Date | string
  }

  export type MediaItemUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    type?: EnumMediaTypeFieldUpdateOperationsInput | $Enums.MediaType
    size?: StringFieldUpdateOperationsInput | string
    uploaded?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MediaItemUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    type?: EnumMediaTypeFieldUpdateOperationsInput | $Enums.MediaType
    size?: StringFieldUpdateOperationsInput | string
    uploaded?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NewsItemCreateInput = {
    title: string
    content: string
    status?: $Enums.ContentStatus
    date: string
    views?: number
    author?: string | null
    tags?: string | null
    imageUrl?: string | null
    createdAt?: Date | string
  }

  export type NewsItemUncheckedCreateInput = {
    id?: number
    title: string
    content: string
    status?: $Enums.ContentStatus
    date: string
    views?: number
    author?: string | null
    tags?: string | null
    imageUrl?: string | null
    createdAt?: Date | string
  }

  export type NewsItemUpdateInput = {
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    date?: StringFieldUpdateOperationsInput | string
    views?: IntFieldUpdateOperationsInput | number
    author?: NullableStringFieldUpdateOperationsInput | string | null
    tags?: NullableStringFieldUpdateOperationsInput | string | null
    imageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NewsItemUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    date?: StringFieldUpdateOperationsInput | string
    views?: IntFieldUpdateOperationsInput | number
    author?: NullableStringFieldUpdateOperationsInput | string | null
    tags?: NullableStringFieldUpdateOperationsInput | string | null
    imageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NewsItemCreateManyInput = {
    id?: number
    title: string
    content: string
    status?: $Enums.ContentStatus
    date: string
    views?: number
    author?: string | null
    tags?: string | null
    imageUrl?: string | null
    createdAt?: Date | string
  }

  export type NewsItemUpdateManyMutationInput = {
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    date?: StringFieldUpdateOperationsInput | string
    views?: IntFieldUpdateOperationsInput | number
    author?: NullableStringFieldUpdateOperationsInput | string | null
    tags?: NullableStringFieldUpdateOperationsInput | string | null
    imageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NewsItemUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    content?: StringFieldUpdateOperationsInput | string
    status?: EnumContentStatusFieldUpdateOperationsInput | $Enums.ContentStatus
    date?: StringFieldUpdateOperationsInput | string
    views?: IntFieldUpdateOperationsInput | number
    author?: NullableStringFieldUpdateOperationsInput | string | null
    tags?: NullableStringFieldUpdateOperationsInput | string | null
    imageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StudentCreateInput = {
    name: string
    email: string
    phone: string
    status?: $Enums.StudentStatus
    address?: string | null
    organisation?: string | null
    createdAt?: Date | string
  }

  export type StudentUncheckedCreateInput = {
    id?: number
    name: string
    email: string
    phone: string
    status?: $Enums.StudentStatus
    address?: string | null
    organisation?: string | null
    createdAt?: Date | string
  }

  export type StudentUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    status?: EnumStudentStatusFieldUpdateOperationsInput | $Enums.StudentStatus
    address?: NullableStringFieldUpdateOperationsInput | string | null
    organisation?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StudentUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    status?: EnumStudentStatusFieldUpdateOperationsInput | $Enums.StudentStatus
    address?: NullableStringFieldUpdateOperationsInput | string | null
    organisation?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StudentCreateManyInput = {
    id?: number
    name: string
    email: string
    phone: string
    status?: $Enums.StudentStatus
    address?: string | null
    organisation?: string | null
    createdAt?: Date | string
  }

  export type StudentUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    status?: EnumStudentStatusFieldUpdateOperationsInput | $Enums.StudentStatus
    address?: NullableStringFieldUpdateOperationsInput | string | null
    organisation?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StudentUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    status?: EnumStudentStatusFieldUpdateOperationsInput | $Enums.StudentStatus
    address?: NullableStringFieldUpdateOperationsInput | string | null
    organisation?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EventListRelationFilter = {
    every?: EventWhereInput
    some?: EventWhereInput
    none?: EventWhereInput
  }

  export type EventOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserOrderByRelevanceInput = {
    fields: UserOrderByRelevanceFieldEnum | UserOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumEventStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.EventStatus | EnumEventStatusFieldRefInput<$PrismaModel>
    in?: $Enums.EventStatus[]
    notIn?: $Enums.EventStatus[]
    not?: NestedEnumEventStatusFilter<$PrismaModel> | $Enums.EventStatus
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type EventOrderByRelevanceInput = {
    fields: EventOrderByRelevanceFieldEnum | EventOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type EventCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    date?: SortOrder
    location?: SortOrder
    studentId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type EventAvgOrderByAggregateInput = {
    id?: SortOrder
    studentId?: SortOrder
  }

  export type EventMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    date?: SortOrder
    location?: SortOrder
    studentId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type EventMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    date?: SortOrder
    location?: SortOrder
    studentId?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
  }

  export type EventSumOrderByAggregateInput = {
    id?: SortOrder
    studentId?: SortOrder
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumEventStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EventStatus | EnumEventStatusFieldRefInput<$PrismaModel>
    in?: $Enums.EventStatus[]
    notIn?: $Enums.EventStatus[]
    not?: NestedEnumEventStatusWithAggregatesFilter<$PrismaModel> | $Enums.EventStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEventStatusFilter<$PrismaModel>
    _max?: NestedEnumEventStatusFilter<$PrismaModel>
  }

  export type EnumVenueStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.VenueStatus | EnumVenueStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VenueStatus[]
    notIn?: $Enums.VenueStatus[]
    not?: NestedEnumVenueStatusFilter<$PrismaModel> | $Enums.VenueStatus
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type EventTypeNullableScalarRelationFilter = {
    is?: EventTypeWhereInput | null
    isNot?: EventTypeWhereInput | null
  }

  export type VenueOrderByRelevanceInput = {
    fields: VenueOrderByRelevanceFieldEnum | VenueOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VenueCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    capacity?: SortOrder
    location?: SortOrder
    status?: SortOrder
    bookings?: SortOrder
    description?: SortOrder
    amenities?: SortOrder
    eventTypeId?: SortOrder
    createdAt?: SortOrder
  }

  export type VenueAvgOrderByAggregateInput = {
    id?: SortOrder
    capacity?: SortOrder
    bookings?: SortOrder
    eventTypeId?: SortOrder
  }

  export type VenueMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    capacity?: SortOrder
    location?: SortOrder
    status?: SortOrder
    bookings?: SortOrder
    description?: SortOrder
    amenities?: SortOrder
    eventTypeId?: SortOrder
    createdAt?: SortOrder
  }

  export type VenueMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    capacity?: SortOrder
    location?: SortOrder
    status?: SortOrder
    bookings?: SortOrder
    description?: SortOrder
    amenities?: SortOrder
    eventTypeId?: SortOrder
    createdAt?: SortOrder
  }

  export type VenueSumOrderByAggregateInput = {
    id?: SortOrder
    capacity?: SortOrder
    bookings?: SortOrder
    eventTypeId?: SortOrder
  }

  export type EnumVenueStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VenueStatus | EnumVenueStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VenueStatus[]
    notIn?: $Enums.VenueStatus[]
    not?: NestedEnumVenueStatusWithAggregatesFilter<$PrismaModel> | $Enums.VenueStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVenueStatusFilter<$PrismaModel>
    _max?: NestedEnumVenueStatusFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type LogisticsServiceProviderOrderByRelevanceInput = {
    fields: LogisticsServiceProviderOrderByRelevanceFieldEnum | LogisticsServiceProviderOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type LogisticsServiceProviderCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type LogisticsServiceProviderAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type LogisticsServiceProviderMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type LogisticsServiceProviderMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type LogisticsServiceProviderSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type CateringServiceOrderByRelevanceInput = {
    fields: CateringServiceOrderByRelevanceFieldEnum | CateringServiceOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type CateringServiceCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type CateringServiceAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type CateringServiceMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type CateringServiceMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type CateringServiceSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type SecurityAgencyOrderByRelevanceInput = {
    fields: SecurityAgencyOrderByRelevanceFieldEnum | SecurityAgencyOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SecurityAgencyCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type SecurityAgencyAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type SecurityAgencyMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type SecurityAgencyMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type SecurityAgencySumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type GiftShopOrderByRelevanceInput = {
    fields: GiftShopOrderByRelevanceFieldEnum | GiftShopOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type GiftShopCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type GiftShopAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type GiftShopMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type GiftShopMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type GiftShopSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type DJOrderByRelevanceInput = {
    fields: DJOrderByRelevanceFieldEnum | DJOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type DJCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type DJAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type DJMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type DJMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type DJSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type PhotographerOrderByRelevanceInput = {
    fields: PhotographerOrderByRelevanceFieldEnum | PhotographerOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PhotographerCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotographerAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type PhotographerMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotographerMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    contact?: SortOrder
    location?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotographerSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type VenueListRelationFilter = {
    every?: VenueWhereInput
    some?: VenueWhereInput
    none?: VenueWhereInput
  }

  export type VenueOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type EventTypeOrderByRelevanceInput = {
    fields: EventTypeOrderByRelevanceFieldEnum | EventTypeOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type EventTypeCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    color?: SortOrder
    events?: SortOrder
    active?: SortOrder
    description?: SortOrder
    category?: SortOrder
    subEvents?: SortOrder
    createdAt?: SortOrder
  }

  export type EventTypeAvgOrderByAggregateInput = {
    id?: SortOrder
    events?: SortOrder
  }

  export type EventTypeMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    color?: SortOrder
    events?: SortOrder
    active?: SortOrder
    description?: SortOrder
    category?: SortOrder
    subEvents?: SortOrder
    createdAt?: SortOrder
  }

  export type EventTypeMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    color?: SortOrder
    events?: SortOrder
    active?: SortOrder
    description?: SortOrder
    category?: SortOrder
    subEvents?: SortOrder
    createdAt?: SortOrder
  }

  export type EventTypeSumOrderByAggregateInput = {
    id?: SortOrder
    events?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type VendorOrderByRelevanceInput = {
    fields: VendorOrderByRelevanceFieldEnum | VendorOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VendorCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    contact?: SortOrder
    email?: SortOrder
    address?: SortOrder
    website?: SortOrder
    createdAt?: SortOrder
  }

  export type VendorAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type VendorMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    contact?: SortOrder
    email?: SortOrder
    address?: SortOrder
    website?: SortOrder
    createdAt?: SortOrder
  }

  export type VendorMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    contact?: SortOrder
    email?: SortOrder
    address?: SortOrder
    website?: SortOrder
    createdAt?: SortOrder
  }

  export type VendorSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumContentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ContentStatus | EnumContentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ContentStatus[]
    notIn?: $Enums.ContentStatus[]
    not?: NestedEnumContentStatusFilter<$PrismaModel> | $Enums.ContentStatus
  }

  export type ContentPageOrderByRelevanceInput = {
    fields: ContentPageOrderByRelevanceFieldEnum | ContentPageOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type ContentPageCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    lastModified?: SortOrder
    slug?: SortOrder
    createdAt?: SortOrder
  }

  export type ContentPageAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type ContentPageMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    lastModified?: SortOrder
    slug?: SortOrder
    createdAt?: SortOrder
  }

  export type ContentPageMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    lastModified?: SortOrder
    slug?: SortOrder
    createdAt?: SortOrder
  }

  export type ContentPageSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumContentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ContentStatus | EnumContentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ContentStatus[]
    notIn?: $Enums.ContentStatus[]
    not?: NestedEnumContentStatusWithAggregatesFilter<$PrismaModel> | $Enums.ContentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumContentStatusFilter<$PrismaModel>
    _max?: NestedEnumContentStatusFilter<$PrismaModel>
  }

  export type EnumMediaTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.MediaType | EnumMediaTypeFieldRefInput<$PrismaModel>
    in?: $Enums.MediaType[]
    notIn?: $Enums.MediaType[]
    not?: NestedEnumMediaTypeFilter<$PrismaModel> | $Enums.MediaType
  }

  export type MediaItemOrderByRelevanceInput = {
    fields: MediaItemOrderByRelevanceFieldEnum | MediaItemOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type MediaItemCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    type?: SortOrder
    size?: SortOrder
    uploaded?: SortOrder
    url?: SortOrder
    createdAt?: SortOrder
  }

  export type MediaItemAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type MediaItemMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    type?: SortOrder
    size?: SortOrder
    uploaded?: SortOrder
    url?: SortOrder
    createdAt?: SortOrder
  }

  export type MediaItemMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    type?: SortOrder
    size?: SortOrder
    uploaded?: SortOrder
    url?: SortOrder
    createdAt?: SortOrder
  }

  export type MediaItemSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumMediaTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MediaType | EnumMediaTypeFieldRefInput<$PrismaModel>
    in?: $Enums.MediaType[]
    notIn?: $Enums.MediaType[]
    not?: NestedEnumMediaTypeWithAggregatesFilter<$PrismaModel> | $Enums.MediaType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMediaTypeFilter<$PrismaModel>
    _max?: NestedEnumMediaTypeFilter<$PrismaModel>
  }

  export type NewsItemOrderByRelevanceInput = {
    fields: NewsItemOrderByRelevanceFieldEnum | NewsItemOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type NewsItemCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    date?: SortOrder
    views?: SortOrder
    author?: SortOrder
    tags?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type NewsItemAvgOrderByAggregateInput = {
    id?: SortOrder
    views?: SortOrder
  }

  export type NewsItemMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    date?: SortOrder
    views?: SortOrder
    author?: SortOrder
    tags?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type NewsItemMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    content?: SortOrder
    status?: SortOrder
    date?: SortOrder
    views?: SortOrder
    author?: SortOrder
    tags?: SortOrder
    imageUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type NewsItemSumOrderByAggregateInput = {
    id?: SortOrder
    views?: SortOrder
  }

  export type EnumStudentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.StudentStatus | EnumStudentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.StudentStatus[]
    notIn?: $Enums.StudentStatus[]
    not?: NestedEnumStudentStatusFilter<$PrismaModel> | $Enums.StudentStatus
  }

  export type StudentOrderByRelevanceInput = {
    fields: StudentOrderByRelevanceFieldEnum | StudentOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type StudentCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    status?: SortOrder
    address?: SortOrder
    organisation?: SortOrder
    createdAt?: SortOrder
  }

  export type StudentAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type StudentMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    status?: SortOrder
    address?: SortOrder
    organisation?: SortOrder
    createdAt?: SortOrder
  }

  export type StudentMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    status?: SortOrder
    address?: SortOrder
    organisation?: SortOrder
    createdAt?: SortOrder
  }

  export type StudentSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumStudentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.StudentStatus | EnumStudentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.StudentStatus[]
    notIn?: $Enums.StudentStatus[]
    not?: NestedEnumStudentStatusWithAggregatesFilter<$PrismaModel> | $Enums.StudentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumStudentStatusFilter<$PrismaModel>
    _max?: NestedEnumStudentStatusFilter<$PrismaModel>
  }

  export type EventCreateNestedManyWithoutStudentInput = {
    create?: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput> | EventCreateWithoutStudentInput[] | EventUncheckedCreateWithoutStudentInput[]
    connectOrCreate?: EventCreateOrConnectWithoutStudentInput | EventCreateOrConnectWithoutStudentInput[]
    createMany?: EventCreateManyStudentInputEnvelope
    connect?: EventWhereUniqueInput | EventWhereUniqueInput[]
  }

  export type EventUncheckedCreateNestedManyWithoutStudentInput = {
    create?: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput> | EventCreateWithoutStudentInput[] | EventUncheckedCreateWithoutStudentInput[]
    connectOrCreate?: EventCreateOrConnectWithoutStudentInput | EventCreateOrConnectWithoutStudentInput[]
    createMany?: EventCreateManyStudentInputEnvelope
    connect?: EventWhereUniqueInput | EventWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EventUpdateManyWithoutStudentNestedInput = {
    create?: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput> | EventCreateWithoutStudentInput[] | EventUncheckedCreateWithoutStudentInput[]
    connectOrCreate?: EventCreateOrConnectWithoutStudentInput | EventCreateOrConnectWithoutStudentInput[]
    upsert?: EventUpsertWithWhereUniqueWithoutStudentInput | EventUpsertWithWhereUniqueWithoutStudentInput[]
    createMany?: EventCreateManyStudentInputEnvelope
    set?: EventWhereUniqueInput | EventWhereUniqueInput[]
    disconnect?: EventWhereUniqueInput | EventWhereUniqueInput[]
    delete?: EventWhereUniqueInput | EventWhereUniqueInput[]
    connect?: EventWhereUniqueInput | EventWhereUniqueInput[]
    update?: EventUpdateWithWhereUniqueWithoutStudentInput | EventUpdateWithWhereUniqueWithoutStudentInput[]
    updateMany?: EventUpdateManyWithWhereWithoutStudentInput | EventUpdateManyWithWhereWithoutStudentInput[]
    deleteMany?: EventScalarWhereInput | EventScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EventUncheckedUpdateManyWithoutStudentNestedInput = {
    create?: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput> | EventCreateWithoutStudentInput[] | EventUncheckedCreateWithoutStudentInput[]
    connectOrCreate?: EventCreateOrConnectWithoutStudentInput | EventCreateOrConnectWithoutStudentInput[]
    upsert?: EventUpsertWithWhereUniqueWithoutStudentInput | EventUpsertWithWhereUniqueWithoutStudentInput[]
    createMany?: EventCreateManyStudentInputEnvelope
    set?: EventWhereUniqueInput | EventWhereUniqueInput[]
    disconnect?: EventWhereUniqueInput | EventWhereUniqueInput[]
    delete?: EventWhereUniqueInput | EventWhereUniqueInput[]
    connect?: EventWhereUniqueInput | EventWhereUniqueInput[]
    update?: EventUpdateWithWhereUniqueWithoutStudentInput | EventUpdateWithWhereUniqueWithoutStudentInput[]
    updateMany?: EventUpdateManyWithWhereWithoutStudentInput | EventUpdateManyWithWhereWithoutStudentInput[]
    deleteMany?: EventScalarWhereInput | EventScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutEventsInput = {
    create?: XOR<UserCreateWithoutEventsInput, UserUncheckedCreateWithoutEventsInput>
    connectOrCreate?: UserCreateOrConnectWithoutEventsInput
    connect?: UserWhereUniqueInput
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumEventStatusFieldUpdateOperationsInput = {
    set?: $Enums.EventStatus
  }

  export type UserUpdateOneRequiredWithoutEventsNestedInput = {
    create?: XOR<UserCreateWithoutEventsInput, UserUncheckedCreateWithoutEventsInput>
    connectOrCreate?: UserCreateOrConnectWithoutEventsInput
    upsert?: UserUpsertWithoutEventsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutEventsInput, UserUpdateWithoutEventsInput>, UserUncheckedUpdateWithoutEventsInput>
  }

  export type EventTypeCreateNestedOneWithoutVenuesInput = {
    create?: XOR<EventTypeCreateWithoutVenuesInput, EventTypeUncheckedCreateWithoutVenuesInput>
    connectOrCreate?: EventTypeCreateOrConnectWithoutVenuesInput
    connect?: EventTypeWhereUniqueInput
  }

  export type EnumVenueStatusFieldUpdateOperationsInput = {
    set?: $Enums.VenueStatus
  }

  export type EventTypeUpdateOneWithoutVenuesNestedInput = {
    create?: XOR<EventTypeCreateWithoutVenuesInput, EventTypeUncheckedCreateWithoutVenuesInput>
    connectOrCreate?: EventTypeCreateOrConnectWithoutVenuesInput
    upsert?: EventTypeUpsertWithoutVenuesInput
    disconnect?: EventTypeWhereInput | boolean
    delete?: EventTypeWhereInput | boolean
    connect?: EventTypeWhereUniqueInput
    update?: XOR<XOR<EventTypeUpdateToOneWithWhereWithoutVenuesInput, EventTypeUpdateWithoutVenuesInput>, EventTypeUncheckedUpdateWithoutVenuesInput>
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type VenueCreateNestedManyWithoutEventTypeInput = {
    create?: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput> | VenueCreateWithoutEventTypeInput[] | VenueUncheckedCreateWithoutEventTypeInput[]
    connectOrCreate?: VenueCreateOrConnectWithoutEventTypeInput | VenueCreateOrConnectWithoutEventTypeInput[]
    createMany?: VenueCreateManyEventTypeInputEnvelope
    connect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
  }

  export type VenueUncheckedCreateNestedManyWithoutEventTypeInput = {
    create?: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput> | VenueCreateWithoutEventTypeInput[] | VenueUncheckedCreateWithoutEventTypeInput[]
    connectOrCreate?: VenueCreateOrConnectWithoutEventTypeInput | VenueCreateOrConnectWithoutEventTypeInput[]
    createMany?: VenueCreateManyEventTypeInputEnvelope
    connect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type VenueUpdateManyWithoutEventTypeNestedInput = {
    create?: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput> | VenueCreateWithoutEventTypeInput[] | VenueUncheckedCreateWithoutEventTypeInput[]
    connectOrCreate?: VenueCreateOrConnectWithoutEventTypeInput | VenueCreateOrConnectWithoutEventTypeInput[]
    upsert?: VenueUpsertWithWhereUniqueWithoutEventTypeInput | VenueUpsertWithWhereUniqueWithoutEventTypeInput[]
    createMany?: VenueCreateManyEventTypeInputEnvelope
    set?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    disconnect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    delete?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    connect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    update?: VenueUpdateWithWhereUniqueWithoutEventTypeInput | VenueUpdateWithWhereUniqueWithoutEventTypeInput[]
    updateMany?: VenueUpdateManyWithWhereWithoutEventTypeInput | VenueUpdateManyWithWhereWithoutEventTypeInput[]
    deleteMany?: VenueScalarWhereInput | VenueScalarWhereInput[]
  }

  export type VenueUncheckedUpdateManyWithoutEventTypeNestedInput = {
    create?: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput> | VenueCreateWithoutEventTypeInput[] | VenueUncheckedCreateWithoutEventTypeInput[]
    connectOrCreate?: VenueCreateOrConnectWithoutEventTypeInput | VenueCreateOrConnectWithoutEventTypeInput[]
    upsert?: VenueUpsertWithWhereUniqueWithoutEventTypeInput | VenueUpsertWithWhereUniqueWithoutEventTypeInput[]
    createMany?: VenueCreateManyEventTypeInputEnvelope
    set?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    disconnect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    delete?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    connect?: VenueWhereUniqueInput | VenueWhereUniqueInput[]
    update?: VenueUpdateWithWhereUniqueWithoutEventTypeInput | VenueUpdateWithWhereUniqueWithoutEventTypeInput[]
    updateMany?: VenueUpdateManyWithWhereWithoutEventTypeInput | VenueUpdateManyWithWhereWithoutEventTypeInput[]
    deleteMany?: VenueScalarWhereInput | VenueScalarWhereInput[]
  }

  export type EnumContentStatusFieldUpdateOperationsInput = {
    set?: $Enums.ContentStatus
  }

  export type EnumMediaTypeFieldUpdateOperationsInput = {
    set?: $Enums.MediaType
  }

  export type EnumStudentStatusFieldUpdateOperationsInput = {
    set?: $Enums.StudentStatus
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumEventStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.EventStatus | EnumEventStatusFieldRefInput<$PrismaModel>
    in?: $Enums.EventStatus[]
    notIn?: $Enums.EventStatus[]
    not?: NestedEnumEventStatusFilter<$PrismaModel> | $Enums.EventStatus
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumEventStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EventStatus | EnumEventStatusFieldRefInput<$PrismaModel>
    in?: $Enums.EventStatus[]
    notIn?: $Enums.EventStatus[]
    not?: NestedEnumEventStatusWithAggregatesFilter<$PrismaModel> | $Enums.EventStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEventStatusFilter<$PrismaModel>
    _max?: NestedEnumEventStatusFilter<$PrismaModel>
  }

  export type NestedEnumVenueStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.VenueStatus | EnumVenueStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VenueStatus[]
    notIn?: $Enums.VenueStatus[]
    not?: NestedEnumVenueStatusFilter<$PrismaModel> | $Enums.VenueStatus
  }

  export type NestedEnumVenueStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VenueStatus | EnumVenueStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VenueStatus[]
    notIn?: $Enums.VenueStatus[]
    not?: NestedEnumVenueStatusWithAggregatesFilter<$PrismaModel> | $Enums.VenueStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVenueStatusFilter<$PrismaModel>
    _max?: NestedEnumVenueStatusFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedEnumContentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ContentStatus | EnumContentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ContentStatus[]
    notIn?: $Enums.ContentStatus[]
    not?: NestedEnumContentStatusFilter<$PrismaModel> | $Enums.ContentStatus
  }

  export type NestedEnumContentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ContentStatus | EnumContentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ContentStatus[]
    notIn?: $Enums.ContentStatus[]
    not?: NestedEnumContentStatusWithAggregatesFilter<$PrismaModel> | $Enums.ContentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumContentStatusFilter<$PrismaModel>
    _max?: NestedEnumContentStatusFilter<$PrismaModel>
  }

  export type NestedEnumMediaTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.MediaType | EnumMediaTypeFieldRefInput<$PrismaModel>
    in?: $Enums.MediaType[]
    notIn?: $Enums.MediaType[]
    not?: NestedEnumMediaTypeFilter<$PrismaModel> | $Enums.MediaType
  }

  export type NestedEnumMediaTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MediaType | EnumMediaTypeFieldRefInput<$PrismaModel>
    in?: $Enums.MediaType[]
    notIn?: $Enums.MediaType[]
    not?: NestedEnumMediaTypeWithAggregatesFilter<$PrismaModel> | $Enums.MediaType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMediaTypeFilter<$PrismaModel>
    _max?: NestedEnumMediaTypeFilter<$PrismaModel>
  }

  export type NestedEnumStudentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.StudentStatus | EnumStudentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.StudentStatus[]
    notIn?: $Enums.StudentStatus[]
    not?: NestedEnumStudentStatusFilter<$PrismaModel> | $Enums.StudentStatus
  }

  export type NestedEnumStudentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.StudentStatus | EnumStudentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.StudentStatus[]
    notIn?: $Enums.StudentStatus[]
    not?: NestedEnumStudentStatusWithAggregatesFilter<$PrismaModel> | $Enums.StudentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumStudentStatusFilter<$PrismaModel>
    _max?: NestedEnumStudentStatusFilter<$PrismaModel>
  }

  export type EventCreateWithoutStudentInput = {
    title: string
    description?: string | null
    date: Date | string
    location: string
    status?: $Enums.EventStatus
    createdAt?: Date | string
  }

  export type EventUncheckedCreateWithoutStudentInput = {
    id?: number
    title: string
    description?: string | null
    date: Date | string
    location: string
    status?: $Enums.EventStatus
    createdAt?: Date | string
  }

  export type EventCreateOrConnectWithoutStudentInput = {
    where: EventWhereUniqueInput
    create: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput>
  }

  export type EventCreateManyStudentInputEnvelope = {
    data: EventCreateManyStudentInput | EventCreateManyStudentInput[]
    skipDuplicates?: boolean
  }

  export type EventUpsertWithWhereUniqueWithoutStudentInput = {
    where: EventWhereUniqueInput
    update: XOR<EventUpdateWithoutStudentInput, EventUncheckedUpdateWithoutStudentInput>
    create: XOR<EventCreateWithoutStudentInput, EventUncheckedCreateWithoutStudentInput>
  }

  export type EventUpdateWithWhereUniqueWithoutStudentInput = {
    where: EventWhereUniqueInput
    data: XOR<EventUpdateWithoutStudentInput, EventUncheckedUpdateWithoutStudentInput>
  }

  export type EventUpdateManyWithWhereWithoutStudentInput = {
    where: EventScalarWhereInput
    data: XOR<EventUpdateManyMutationInput, EventUncheckedUpdateManyWithoutStudentInput>
  }

  export type EventScalarWhereInput = {
    AND?: EventScalarWhereInput | EventScalarWhereInput[]
    OR?: EventScalarWhereInput[]
    NOT?: EventScalarWhereInput | EventScalarWhereInput[]
    id?: IntFilter<"Event"> | number
    title?: StringFilter<"Event"> | string
    description?: StringNullableFilter<"Event"> | string | null
    date?: DateTimeFilter<"Event"> | Date | string
    location?: StringFilter<"Event"> | string
    studentId?: IntFilter<"Event"> | number
    status?: EnumEventStatusFilter<"Event"> | $Enums.EventStatus
    createdAt?: DateTimeFilter<"Event"> | Date | string
  }

  export type UserCreateWithoutEventsInput = {
    name: string
    email: string
    password: string
    role?: $Enums.Role
    createdAt?: Date | string
  }

  export type UserUncheckedCreateWithoutEventsInput = {
    id?: number
    name: string
    email: string
    password: string
    role?: $Enums.Role
    createdAt?: Date | string
  }

  export type UserCreateOrConnectWithoutEventsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutEventsInput, UserUncheckedCreateWithoutEventsInput>
  }

  export type UserUpsertWithoutEventsInput = {
    update: XOR<UserUpdateWithoutEventsInput, UserUncheckedUpdateWithoutEventsInput>
    create: XOR<UserCreateWithoutEventsInput, UserUncheckedCreateWithoutEventsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutEventsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutEventsInput, UserUncheckedUpdateWithoutEventsInput>
  }

  export type UserUpdateWithoutEventsInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateWithoutEventsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventTypeCreateWithoutVenuesInput = {
    name: string
    color: string
    events?: number
    active?: boolean
    description?: string | null
    category?: string | null
    subEvents?: string | null
    createdAt?: Date | string
  }

  export type EventTypeUncheckedCreateWithoutVenuesInput = {
    id?: number
    name: string
    color: string
    events?: number
    active?: boolean
    description?: string | null
    category?: string | null
    subEvents?: string | null
    createdAt?: Date | string
  }

  export type EventTypeCreateOrConnectWithoutVenuesInput = {
    where: EventTypeWhereUniqueInput
    create: XOR<EventTypeCreateWithoutVenuesInput, EventTypeUncheckedCreateWithoutVenuesInput>
  }

  export type EventTypeUpsertWithoutVenuesInput = {
    update: XOR<EventTypeUpdateWithoutVenuesInput, EventTypeUncheckedUpdateWithoutVenuesInput>
    create: XOR<EventTypeCreateWithoutVenuesInput, EventTypeUncheckedCreateWithoutVenuesInput>
    where?: EventTypeWhereInput
  }

  export type EventTypeUpdateToOneWithWhereWithoutVenuesInput = {
    where?: EventTypeWhereInput
    data: XOR<EventTypeUpdateWithoutVenuesInput, EventTypeUncheckedUpdateWithoutVenuesInput>
  }

  export type EventTypeUpdateWithoutVenuesInput = {
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventTypeUncheckedUpdateWithoutVenuesInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    color?: StringFieldUpdateOperationsInput | string
    events?: IntFieldUpdateOperationsInput | number
    active?: BoolFieldUpdateOperationsInput | boolean
    description?: NullableStringFieldUpdateOperationsInput | string | null
    category?: NullableStringFieldUpdateOperationsInput | string | null
    subEvents?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueCreateWithoutEventTypeInput = {
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    createdAt?: Date | string
  }

  export type VenueUncheckedCreateWithoutEventTypeInput = {
    id?: number
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    createdAt?: Date | string
  }

  export type VenueCreateOrConnectWithoutEventTypeInput = {
    where: VenueWhereUniqueInput
    create: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput>
  }

  export type VenueCreateManyEventTypeInputEnvelope = {
    data: VenueCreateManyEventTypeInput | VenueCreateManyEventTypeInput[]
    skipDuplicates?: boolean
  }

  export type VenueUpsertWithWhereUniqueWithoutEventTypeInput = {
    where: VenueWhereUniqueInput
    update: XOR<VenueUpdateWithoutEventTypeInput, VenueUncheckedUpdateWithoutEventTypeInput>
    create: XOR<VenueCreateWithoutEventTypeInput, VenueUncheckedCreateWithoutEventTypeInput>
  }

  export type VenueUpdateWithWhereUniqueWithoutEventTypeInput = {
    where: VenueWhereUniqueInput
    data: XOR<VenueUpdateWithoutEventTypeInput, VenueUncheckedUpdateWithoutEventTypeInput>
  }

  export type VenueUpdateManyWithWhereWithoutEventTypeInput = {
    where: VenueScalarWhereInput
    data: XOR<VenueUpdateManyMutationInput, VenueUncheckedUpdateManyWithoutEventTypeInput>
  }

  export type VenueScalarWhereInput = {
    AND?: VenueScalarWhereInput | VenueScalarWhereInput[]
    OR?: VenueScalarWhereInput[]
    NOT?: VenueScalarWhereInput | VenueScalarWhereInput[]
    id?: IntFilter<"Venue"> | number
    name?: StringFilter<"Venue"> | string
    capacity?: IntFilter<"Venue"> | number
    location?: StringFilter<"Venue"> | string
    status?: EnumVenueStatusFilter<"Venue"> | $Enums.VenueStatus
    bookings?: IntFilter<"Venue"> | number
    description?: StringNullableFilter<"Venue"> | string | null
    amenities?: StringNullableFilter<"Venue"> | string | null
    eventTypeId?: IntNullableFilter<"Venue"> | number | null
    createdAt?: DateTimeFilter<"Venue"> | Date | string
  }

  export type EventCreateManyStudentInput = {
    id?: number
    title: string
    description?: string | null
    date: Date | string
    location: string
    status?: $Enums.EventStatus
    createdAt?: Date | string
  }

  export type EventUpdateWithoutStudentInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventUncheckedUpdateWithoutStudentInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EventUncheckedUpdateManyWithoutStudentInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumEventStatusFieldUpdateOperationsInput | $Enums.EventStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueCreateManyEventTypeInput = {
    id?: number
    name: string
    capacity: number
    location: string
    status?: $Enums.VenueStatus
    bookings?: number
    description?: string | null
    amenities?: string | null
    createdAt?: Date | string
  }

  export type VenueUpdateWithoutEventTypeInput = {
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueUncheckedUpdateWithoutEventTypeInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VenueUncheckedUpdateManyWithoutEventTypeInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    capacity?: IntFieldUpdateOperationsInput | number
    location?: StringFieldUpdateOperationsInput | string
    status?: EnumVenueStatusFieldUpdateOperationsInput | $Enums.VenueStatus
    bookings?: IntFieldUpdateOperationsInput | number
    description?: NullableStringFieldUpdateOperationsInput | string | null
    amenities?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}